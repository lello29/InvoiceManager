# Guida all'importazione del progetto DEXEVE su GitHub

Questa guida ti mostrerà come importare correttamente il progetto DEXEVE su GitHub e come configurarlo per il deployment su Easypanel.

## 1. Preparazione del repository

### Creazione di un nuovo repository su GitHub

1. Accedi al tuo account GitHub
2. Clicca su "New repository" (o "Nuovo repository")
3. Dai un nome al repository (es. "dexeve-invoicing")
4. Scegli se renderlo pubblico o privato (consigliato: privato)
5. Non inizializzare il repository con README, .gitignore o licenza
6. Clicca su "Create repository"

## 2. Importazione del progetto

### Opzione 1: Usando la riga di comando

1. Estrai il file `dexeve-git-completo.tar.gz` in una directory locale
2. Apri un terminale nella directory estratta `dexeve-git-full`
3. Esegui i seguenti comandi:

```bash
# Configura i tuoi dati utente Git (se non l'hai già fatto)
git config --global user.name "Il Tuo Nome"
git config --global user.email "la-tua-email@example.com"

# Aggiungi il repository remoto
git remote add origin https://github.com/username/dexeve-invoicing.git

# Carica il progetto su GitHub
git push -u origin main
```

### Opzione 2: Usando GitHub Desktop

1. Estrai il file `dexeve-git-completo.tar.gz` in una directory locale
2. Apri GitHub Desktop
3. Seleziona "File" -> "Add Local Repository"
4. Naviga fino alla directory `dexeve-git-full` estratta
5. Clicca su "Add Repository"
6. Vai alla scheda "Repository" -> "Push"

## 3. Configurazione per Easypanel

Per configurare correttamente il progetto per Easypanel, devi:

1. Assicurarti che il file `nixpacks.toml` sia nella root del repository
2. Verificare che il file `startup.sh` abbia i permessi di esecuzione
3. Configurare Easypanel per utilizzare il tuo repository GitHub:
   - Nella dashboard di Easypanel, crea un nuovo progetto
   - Seleziona "GitHub" come fonte
   - Inserisci l'URL del tuo repository
   - Configura il branch (solitamente `main`)
   - Imposta le variabili d'ambiente necessarie (vedi sezione successiva)

## 4. Variabili d'ambiente richieste

Configura queste variabili d'ambiente nel progetto Easypanel:

```
DATABASE_URL=postgres://lello29:AA20041984aa@dexeve_postgres-db:5432/dexeve
PORT=5000
HOST=0.0.0.0
NODE_ENV=production
SESSION_SECRET=93748hjdjk847jdjf84jdjk48djdjk8
```

## 5. Aggiornamenti e deployment continuo

Una volta configurato il repository GitHub con Easypanel, puoi facilmente:

1. Apportare modifiche in locale
2. Eseguire commit delle modifiche
3. Push al repository GitHub
4. Easypanel rileverà automaticamente le modifiche e aggiornerà l'applicazione

## Risoluzione dei problemi

### Problema: Errore di build in Easypanel

Se riscontri errori durante la build in Easypanel, verifica:

1. Che il file `nixpacks.toml` sia correttamente configurato
2. Che le variabili d'ambiente siano impostate correttamente
3. Consulta i log di build in Easypanel per identificare problemi specifici

### Problema: Errore di connessione al database

Assicurati che:

1. Il database PostgreSQL sia configurato correttamente in Easypanel
2. La stringa di connessione DATABASE_URL sia corretta
3. Le credenziali del database siano valide

## Contatto per supporto

Se hai bisogno di ulteriore assistenza, contattaci specificando:
- L'URL del tuo repository GitHub
- Gli errori specifici che stai riscontrando
- Le configurazioni di Easypanel che stai utilizzando