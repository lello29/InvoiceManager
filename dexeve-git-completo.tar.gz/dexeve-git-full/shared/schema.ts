import { pgTable, text, serial, integer, boolean, timestamp, numeric, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  name: text("name").notNull(),
  phone: text("phone"),
  address: text("address"),
  taxId: text("tax_id"),
  role: text("role").notNull().default("client"),
});

export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  address: text("address"),
  taxId: text("tax_id"),
  totalPaid: numeric("total_paid"),
  totalPending: numeric("total_pending"),
  totalOverdue: numeric("total_overdue"),
  totalInvoices: integer("total_invoices"),
  paidInvoices: integer("paid_invoices"),
  pendingInvoices: integer("pending_invoices"),
  overdueInvoices: integer("overdue_invoices")
});

// Tabella per la relazione many-to-many tra utenti e clienti
export const userClients = pgTable("user_clients", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  clientId: integer("client_id").notNull().references(() => clients.id),
  isDefault: boolean("is_default").default(false).notNull(),
  accessLevel: text("access_level").default("view").notNull(),
});

export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  number: text("number").notNull().unique(),
  clientId: integer("client_id").notNull().references(() => clients.id),
  issueDate: timestamp("issue_date").notNull(),
  dueDate: timestamp("due_date").notNull(),
  amount: numeric("amount").notNull(),
  status: text("status").notNull().default("pending"),
  paymentType: text("payment_type"),
  paymentDate: timestamp("payment_date"),
  notes: text("notes"),
  pdfPath: text("pdf_path"),
  attachments: jsonb("attachments").$type<{ path: string; name: string; }[]>()
});

export const invoiceItems = pgTable("invoice_items", {
  id: serial("id").primaryKey(),
  invoiceId: integer("invoice_id").notNull().references(() => invoices.id),
  description: text("description").notNull(),
  quantity: numeric("quantity").notNull(),
  price: numeric("price").notNull(),
  total: numeric("total").notNull()
});

export const apiSettings = pgTable("api_settings", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  apiKey: text("api_key").notNull(),
  model: text("model").notNull().default("gpt-4o"),
  extraOptions: jsonb("extra_options"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow()
});

// Relations
export const userRelations = relations(users, ({ many }) => ({
  userClients: many(userClients),
}));

export const clientRelations = relations(clients, ({ many }) => ({
  userClients: many(userClients),
  invoices: many(invoices),
}));

export const userClientRelations = relations(userClients, ({ one }) => ({
  user: one(users, {
    fields: [userClients.userId],
    references: [users.id],
  }),
  client: one(clients, {
    fields: [userClients.clientId],
    references: [clients.id],
  }),
}));

export const invoiceRelations = relations(invoices, ({ one, many }) => ({
  client: one(clients, {
    fields: [invoices.clientId],
    references: [clients.id],
  }),
  items: many(invoiceItems),
}));

export const invoiceItemRelations = relations(invoiceItems, ({ one }) => ({
  invoice: one(invoices, {
    fields: [invoiceItems.invoiceId],
    references: [invoices.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  name: true,
  phone: true,
  address: true,
  taxId: true,
  role: true
});

export const insertClientSchema = createInsertSchema(clients).omit({
  id: true
});

export const insertInvoiceSchema = createInsertSchema(invoices, {
  issueDate: z.coerce.date(),
  dueDate: z.coerce.date(),
  paymentDate: z.coerce.date().nullable().optional(),
  amount: z.coerce.number()
}).omit({
  id: true
});

export const insertInvoiceItemSchema = createInsertSchema(invoiceItems).omit({
  id: true
});

export const insertApiSettingsSchema = createInsertSchema(apiSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertUserClientSchema = createInsertSchema(userClients).omit({
  id: true
});

// Insert types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertClient = z.infer<typeof insertClientSchema>;
export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type InsertInvoiceItem = z.infer<typeof insertInvoiceItemSchema>;
export type InsertApiSettings = z.infer<typeof insertApiSettingsSchema>;
export type InsertUserClient = z.infer<typeof insertUserClientSchema>;

// Select types
export type User = typeof users.$inferSelect;
export type Client = typeof clients.$inferSelect;
export type Invoice = typeof invoices.$inferSelect;
export type InvoiceItem = typeof invoiceItems.$inferSelect;
export type ApiSettings = typeof apiSettings.$inferSelect;

// Extended types for API responses
export type InvoiceWithClient = Invoice & { 
  client: { 
    name: string;
    email: string; 
  } 
};

export type InvoiceWithItems = Invoice & {
  items: InvoiceItem[];
};

export type ClientWithInvoices = Client & {
  invoices: Invoice[];
};
