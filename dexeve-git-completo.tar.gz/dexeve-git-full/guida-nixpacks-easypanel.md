# Guida all'installazione di DEXEVE con Nixpacks su Easypanel

Questa guida ti aiuterà a installare correttamente l'applicazione DEXEVE usando Nixpacks su Easypanel, risolvendo l'errore "Command failed with exit code 1".

## Problema
Easypanel usa Nixpacks come sistema di build e non utilizza direttamente Dockerfile. Questo spiega l'errore che stai ricevendo.

## Soluzione

### Passo 1: Prepara i file di configurazione Nixpacks

1. Scarica e estrai il pacchetto contenente:
   - `nixpacks.toml` - Configurazione per Nixpacks
   - `startup.sh` - Script di avvio personalizzato
   - Questa guida

2. Assicurati che questi file siano nella directory principale del tuo progetto.

### Passo 2: Configura il progetto in Easypanel

1. Accedi alla dashboard di Easypanel
2. Crea un nuovo progetto (o seleziona quello esistente)
3. Nelle impostazioni, assicurati di:
   - Impostare la porta dell'applicazione a `5000`
   - Attivare "Public" per renderla accessibile

### Passo 3: Configura le variabili d'ambiente

Imposta le seguenti variabili d'ambiente nel tuo progetto:

```
DATABASE_URL=postgres://lello29:AA20041984aa@dexeve_postgres-db:5432/dexeve
NODE_ENV=production
PORT=5000
HOST=0.0.0.0
SESSION_SECRET=93748hjdjk847jdjf84jdjk48djdjk8
```

### Passo 4: Configura il database

1. Aggiungi un servizio PostgreSQL a Easypanel
2. Imposta:
   - Nome utente: `lello29`
   - Password: `AA20041984aa`
   - Nome del database: `dexeve`

### Passo 5: Deploy dell'applicazione

1. Carica i file del progetto in Easypanel (inclusi nixpacks.toml e startup.sh)
2. Avvia il deploy
3. Monitora i log durante il processo di build e avvio

## Risoluzione dei problemi

### Problema: La build fallisce ancora

1. Verifica che il file `nixpacks.toml` sia nella directory principale
2. Controlla i log di build per errori specifici
3. Prova ad aggiungere il file `.env` con le variabili d'ambiente

### Problema: L'applicazione non è accessibile (errore 404)

1. Verifica che la porta configurata sia `5000`
2. Controlla che l'impostazione "Public" sia attivata
3. Verifica nei log che l'applicazione sia avviata correttamente

### Problema: Errori di connessione al database

1. Verifica che il servizio database sia in esecuzione
2. Controlla che le credenziali del database siano corrette
3. Assicurati che la stringa di connessione DATABASE_URL sia corretta

## Contatto per assistenza

Se hai bisogno di ulteriore assistenza, contattaci specificando:
- Gli errori esatti visualizzati nei log
- Le impostazioni di Easypanel che stai utilizzando
- Screenshot della dashboard se possibile