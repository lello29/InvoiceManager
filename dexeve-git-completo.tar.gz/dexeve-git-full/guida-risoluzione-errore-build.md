# Guida alla Risoluzione del Problema 404 su Easypanel

Questa guida fornisce istruzioni dettagliate per risolvere il problema "HTTP ERROR 404" quando si prova ad accedere all'applicazione DEXEVE deploy su Easypanel.

## Problema
Quando si accede all'URL `https://dexeve-dexeve.s5tvyi.easypanel.host/`, viene mostrato un errore 404, indicando che l'applicazione non è accessibile.

## Soluzioni

### 1. Verifica la Configurazione delle Porte in Easypanel

1. Accedi alla dashboard di Easypanel
2. Seleziona il progetto "dexeve"
3. Vai alla scheda "Settings"
4. Verifica che il "Container Port" sia impostato su `5000`
5. Verifica che "Public" sia impostato su "Yes"
6. Fai clic su "Save" se hai apportato modifiche

### 2. Utilizza il Dockerfile Aggiornato

Il Dockerfile corrente potrebbe avere problemi con l'esposizione delle porte. Segui questi passaggi:

1. Accedi al server Easypanel via SSH
2. Naviga nella directory del progetto
3. Crea un nuovo file `Dockerfile` con il contenuto del file `Dockerfile-fixed` fornito
4. Aggiorna il file docker-entrypoint.sh con la versione corretta
5. Ricostruisci e riavvia il container

```bash
# Sul server Easypanel
cd /path/to/dexeve
mv Dockerfile-fixed Dockerfile
chmod +x docker-entrypoint-fixed.sh
mv docker-entrypoint-fixed.sh docker-entrypoint.sh
```

### 3. Configura Correttamente le Variabili d'Ambiente

Verifica che le seguenti variabili d'ambiente siano impostate correttamente in Easypanel:

- `DATABASE_URL`: postgres://lello29:AA20041984aa@db:5432/dexeve
- `PORT`: 5000
- `HOST`: 0.0.0.0
- `NODE_ENV`: production

### 4. Verifica i Log dell'Applicazione

Se il problema persiste, controlla i log dell'applicazione:

1. Vai alla dashboard di Easypanel
2. Seleziona il progetto "dexeve"
3. Vai alla scheda "Logs"
4. Cerca errori specifici che potrebbero indicare il problema

### 5. Prova con un Nuovo Deployment

Se le soluzioni precedenti non funzionano, prova con un nuovo deployment:

1. Scarica il pacchetto corretto: [dexeve-docker-completo.tar.gz](url)
2. Estrai il contenuto
3. Carica i file su Easypanel
4. Configura un nuovo progetto usando il Dockerfile aggiornato

### Configurazione del Database

Verifica che il database sia accessibile dalla tua applicazione:

```bash
# Esegui questo comando all'interno del container dell'applicazione
psql -h db -U lello29 -d dexeve -c "SELECT 'connessione riuscita'"
```

## Contatto per Supporto

Se hai ancora problemi dopo aver seguito queste istruzioni, contattaci per ricevere assistenza.