import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Download, X, Maximize, RefreshCcw } from "lucide-react";
import { Dialog, DialogTrigger, DialogContent } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { SimplePdfViewer } from './simple-pdf-viewer';

interface PdfViewerProps {
  pdfUrl: string;
  className?: string;
  onClose?: () => void;
  downloadUrl?: string;
  downloadFilename?: string;
}

export { SimplePdfViewer } from './simple-pdf-viewer';

// Componente pulsante per visualizzare un PDF
export function PdfViewerButton({ 
  pdfUrl, 
  buttonText = "Visualizza PDF",
  downloadUrl,
  downloadFilename
}: { 
  pdfUrl: string; 
  buttonText?: string;
  downloadUrl?: string;
  downloadFilename?: string;
}) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          {buttonText}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-5xl w-[90vw] max-h-[90vh] p-0">
        <PdfViewer 
          pdfUrl={pdfUrl} 
          className="h-[85vh]"
          downloadUrl={downloadUrl}
          downloadFilename={downloadFilename}
        />
      </DialogContent>
    </Dialog>
  );
}

export function PdfViewer({
  pdfUrl,
  className,
  onClose,
  downloadUrl,
  downloadFilename = "documento.pdf"
}: PdfViewerProps) {
  const [fullscreen, setFullscreen] = useState<boolean>(false);
  const [refreshKey, setRefreshKey] = useState<number>(0);
  
  // URL del PDF
  const [currentUrl, setCurrentUrl] = useState<string>(pdfUrl);
  
  // Gestione file mancanti con il nuovo endpoint secure-pdf
  React.useEffect(() => {
    console.log("PDF Viewer - percorso documento:", pdfUrl);
    
    // Estrai il nome del file dal percorso originale
    const fileName = pdfUrl.split('/').pop() || '';
    
    // Usa il nuovo endpoint secure-pdf
    const nocacheParam = `?_t=${Date.now()}`;
    const secureUrl = `/api/secure-pdf/${encodeURIComponent(fileName)}${nocacheParam}`;
    
    console.log("Usando endpoint sicuro per PDF:", secureUrl);
    setCurrentUrl(secureUrl);
  }, [pdfUrl]);
  
  // Funzione per provare un URL alternativo o forzare il refresh
  function tryAlternativeUrl() {
    console.log("Tentativo di ricarica del PDF usando il nuovo endpoint sicuro");
    
    // Estrai il nome del file dal percorso originale
    const fileName = pdfUrl.split('/').pop() || '';
    
    // Usa il nuovo endpoint secure-pdf con un nuovo timestamp
    const nocacheParam = `?_t=${Date.now()}`;
    const secureUrl = `/api/secure-pdf/${encodeURIComponent(fileName)}${nocacheParam}`;
    
    console.log("Nuovo URL sicuro per PDF:", secureUrl);
    setCurrentUrl(secureUrl);
    
    // Forza il refresh del componente
    setRefreshKey(prev => prev + 1);
  }

  return (
    <div className={cn("flex flex-col items-center bg-white rounded-lg overflow-hidden", className)}>
      <div className="flex justify-between items-center w-full p-2 bg-gray-100 border-b">
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={tryAlternativeUrl}
          >
            <RefreshCcw className="h-4 w-4 mr-1" />
            <span className="hidden sm:inline">Riprova</span>
          </Button>
        </div>
        
        <div className="flex items-center gap-2">
          {downloadUrl && (
            <a 
              href={downloadUrl} 
              download={downloadFilename}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-1" />
                <span className="hidden sm:inline">Scarica</span>
              </Button>
            </a>
          )}
          
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" onClick={() => setFullscreen(true)}>
                <Maximize className="h-4 w-4 mr-1" />
                <span className="hidden sm:inline">Schermo intero</span>
              </Button>
            </DialogTrigger>
          </Dialog>
          
          {onClose && (
            <Button variant="outline" size="sm" onClick={onClose}>
              <X className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Chiudi</span>
            </Button>
          )}
        </div>
      </div>
      
      <div className="w-full overflow-auto bg-gray-50 flex-1 flex items-center justify-center">
        {/* Utilizziamo un iframe con key per forzare il rendering se necessario */}
        <iframe 
          key={`pdf-${refreshKey}`}
          src={currentUrl}
          className="w-full h-full min-h-[500px]"
          style={{ border: "none" }}
          title="PDF Viewer"
          allow="fullscreen"
          onError={() => console.error("Errore nel caricamento dell'iframe")}
        />
      </div>
    </div>
  );
}