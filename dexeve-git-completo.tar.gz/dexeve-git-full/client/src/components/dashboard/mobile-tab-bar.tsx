import { useAuth } from "@/hooks/use-auth";
import { BarChart3, FileText, Home, Settings, User, Users, LogOut, Building, MessageSquare, UserCog, LineChart, FileX } from "lucide-react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

export function MobileTabBar() {
  const { user, logoutMutation } = useAuth();
  const [location, setLocation] = useLocation();
  
  // Se l'utente non è autenticato, non mostrare la barra
  if (!user) {
    return null;
  }
  
  // Determina se l'utente è un amministratore
  const isAdmin = user.role === "admin";
  
  // Funzione per gestire il click sui tab
  const handleTabClick = (path: string) => {
    setLocation(path);
  };
  
  // Funzione per determinare se un tab è attivo
  const isActive = (path: string) => {
    // Per la dashboard admin, controlla che sia specificamente la rotta principale
    if (path === "/admin" && location === "/admin") {
      return true;
    }
    // Per gli altri percorsi, controlla se l'URL corrente inizia con il percorso dato
    return location === path || 
           (path !== "/admin" && location.startsWith(path)) || 
           (path === "/admin/invoices" && location === "/invoices") || 
           (path === "/admin/clients" && location === "/clients") || 
           (path === "/admin/user-clients" && location === "/user-clients") || 
           (path === "/admin/analytics" && location === "/analytics") || 
           (path === "/admin/missing-pdf" && location === "/missing-pdf") || 
           (path === "/admin/settings" && location === "/settings");
  };
  
  // Gestisce il logout
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50 shadow-lg">
      <div className="grid grid-cols-6 h-16">
        {isAdmin ? (
          // ADMIN TABS
          <>
            <NavButton 
              icon={<BarChart3 />} 
              label="Dashboard" 
              active={isActive("/admin") && !location.includes('/admin/')} 
              onClick={() => handleTabClick("/admin")} 
            />
            <NavButton 
              icon={<FileText />} 
              label="Fatture" 
              active={isActive("/admin/invoices") || isActive("/invoices")} 
              onClick={() => handleTabClick("/admin/invoices")} 
            />
            <NavButton 
              icon={<Users />} 
              label="Clienti" 
              active={isActive("/admin/clients") || isActive("/clients")} 
              onClick={() => handleTabClick("/admin/clients")} 
            />
            <NavButton 
              icon={<FileX />} 
              label="PDF" 
              active={isActive("/admin/missing-pdf")} 
              onClick={() => handleTabClick("/admin/missing-pdf")} 
            />
            <NavButton 
              icon={<LineChart />} 
              label="Analisi" 
              active={isActive("/admin/analytics")} 
              onClick={() => handleTabClick("/admin/analytics")} 
            />
            <NavButton 
              icon={<Settings />} 
              label="Impostazioni" 
              active={isActive("/admin/settings") || isActive("/settings")} 
              onClick={() => handleTabClick("/admin/settings")} 
            />
          </>
        ) : (
          // CLIENT TABS
          <>
            <NavButton 
              icon={<FileText />} 
              label="Fatture" 
              active={location === "/client" || (location.includes("/client") && location.includes("tab=fatture"))} 
              onClick={() => handleTabClick("/client?tab=fatture")} 
            />
            <NavButton 
              icon={<User />} 
              label="Profilo" 
              active={location.includes("/client") && location.includes("tab=profilo")} 
              onClick={() => handleTabClick("/client?tab=profilo")} 
            />
            <NavButton 
              icon={<Building />} 
              label="Azienda" 
              active={location.includes("/client") && location.includes("tab=azienda")} 
              onClick={() => handleTabClick("/client?tab=azienda")} 
            />
            <NavButton 
              icon={<MessageSquare />} 
              label="Messaggi" 
              active={location.includes("/client") && location.includes("tab=messaggi")} 
              onClick={() => handleTabClick("/client?tab=messaggi")} 
            />
          </>
        )}
      </div>
    </div>
  );
}

// Componente per un pulsante della barra di navigazione
function NavButton({ 
  icon, 
  label, 
  active, 
  onClick 
}: { 
  icon: React.ReactNode; 
  label: string; 
  active: boolean; 
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex flex-col items-center justify-center space-y-1",
        active 
          ? "text-amber-600 font-medium" 
          : "text-gray-600 hover:text-amber-500"
      )}
    >
      <div className={cn(
        "w-6 h-6",
        active && "text-amber-600"
      )}>
        {icon}
      </div>
      <span className="text-xs">{label}</span>
    </button>
  );
}