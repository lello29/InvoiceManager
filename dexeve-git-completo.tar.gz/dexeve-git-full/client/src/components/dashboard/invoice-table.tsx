import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { StatusBadge } from "@/components/ui/status-badge";
import { Button } from "@/components/ui/button";
import { Eye, Edit, Trash, Download, ChevronLeft, ChevronRight, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";
import { useState, useMemo, useEffect } from "react";
import { Invoice, InvoiceWithClient } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { formatDate, formatCurrency, getSafeDateValue } from "@/lib/utils";
import { InvoiceCardMobile } from "./invoice-card-mobile";
import { useIsMobile } from "@/hooks/use-mobile";
import { EditableCell } from "@/components/ui/editable-cell";
import { ChevronDown, ChevronUp } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

// Componente per gestire il pulsante di download con verifica di esistenza del file
interface PdfDownloadButtonProps {
  invoice: Invoice | InvoiceWithClient;
  onDownload: (invoice: Invoice | InvoiceWithClient) => void;
}

function PdfDownloadButton({ invoice, onDownload }: PdfDownloadButtonProps) {
  const [fileStatus, setFileStatus] = useState<'loading' | 'available' | 'not_found' | 'error'>('loading');
  
  useEffect(() => {
    // Se non c'è un percorso PDF, imposta subito come non disponibile
    if (!invoice.pdfPath) {
      setFileStatus('not_found');
      return;
    }
    
    // Verifica l'esistenza del file
    const checkFileExists = async () => {
      try {
        // Assicuriamoci che il percorso inizi con / se non è un URL completo
        let path = invoice.pdfPath || '';
        if (path && !path.startsWith('http') && !path.startsWith('/')) {
          path = '/' + path;
        }
        
        // Utilizziamo /api/download-pdf/ per i controlli di disponibilità
        if (path.includes('/api/uploads/')) {
          const pathParts = path.split('/api/uploads/');
          if (pathParts.length > 1) {
            path = `/api/download-pdf/${encodeURIComponent(pathParts[1])}`;
          }
        }
        
        console.log("Verifica disponibilità file PDF:", path);
        
        // Aggiungiamo un timestamp per evitare il caching
        const nocacheUrl = `${path}${path.includes('?') ? '&' : '?'}_t=${Date.now()}`;
        
        // Utilizziamo GET invece di HEAD per maggiore compatibilità
        const response = await fetch(nocacheUrl, { 
          method: 'GET',
          headers: { 'Pragma': 'no-cache', 'Cache-Control': 'no-cache' }
        });
        
        if (response.ok) {
          console.log("File PDF disponibile:", path);
          setFileStatus('available');
        } else {
          console.warn("File PDF non disponibile:", path, "Status:", response.status);
          setFileStatus('not_found');
        }
      } catch (error) {
        console.error("Errore nella verifica del PDF:", error);
        setFileStatus('error');
      }
    };
    
    // Aggiungiamo un piccolo ritardo prima del controllo
    const timer = setTimeout(() => {
      checkFileExists();
    }, 500);  // 500ms di ritardo
    
    return () => clearTimeout(timer);
  }, [invoice.pdfPath]);
  
  // Rendering condizionale in base allo stato
  if (fileStatus === 'loading') {
    return (
      <Button 
        variant="outline" 
        size="icon" 
        disabled
        className="border-gray-300 opacity-70"
      >
        <Loader2 className="h-4 w-4 animate-spin text-gray-500" />
      </Button>
    );
  }
  
  if (fileStatus === 'available') {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="outline" 
              size="icon" 
              onClick={() => onDownload(invoice)} 
              className="border-green-500 hover:bg-green-50 hover:text-green-700"
            >
              <Download className="h-4 w-4 text-green-600" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Scarica PDF</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }
  
  // Per not_found o error
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            variant="outline" 
            size="icon" 
            disabled
            className="border-red-300 opacity-70"
          >
            <AlertCircle className="h-4 w-4 text-red-500" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>{fileStatus === 'not_found' ? 'PDF non trovato' : 'Errore nella verifica del PDF'}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

interface InvoiceTableProps {
  invoices: InvoiceWithClient[] | Invoice[];
  isAdmin?: boolean;
  onView: (invoice: InvoiceWithClient | Invoice) => void;
  onEdit?: (invoice: InvoiceWithClient | Invoice) => void;
  total: number;
  currentPage: number;
  onPageChange: (page: number) => void;
  pageSize: number;
  onUpdateInvoice?: (id: number, field: string, value: string | null) => void;
}

export function InvoiceTable({ 
  invoices, 
  isAdmin = false, 
  onView, 
  onEdit,
  total,
  currentPage,
  onPageChange,
  pageSize,
  onUpdateInvoice
}: InvoiceTableProps) {
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [invoiceToDelete, setInvoiceToDelete] = useState<InvoiceWithClient | Invoice | null>(null);
  const [sortColumn, setSortColumn] = useState<string>("issueDate");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [selectedInvoices, setSelectedInvoices] = useState<Record<number, boolean>>({});
  const { toast } = useToast();
  const isMobile = useIsMobile();
  
  // Funzione per gestire il download diretto del PDF
  const handleDownloadPdf = async (invoice: Invoice | InvoiceWithClient) => {
    if (!invoice.pdfPath) {
      toast({
        title: "PDF non disponibile",
        description: "Il documento PDF per questa fattura non è disponibile",
        variant: "destructive"
      });
      return;
    }
    
    // Assicuriamoci che il percorso inizi con / se non è un URL completo
    let path = invoice.pdfPath || '';
    if (path && !path.startsWith('http') && !path.startsWith('/')) {
      path = '/' + path;
    }
    
    // Prima verifichiamo che il file esista fisicamente
    try {
      // Effettua una richiesta HEAD per verificare se il file esiste
      // Utilizziamo l'endpoint ottimizzato per le verifiche
      // Aggiungiamo un timestamp per evitare il caching
      const nocacheUrl = `${path}${path.includes('?') ? '&' : '?'}_t=${Date.now()}`;
      
      const verifyResponse = await fetch(nocacheUrl, {
        method: 'HEAD',
        headers: { 'Pragma': 'no-cache', 'Cache-Control': 'no-cache' }
      });
      
      if (!verifyResponse.ok) {
        // Il file non esiste, notifica l'utente
        toast({
          title: "PDF non trovato",
          description: "Il file PDF è registrato nel database ma non è stato trovato sul server",
          variant: "destructive"
        });
        
        return;
      }
    } catch (error) {
      console.error("Errore nella verifica del PDF:", error);
      toast({
        title: "Errore nella verifica",
        description: "Non è stato possibile verificare l'esistenza del file PDF",
        variant: "destructive"
      });
      return;
    }
    
    // Usa il nuovo endpoint sicuro per PDF
    // Estrai il nome del file dal percorso originale
    const fileName = path.split('/').pop() || '';
    
    // Usa il nuovo endpoint secure-pdf con parametro di download
    // Aggiungiamo l'ID della fattura per ottenere un nome file descrittivo con i dati corretti
    path = `/api/secure-pdf/${encodeURIComponent(fileName)}?download=true&invoiceId=${invoice.id}&_t=${Date.now()}`;
    console.log("Download PDF con percorso:", path);
    
    // Creiamo un link temporaneo per il download
    const link = document.createElement('a');
    link.href = path;
    // Il nome del file sarà generato lato server, qui non impostiamo link.download
    // per permettere al server di definire il nome file
    link.target = '_blank'; 
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Download avviato",
      description: "Il download del PDF è stato avviato"
    });
  };

  const totalPages = Math.ceil(total / pageSize);
  const startItem = (currentPage - 1) * pageSize + 1;
  const endItem = Math.min(currentPage * pageSize, total);

  const deleteInvoice = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/invoices/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Fattura eliminata",
        description: "La fattura è stata eliminata con successo.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/invoices'] });
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: `Impossibile eliminare la fattura: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const handleDeleteClick = (invoice: InvoiceWithClient | Invoice) => {
    setInvoiceToDelete(invoice);
    setDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = () => {
    if (invoiceToDelete) {
      deleteInvoice.mutate(invoiceToDelete.id);
      setDeleteConfirmOpen(false);
    }
  };

  // Determine if the invoice has client information
  const hasClientInfo = (invoice: any): invoice is InvoiceWithClient => {
    return 'client' in invoice && invoice.client;
  };
  
  // Funzione per ottenere il nome leggibile del tipo di pagamento
  function getPaymentTypeName(type: string): string {
    switch (type) {
      case 'bank_transfer':
        return 'Bonifico bancario';
      case 'credit_card':
        return 'Carta di credito';
      case 'cash':
        return 'Contanti';
      case 'paypal':
        return 'PayPal';
      default:
        return type;
    }
  };
  
  // Gestione selezione multipla
  const handleSelectInvoice = (id: number, checked: boolean) => {
    setSelectedInvoices(prev => ({
      ...prev,
      [id]: checked
    }));
  };
  
  const handleSelectAll = (checked: boolean) => {
    const newSelected: Record<number, boolean> = {};
    if (checked) {
      sortedInvoices.forEach(invoice => {
        newSelected[invoice.id] = true;
      });
    }
    setSelectedInvoices(newSelected);
  };
  
  // Conteggio delle fatture selezionate
  const selectedCount = Object.values(selectedInvoices).filter(Boolean).length;
  
  // Aggiungi funzione di aggiornamento inline
  const updateInvoice = useMutation({
    mutationFn: async ({ id, field, value }: { id: number; field: string; value: string | null }) => {
      // Converti i numeri in formato stringa quando necessario
      const finalValue = typeof value === 'number' ? String(value) : value;
      const response = await apiRequest("PATCH", `/api/admin/invoices/${id}`, { field, value: finalValue });
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Fattura aggiornata",
        description: "Il valore è stato aggiornato con successo.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/invoices'] });
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: `Impossibile aggiornare il valore: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Handler per l'aggiornamento inline
  const handleUpdateField = (invoice: Invoice | InvoiceWithClient, field: string, value: string | null) => {
    // Per tutti i campi, incluse le date, usiamo il valore così com'è
    // La conversione verrà gestita dal server
    if (onUpdateInvoice) {
      onUpdateInvoice(invoice.id, field, value);
    } else {
      updateInvoice.mutate({ 
        id: invoice.id, 
        field, 
        value 
      });
    }
  };
  
  // Funzione per gestire il click sulle intestazioni delle colonne per l'ordinamento
  const handleSort = (column: string) => {
    if (sortColumn === column) {
      // Se la colonna è già selezionata, invertiamo la direzione
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      // Altrimenti impostiamo la nuova colonna e la direzione predefinita
      setSortColumn(column);
      setSortDirection("asc");
    }
    
    // Reset alla prima pagina quando cambia l'ordinamento
    if (currentPage !== 1) {
      onPageChange(1);
    }
  };
  
  // Funzione per ottenere le fatture ordinate localmente
  const sortedInvoices = useMemo(() => {
    return [...invoices].sort((a, b) => {
      let valA: any;
      let valB: any;
      
      // Estrai i valori da confrontare in base alla colonna selezionata
      switch (sortColumn) {
        case "number":
          valA = a.number;
          valB = b.number;
          break;
        case "issueDate":
          valA = new Date(a.issueDate as any).getTime();
          valB = new Date(b.issueDate as any).getTime();
          break;
        case "paymentDate":
          valA = a.paymentDate ? new Date(a.paymentDate as any).getTime() : 0;
          valB = b.paymentDate ? new Date(b.paymentDate as any).getTime() : 0;
          break;
        case "paymentType":
          valA = a.paymentType || "";
          valB = b.paymentType || "";
          break;
        case "amount":
          valA = Number(a.amount);
          valB = Number(b.amount);
          break;
        case "status":
          valA = a.status;
          valB = b.status;
          break;
        default:
          valA = a.number;
          valB = b.number;
      }
      
      // Applica l'ordinamento in base alla direzione
      if (sortDirection === "asc") {
        return valA > valB ? 1 : valA < valB ? -1 : 0;
      } else {
        return valA < valB ? 1 : valA > valB ? -1 : 0;
      }
    });
  }, [invoices, sortColumn, sortDirection]);

  return (
    <>
      {isMobile ? (
        <div className="space-y-1 px-2">
          {invoices.length === 0 ? (
            <div className="text-center py-8 text-gray-500 bg-white rounded-lg shadow-sm">
              Nessuna fattura trovata
            </div>
          ) : (
            <>
              {sortedInvoices.map((invoice) => (
                <InvoiceCardMobile 
                  key={invoice.id} 
                  invoice={invoice}
                  onView={onView}
                  onEdit={isAdmin ? onEdit : undefined}
                  onUpdateInvoice={onUpdateInvoice}
                />
              ))}
              
              {/* Mobile pagination */}
              {total > 0 && (
                <div className="flex justify-between mt-4 mb-8">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onPageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                    className="text-xs"
                  >
                    <ChevronLeft className="h-3 w-3 mr-1" />
                    Precedente
                  </Button>
                  <div className="text-xs text-center">
                    <span className="font-medium">{currentPage}</span> / <span>{totalPages}</span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onPageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                    className="text-xs"
                  >
                    Successiva
                    <ChevronRight className="h-3 w-3 ml-1" />
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      ) : (
        <div className="overflow-x-auto bg-white shadow rounded-lg">
          {/* Riepilogo selezione multipla */}
          {selectedCount > 0 && (
            <div className="bg-primary-50 border-b border-primary-100 p-2 flex items-center justify-between">
              <div className="flex items-center">
                <CheckCircle2 className="h-5 w-5 text-primary mr-2" />
                <span className="text-sm font-medium">
                  {selectedCount} {selectedCount === 1 ? 'fattura selezionata' : 'fatture selezionate'}
                </span>
              </div>
              <div className="flex space-x-2">
                <Button size="sm" variant="outline" className="text-xs" 
                  onClick={() => toast({
                    title: "Azione completata",
                    description: `${selectedCount} fatture selezionate contrassegnate come verificate`,
                  })}>
                  <CheckCircle2 className="h-3.5 w-3.5 mr-1" />
                  Segna come verificate
                </Button>
                <Button size="sm" variant="outline" className="text-xs border-red-500 text-red-600 hover:bg-red-50"
                  onClick={() => setSelectedInvoices({})}>
                  Cancella selezione
                </Button>
              </div>
            </div>
          )}
          
          <Table>
            <TableHeader className="bg-gray-50">
              <TableRow>
                <TableHead className="w-[40px]">
                  <Checkbox 
                    checked={selectedCount > 0 && selectedCount === sortedInvoices.length} 
                    onCheckedChange={handleSelectAll}
                    aria-label="Seleziona tutte le fatture"
                  />
                </TableHead>
                <TableHead className="w-[150px]">
                  <div 
                    className="flex items-center cursor-pointer" 
                    onClick={() => handleSort("number")}
                  >
                    N. Fattura
                    {sortColumn === "number" && (
                      sortDirection === "asc" ? <ChevronUp className="ml-1 h-4 w-4" /> : <ChevronDown className="ml-1 h-4 w-4" />
                    )}
                  </div>
                </TableHead>
                {isAdmin && (
                  <TableHead>
                    <div className="flex items-center">
                      Cliente
                    </div>
                  </TableHead>
                )}
                <TableHead>
                  <div 
                    className="flex items-center cursor-pointer" 
                    onClick={() => handleSort("issueDate")}
                  >
                    Data Emissione
                    {sortColumn === "issueDate" && (
                      sortDirection === "asc" ? <ChevronUp className="ml-1 h-4 w-4" /> : <ChevronDown className="ml-1 h-4 w-4" />
                    )}
                  </div>
                </TableHead>
                <TableHead>
                  <div 
                    className="flex items-center cursor-pointer" 
                    onClick={() => handleSort("paymentType")}
                  >
                    Tipo Pagamento
                    {sortColumn === "paymentType" && (
                      sortDirection === "asc" ? <ChevronUp className="ml-1 h-4 w-4" /> : <ChevronDown className="ml-1 h-4 w-4" />
                    )}
                  </div>
                </TableHead>
                <TableHead>
                  <div 
                    className="flex items-center cursor-pointer" 
                    onClick={() => handleSort("paymentDate")}
                  >
                    Data Pagamento
                    {sortColumn === "paymentDate" && (
                      sortDirection === "asc" ? <ChevronUp className="ml-1 h-4 w-4" /> : <ChevronDown className="ml-1 h-4 w-4" />
                    )}
                  </div>
                </TableHead>
                <TableHead>
                  <div 
                    className="flex items-center cursor-pointer" 
                    onClick={() => handleSort("amount")}
                  >
                    Importo
                    {sortColumn === "amount" && (
                      sortDirection === "asc" ? <ChevronUp className="ml-1 h-4 w-4" /> : <ChevronDown className="ml-1 h-4 w-4" />
                    )}
                  </div>
                </TableHead>
                <TableHead>
                  <div 
                    className="flex items-center cursor-pointer" 
                    onClick={() => handleSort("status")}
                  >
                    Stato
                    {sortColumn === "status" && (
                      sortDirection === "asc" ? <ChevronUp className="ml-1 h-4 w-4" /> : <ChevronDown className="ml-1 h-4 w-4" />
                    )}
                  </div>
                </TableHead>
                <TableHead className="text-right">
                  Azioni
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedInvoices.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={isAdmin ? 6 : 6} className="text-center py-8 text-gray-500">
                    Nessuna fattura trovata
                  </TableCell>
                </TableRow>
              ) : (
                sortedInvoices.map((invoice) => (
                  <TableRow 
                    key={invoice.id} 
                    className={`hover:bg-gray-50 ${selectedInvoices[invoice.id] ? 'bg-primary/5' : ''}`}
                  >
                    <TableCell>
                      <Checkbox 
                        checked={selectedInvoices[invoice.id] || false}
                        onCheckedChange={(checked) => handleSelectInvoice(invoice.id, !!checked)}
                        aria-label={`Seleziona fattura ${invoice.number}`}
                      />
                    </TableCell>
                    <TableCell className="font-medium font-mono">
                      {isAdmin ? (
                        <EditableCell 
                          value={invoice.number} 
                          onChange={(value) => handleUpdateField(invoice, "number", value)}
                          className="font-mono"
                        />
                      ) : (
                        invoice.number
                      )}
                    </TableCell>
                    {isAdmin && (
                      <TableCell>
                        {hasClientInfo(invoice) ? (
                          <>
                            <div className="text-sm text-gray-900">{invoice.client.name}</div>
                            <div className="text-xs text-gray-500">{invoice.client.email}</div>
                          </>
                        ) : (
                          <div className="text-sm text-gray-500">Cliente non disponibile</div>
                        )}
                      </TableCell>
                    )}
                    <TableCell className="text-gray-500">
                      {isAdmin ? (
                        <EditableCell 
                          value={getSafeDateValue(invoice.issueDate)} 
                          onChange={(value) => handleUpdateField(invoice, "issueDate", value)}
                          type="date"
                        />
                      ) : (
                        formatDate(new Date(invoice.issueDate as any))
                      )}
                    </TableCell>
                    <TableCell className="text-gray-500">
                      {isAdmin ? (
                        <EditableCell 
                          value={invoice.paymentType || ''} 
                          onChange={(value) => handleUpdateField(invoice, "paymentType", value)}
                          type="select"
                          options={[
                            { value: "", label: "Seleziona tipo pagamento" },
                            { value: "bank_transfer", label: "Bonifico bancario" },
                            { value: "credit_card", label: "Carta di credito" },
                            { value: "cash", label: "Contanti" },
                            { value: "paypal", label: "PayPal" }
                          ]}
                          placeholder="Non specificato"
                        />
                      ) : (
                        invoice.paymentType ? getPaymentTypeName(invoice.paymentType) : <span className="text-gray-400">Non specificato</span>
                      )}
                    </TableCell>
                    <TableCell className="text-gray-500">
                      {isAdmin ? (
                        <EditableCell 
                          value={invoice.paymentDate ? getSafeDateValue(invoice.paymentDate) : ''} 
                          onChange={(value) => handleUpdateField(invoice, "paymentDate", value || null)}
                          type="date"
                          placeholder="Non impostata"
                        />
                      ) : (
                        invoice.paymentDate ? formatDate(new Date(invoice.paymentDate as any)) : <span className="text-gray-400">Non impostata</span>
                      )}
                    </TableCell>
                    <TableCell className="font-medium">
                      {isAdmin ? (
                        <EditableCell 
                          value={String(invoice.amount)} 
                          onChange={(value) => {
                            // Prima converti a string per assicurarci che handleUpdateField riceva il tipo corretto
                            handleUpdateField(invoice, "amount", value);
                          }}
                          type="text"
                          className="font-medium"
                        />
                      ) : (
                        formatCurrency(Number(invoice.amount))
                      )}
                    </TableCell>
                    <TableCell>
                      {isAdmin ? (
                        <EditableCell 
                          value={invoice.status} 
                          onChange={(value) => handleUpdateField(invoice, "status", value)}
                          type="select"
                          options={[
                            { value: "pending", label: "In attesa" },
                            { value: "paid", label: "Pagata" },
                            { value: "overdue", label: "Scaduta" },
                            { value: "cancelled", label: "Annullata" }
                          ]}
                        />
                      ) : (
                        <StatusBadge status={invoice.status} />
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button variant="ghost" size="icon" onClick={() => onView(invoice)} title="Visualizza">
                          <Eye className="h-4 w-4 text-primary" />
                        </Button>
                        {isAdmin && onEdit && (
                          <>
                            <Button variant="ghost" size="icon" onClick={() => onEdit(invoice)} title="Modifica">
                              <Edit className="h-4 w-4 text-gray-600" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDeleteClick(invoice)} title="Elimina">
                              <Trash className="h-4 w-4 text-red-600" />
                            </Button>
                          </>
                        )}
                        {/* Pulsante di download con verifica dell'esistenza del file */}
                        <PdfDownloadButton invoice={invoice} onDownload={handleDownloadPdf} />
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>

          {/* Desktop pagination */}
          {total > 0 && (
            <div className="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
              <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                <div>
                  <p className="text-sm text-gray-700">
                    Mostrati <span className="font-medium">{startItem}</span> a <span className="font-medium">{endItem}</span> di <span className="font-medium">{total}</span> risultati
                  </p>
                </div>
                <div>
                  <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onPageChange(currentPage - 1)}
                      disabled={currentPage === 1}
                      className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                    >
                      <span className="sr-only">Precedente</span>
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    
                    {/* Page numbers */}
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                      <Button
                        key={page}
                        variant={page === currentPage ? "default" : "outline"}
                        size="sm"
                        onClick={() => onPageChange(page)}
                        className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${
                          page === currentPage
                            ? "bg-primary text-white border-primary hover:bg-primary-dark"
                            : "border-gray-300 bg-white text-gray-700 hover:bg-gray-50"
                        }`}
                      >
                        {page}
                      </Button>
                    ))}
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onPageChange(currentPage + 1)}
                      disabled={currentPage === totalPages}
                      className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                    >
                      <span className="sr-only">Successiva</span>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </nav>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Sei sicuro di voler eliminare questa fattura?</AlertDialogTitle>
            <AlertDialogDescription>
              Questa azione non può essere annullata. La fattura verrà eliminata definitivamente dal sistema.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annulla</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-red-600 hover:bg-red-700">
              Elimina
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}