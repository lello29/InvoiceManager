import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Invoice, InvoiceItem, Client } from "@shared/schema";
import { StatusBadge } from "@/components/ui/status-badge";
import { Download, X, BrainCircuit, FileText } from "lucide-react";
import { formatDate, formatCurrency } from "@/lib/utils";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { InvoiceInsights } from "./invoice-insights";
import { useAuth } from "@/hooks/use-auth";
import { PdfViewer, PdfViewerButton } from "../pdf-viewer";
import { useState } from "react";

interface InvoiceModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  invoice: Invoice | null;
  items: InvoiceItem[];
  client?: Client;
  onViewPdf?: (invoice: Invoice) => void;
}

// Helper function to convert payment type code to readable name
function getPaymentTypeName(type: string): string {
  switch (type) {
    case 'bank_transfer':
      return 'Bonifico bancario';
    case 'credit_card':
      return 'Carta di credito';
    case 'cash':
      return 'Contanti';
    case 'paypal':
      return 'PayPal';
    default:
      return type;
  }
}

export function InvoiceModal({ open, onOpenChange, invoice, items, client, onViewPdf }: InvoiceModalProps) {
  if (!invoice) return null;
  
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [showPdfViewer, setShowPdfViewer] = useState(false);

  const handleDownload = () => {
    if (invoice.pdfPath) {
      // Utilizza l'endpoint ottimizzato per scaricare il PDF
      let downloadPath = invoice.pdfPath;
      
      // Correggi il percorso se non usa già il formato ottimizzato
      if (downloadPath.includes('/uploads/')) {
        const filename = downloadPath.split('/').pop();
        if (filename) {
          downloadPath = `/api/download-pdf/${filename}`;
        }
      } else if (downloadPath.startsWith('/api/view-pdf/')) {
        // Converti da visualizzazione a download se necessario
        const pathParts = downloadPath.split('/api/view-pdf/');
        if (pathParts.length > 1) {
          downloadPath = `/api/download-pdf/${pathParts[1]}`;
        }
      }
      
      window.open(downloadPath, '_blank');
    }
  };
  
  const handleViewPdf = () => {
    if (invoice.pdfPath) {
      // Assicuriamoci che il percorso inizi con / se non è un URL completo
      let path = invoice.pdfPath;
      if (!path.startsWith('http') && !path.startsWith('/')) {
        path = '/' + path;
      }
      console.log("Tentativo di apertura PDF:", path);
      
      // Correggi il percorso se usa il formato /api/view-pdf/ che è quello ottimizzato
      if (!path.startsWith('/api/view-pdf/') && path.includes('/uploads/')) {
        // Estrai il nome del file dal percorso
        const filename = path.split('/').pop();
        if (filename) {
          path = `/api/view-pdf/${filename}`;
          console.log("Percorso PDF convertito all'endpoint ottimizzato:", path);
        }
      }
      
      // Aggiorniamo il percorso nel caso abbia bisogno di correzioni
      invoice.pdfPath = path;
      
      // Se è fornita una funzione onViewPdf esterna, utilizziamola
      if (onViewPdf) {
        onViewPdf(invoice);
      } else {
        // Altrimenti utilizziamo il visualizzatore interno
        setShowPdfViewer(true);
      }
    } else if (onViewPdf) {
      // Se non c'è un percorso PDF ma esiste la funzione onViewPdf, deleghiamo a quella
      onViewPdf(invoice);
    } else {
      console.error("Nessun PDF disponibile e nessuna funzione onViewPdf fornita");
    }
  };

  return (
    <>
      {showPdfViewer && invoice.pdfPath && (
        <Dialog open={showPdfViewer} onOpenChange={setShowPdfViewer}>
          <DialogContent className="max-w-5xl w-[90vw] max-h-[90vh] p-0">
            <PdfViewer 
              pdfUrl={invoice.pdfPath} 
              className="h-[85vh]"
              downloadUrl={invoice.pdfPath}
              downloadFilename={invoice.pdfPath.split('/').pop() || "fattura.pdf"}
              onClose={() => setShowPdfViewer(false)}
            />
          </DialogContent>
        </Dialog>
      )}
      
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-4xl p-0 w-[95vw] max-h-[90vh] overflow-auto">
          <DialogHeader className="flex justify-between items-center px-6 py-4 bg-gray-50 border-b">
            <DialogTitle className="text-lg font-semibold text-gray-900">
              Dettagli Fattura - <span className="font-mono">{invoice.number}</span>
            </DialogTitle>
            <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)}>
              <X className="h-4 w-4" />
            </Button>
          </DialogHeader>

          <div className="px-6 py-4">
            {isAdmin ? (
              <Tabs defaultValue="details" className="w-full">
                <TabsList className="mb-6">
                  <TabsTrigger value="details">Dettagli Fattura</TabsTrigger>
                  <TabsTrigger value="insights" className="flex items-center">
                    <BrainCircuit className="w-4 h-4 mr-1" />
                    Analisi AI
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="details">
                  <div className="flex flex-col md:flex-row">
                    <div className="flex-1">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                        <div className="bg-gray-50 p-3 rounded">
                          <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Cliente</h4>
                          {client ? (
                            <>
                              <p className="text-sm font-medium">{client.name}</p>
                              <p className="text-xs text-gray-500">{client.email}</p>
                            </>
                          ) : (
                            <p className="text-sm text-gray-500">Informazioni cliente non disponibili</p>
                          )}
                        </div>
                        <div className="bg-gray-50 p-3 rounded">
                          <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Informazioni Fattura</h4>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <p className="text-xs text-gray-500">Emissione:</p>
                              <p className="text-sm">{formatDate(new Date(invoice.issueDate as any))}</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-500">Scadenza:</p>
                              <p className="text-sm">{formatDate(new Date(invoice.dueDate as any))}</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-500">Stato:</p>
                              <p className="text-sm">
                                <StatusBadge status={invoice.status} />
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-500">Pagamento:</p>
                              <p className="text-sm">{invoice.paymentType ? getPaymentTypeName(invoice.paymentType) : "Non specificato"}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      {items.length > 0 && (
                        <>
                          <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Dettaglio Voci</h4>
                          <div className="overflow-x-auto rounded border border-gray-200 bg-white">
                            <table className="min-w-full divide-y divide-gray-200 text-xs sm:text-sm">
                              <thead className="bg-gray-50">
                                <tr>
                                  <th scope="col" className="px-2 sm:px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Descrizione
                                  </th>
                                  <th scope="col" className="px-2 sm:px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Qtà
                                  </th>
                                  <th scope="col" className="px-2 sm:px-3 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Prezzo
                                  </th>
                                  <th scope="col" className="px-2 sm:px-3 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Totale
                                  </th>
                                </tr>
                              </thead>
                              <tbody className="bg-white divide-y divide-gray-100">
                                {items.map((item) => (
                                  <tr key={item.id} className="hover:bg-gray-50">
                                    <td className="px-2 sm:px-3 py-2 break-words text-xs sm:text-sm max-w-[140px] sm:max-w-none">
                                      {item.description}
                                    </td>
                                    <td className="px-2 sm:px-3 py-2 text-center text-xs sm:text-sm">
                                      {Number(item.quantity)}
                                    </td>
                                    <td className="px-2 sm:px-3 py-2 text-right text-xs sm:text-sm">
                                      {formatCurrency(Number(item.price))}
                                    </td>
                                    <td className="px-2 sm:px-3 py-2 text-right font-medium text-xs sm:text-sm">
                                      {formatCurrency(Number(item.total))}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                              <tfoot className="bg-gray-50">
                                <tr className="border-t border-gray-200">
                                  <td colSpan={2} className="px-2 sm:px-3 py-2"></td>
                                  <td className="px-2 sm:px-3 py-2 text-right text-xs sm:text-sm font-semibold">
                                    Totale
                                  </td>
                                  <td className="px-2 sm:px-3 py-2 text-right text-xs sm:text-sm font-semibold">
                                    {formatCurrency(Number(invoice.amount))}
                                  </td>
                                </tr>
                              </tfoot>
                            </table>
                          </div>
                        </>
                      )}
                    </div>
                    
                    <div className="mt-6 md:mt-0 md:ml-6 md:w-1/3">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Anteprima PDF</h4>
                        {invoice.pdfPath ? (
                          <div 
                            className="bg-white rounded border border-gray-300 h-80 flex items-center justify-center cursor-pointer hover:bg-gray-50 transition-colors"
                            onClick={handleViewPdf}
                          >
                            <div className="text-center">
                              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" className="h-16 w-16 mx-auto text-red-500 mb-2" fill="currentColor">
                                <path d="M181.9 256.1c-5-16-4.9-46.9-2-46.9 8.4 0 7.6 36.9 2 46.9zm-1.7 47.2c-7.7 20.2-17.3 43.3-28.4 62.7 18.3-7 39-17.2 62.9-21.9-12.7-9.6-24.9-23.4-34.5-40.8zM86.1 428.1c0 .8 13.2-5.4 34.9-40.2-6.7 6.3-29.1 24.5-34.9 40.2zM248 160h136v328c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V24C0 10.7 10.7 0 24 0h200v136c0 13.2 10.8 24 24 24zm-8 171.8c-20-12.2-33.3-29-42.7-53.8 4.5-18.5 11.6-46.6 6.2-64.2-4.7-29.4-42.4-26.5-47.8-6.8-5 18.3-.4 44.1 8.1 77-11.6 27.6-28.7 64.6-40.8 85.8-.1 0-.1.1-.2.1-27.1 13.9-73.6 44.5-54.5 68 5.6 6.9 16 10 21.5 10 17.9 0 35.7-18 61.1-61.8 25.8-8.5 54.1-19.1 79-23.2 21.7 11.8 47.1 19.5 64 19.5 29.2 0 31.2-32 19.7-43.4-13.9-13.6-54.3-9.7-73.6-7.2zM377 105L279 7c-4.5-4.5-10.6-7-17-7h-6v128h128v-6.1c0-6.3-2.5-12.4-7-16.9zm-74.1 255.3c4.1-2.7-2.5-11.9-42.8-9 37.1 15.8 42.8 9 42.8 9z"/>
                              </svg>
                              <p className="text-sm text-gray-600">{invoice.pdfPath.split('/').pop()}</p>
                              <p className="text-xs text-primary mt-2">Fai clic per visualizzare</p>
                            </div>
                          </div>
                        ) : (
                          <div className="bg-white rounded border border-gray-300 h-80 flex items-center justify-center">
                            <p className="text-gray-500">Nessun PDF disponibile</p>
                          </div>
                        )}
                      </div>
                      
                      {invoice.notes && (
                        <div className="mt-4 bg-gray-50 p-4 rounded-lg">
                          <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Note</h4>
                          <p className="text-sm text-gray-600">
                            {invoice.notes}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="insights">
                  <InvoiceInsights invoiceId={invoice.id} />
                </TabsContent>
              </Tabs>
            ) : (
              // Versione senza tab per i client (senza analisi AI)
              <div className="flex flex-col md:flex-row">
                <div className="flex-1">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                    <div className="bg-gray-50 p-3 rounded">
                      <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Cliente</h4>
                      {client ? (
                        <>
                          <p className="text-sm font-medium">{client.name}</p>
                          <p className="text-xs text-gray-500">{client.email}</p>
                        </>
                      ) : (
                        <p className="text-sm text-gray-500">Informazioni cliente non disponibili</p>
                      )}
                    </div>
                    <div className="bg-gray-50 p-3 rounded">
                      <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Informazioni Fattura</h4>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <p className="text-xs text-gray-500">Emissione:</p>
                          <p className="text-sm">{formatDate(new Date(invoice.issueDate as any))}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Scadenza:</p>
                          <p className="text-sm">{formatDate(new Date(invoice.dueDate as any))}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Stato:</p>
                          <p className="text-sm">
                            <StatusBadge status={invoice.status} />
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Pagamento:</p>
                          <p className="text-sm">{invoice.paymentType ? getPaymentTypeName(invoice.paymentType) : "Non specificato"}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {items.length > 0 && (
                    <>
                      <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Dettaglio Voci</h4>
                      <div className="overflow-x-auto rounded border border-gray-200 bg-white">
                        <table className="min-w-full divide-y divide-gray-200 text-xs sm:text-sm">
                          <thead className="bg-gray-50">
                            <tr>
                              <th scope="col" className="px-2 sm:px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Descrizione
                              </th>
                              <th scope="col" className="px-2 sm:px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Qtà
                              </th>
                              <th scope="col" className="px-2 sm:px-3 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Prezzo
                              </th>
                              <th scope="col" className="px-2 sm:px-3 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Totale
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-100">
                            {items.map((item) => (
                              <tr key={item.id} className="hover:bg-gray-50">
                                <td className="px-2 sm:px-3 py-2 break-words text-xs sm:text-sm max-w-[140px] sm:max-w-none">
                                  {item.description}
                                </td>
                                <td className="px-2 sm:px-3 py-2 text-center text-xs sm:text-sm">
                                  {Number(item.quantity)}
                                </td>
                                <td className="px-2 sm:px-3 py-2 text-right text-xs sm:text-sm">
                                  {formatCurrency(Number(item.price))}
                                </td>
                                <td className="px-2 sm:px-3 py-2 text-right font-medium text-xs sm:text-sm">
                                  {formatCurrency(Number(item.total))}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                          <tfoot className="bg-gray-50">
                            <tr className="border-t border-gray-200">
                              <td colSpan={2} className="px-2 sm:px-3 py-2"></td>
                              <td className="px-2 sm:px-3 py-2 text-right text-xs sm:text-sm font-semibold">
                                Totale
                              </td>
                              <td className="px-2 sm:px-3 py-2 text-right text-xs sm:text-sm font-semibold">
                                {formatCurrency(Number(invoice.amount))}
                              </td>
                            </tr>
                          </tfoot>
                        </table>
                      </div>
                    </>
                  )}
                </div>
                
                <div className="mt-6 md:mt-0 md:ml-6 md:w-1/3">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Anteprima PDF</h4>
                    {invoice.pdfPath ? (
                      <div 
                        className="bg-white rounded border border-gray-300 h-80 flex items-center justify-center cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={handleViewPdf}
                      >
                        <div className="text-center">
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" className="h-16 w-16 mx-auto text-red-500 mb-2" fill="currentColor">
                            <path d="M181.9 256.1c-5-16-4.9-46.9-2-46.9 8.4 0 7.6 36.9 2 46.9zm-1.7 47.2c-7.7 20.2-17.3 43.3-28.4 62.7 18.3-7 39-17.2 62.9-21.9-12.7-9.6-24.9-23.4-34.5-40.8zM86.1 428.1c0 .8 13.2-5.4 34.9-40.2-6.7 6.3-29.1 24.5-34.9 40.2zM248 160h136v328c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V24C0 10.7 10.7 0 24 0h200v136c0 13.2 10.8 24 24 24zm-8 171.8c-20-12.2-33.3-29-42.7-53.8 4.5-18.5 11.6-46.6 6.2-64.2-4.7-29.4-42.4-26.5-47.8-6.8-5 18.3-.4 44.1 8.1 77-11.6 27.6-28.7 64.6-40.8 85.8-.1 0-.1.1-.2.1-27.1 13.9-73.6 44.5-54.5 68 5.6 6.9 16 10 21.5 10 17.9 0 35.7-18 61.1-61.8 25.8-8.5 54.1-19.1 79-23.2 21.7 11.8 47.1 19.5 64 19.5 29.2 0 31.2-32 19.7-43.4-13.9-13.6-54.3-9.7-73.6-7.2zM377 105L279 7c-4.5-4.5-10.6-7-17-7h-6v128h128v-6.1c0-6.3-2.5-12.4-7-16.9zm-74.1 255.3c4.1-2.7-2.5-11.9-42.8-9 37.1 15.8 42.8 9 42.8 9z"/>
                          </svg>
                          <p className="text-sm text-gray-600">{invoice.pdfPath.split('/').pop()}</p>
                          <p className="text-xs text-primary mt-2">Fai clic per visualizzare</p>
                        </div>
                      </div>
                    ) : (
                      <div className="bg-white rounded border border-gray-300 h-80 flex items-center justify-center">
                        <p className="text-gray-500">Nessun PDF disponibile</p>
                      </div>
                    )}
                  </div>
                  
                  {invoice.notes && (
                    <div className="mt-4 bg-gray-50 p-4 rounded-lg">
                      <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Note</h4>
                      <p className="text-sm text-gray-600">
                        {invoice.notes}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          <DialogFooter className="px-6 py-4 bg-gray-50 border-t flex flex-col sm:flex-row w-full gap-2">
            {invoice.pdfPath && (
              <>
                <Button 
                  className="w-full sm:w-auto order-1 sm:order-none" 
                  onClick={handleDownload}
                >
                  <Download className="mr-2 h-4 w-4" />
                  Scarica PDF
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full sm:w-auto order-2 sm:order-none" 
                  onClick={handleViewPdf}
                >
                  <FileText className="mr-2 h-4 w-4" />
                  Visualizza PDF
                </Button>
              </>
            )}
            <Button 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              className="w-full sm:w-auto order-3 sm:order-none"
            >
              Chiudi
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}