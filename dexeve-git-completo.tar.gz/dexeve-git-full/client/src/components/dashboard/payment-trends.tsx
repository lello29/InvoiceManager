import { usePaymentTrends } from "@/hooks/use-ai-insights";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { 
  Loader2, AlertTriangle, BarChart4, Clock, 
  TrendingUp, AlertCircle, CheckSquare 
} from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

interface PaymentTrendsProps {
  clientId?: number;
  className?: string;
}

export function PaymentTrends({ clientId, className }: PaymentTrendsProps) {
  const {
    data: trends,
    isLoading,
    isError,
    error
  } = usePaymentTrends(clientId);

  if (isError) {
    return (
      <Alert variant="destructive" className={className}>
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Errore nell'analisi delle tendenze</AlertTitle>
        <AlertDescription>
          {error?.message || 
           "Si è verificato un errore durante l'analisi delle tendenze di pagamento. Riprova più tardi."}
        </AlertDescription>
      </Alert>
    );
  }

  if (isLoading) {
    return (
      <Card className={cn("w-full", className)}>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            Analisi delle tendenze in corso...
          </CardTitle>
          <CardDescription>
            L'intelligenza artificiale sta analizzando le tendenze di pagamento di questo cliente...
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-[90%]" />
          <Skeleton className="h-4 w-[75%]" />
          <Separator className="my-2" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-[85%]" />
          <Skeleton className="h-4 w-[65%]" />
        </CardContent>
      </Card>
    );
  }

  if (!trends) {
    return null;
  }

  // Determina il colore per il profilo di rischio
  const getRiskColor = (risk: string): "default" | "red" | "yellow" | "green" => {
    const lowerRisk = risk.toLowerCase();
    if (lowerRisk.includes("alto") || lowerRisk.includes("high")) return "red";
    if (lowerRisk.includes("medio") || lowerRisk.includes("medium")) return "yellow";
    if (lowerRisk.includes("basso") || lowerRisk.includes("low")) return "green";
    return "default";
  };

  return (
    <Card className={cn("w-full", className)}>
      <CardHeader>
        <CardTitle className="text-primary">Analisi delle Tendenze di Pagamento</CardTitle>
        <CardDescription>
          Tendenze e pattern di pagamento identificati dall'intelligenza artificiale
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Riepilogo delle tendenze */}
        <div>
          <h3 className="font-semibold text-lg mb-2 flex items-center">
            <BarChart4 className="h-4 w-4 mr-2 text-primary" />
            Riepilogo delle Tendenze
          </h3>
          <p className="text-sm text-muted-foreground">{trends.trendSummary}</p>
        </div>

        {/* Tempi di pagamento */}
        <div className="bg-secondary/30 p-4 rounded-lg">
          <h3 className="font-semibold text-lg mb-2 flex items-center">
            <Clock className="h-4 w-4 mr-2 text-primary" />
            Tempi di Pagamento
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <span className="text-sm text-muted-foreground block mb-1">Tempo medio di pagamento</span>
              <div className="flex items-center">
                <span className="text-xl font-bold">{trends.averagePaymentTime}</span>
                <span className="ml-1 text-sm text-muted-foreground">giorni</span>
              </div>
              
              {/* Visualizzatore grafico */}
              <div className="mt-2">
                <Progress 
                  value={Math.min(100, (trends.averagePaymentTime / 30) * 100)} 
                  className="h-2" 
                />
                <div className="flex justify-between text-xs mt-1">
                  <span>0</span>
                  <span>15</span>
                  <span>30+</span>
                </div>
              </div>
            </div>
            
            <div>
              <span className="text-sm text-muted-foreground block mb-1">Profilo di rischio</span>
              <Badge variant={getRiskColor(trends.riskProfile) as any}>
                {trends.riskProfile}
              </Badge>
            </div>
          </div>
        </div>

        {/* Schemi di pagamento */}
        <div>
          <h3 className="font-semibold text-lg mb-2 flex items-center">
            <TrendingUp className="h-4 w-4 mr-2 text-primary" />
            Schemi di Pagamento
          </h3>
          <p className="text-sm text-muted-foreground">{trends.paymentPatterns}</p>
        </div>

        {/* Raccomandazioni */}
        <div>
          <h3 className="font-semibold text-lg mb-2 flex items-center">
            <CheckSquare className="h-4 w-4 mr-2 text-primary" />
            Raccomandazioni
          </h3>
          {Array.isArray(trends.recommendations) ? (
            <ul className="list-disc pl-5 space-y-1">
              {trends.recommendations.map((rec: string, i: number) => (
                <li key={i} className="text-sm text-muted-foreground">{rec}</li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-muted-foreground">{trends.recommendations}</p>
          )}
        </div>
      </CardContent>
      <CardFooter className="text-xs text-muted-foreground">
        Generato dall'intelligenza artificiale. I valori potrebbero variare in base ai dati storici disponibili.
      </CardFooter>
    </Card>
  );
}