import { usePendingPaymentsReport } from "@/hooks/use-ai-insights";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { 
  Loader2, AlertTriangle, DollarSign, 
  ListTodo, PieChart, ArrowUpCircle
} from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { formatCurrency } from "@/lib/utils";
import { cn } from "@/lib/utils";

export function PendingPaymentsReport({ className }: { className?: string }) {
  const {
    data: report,
    isLoading,
    isError,
    error
  } = usePendingPaymentsReport();

  if (isError) {
    return (
      <Alert variant="destructive" className={className}>
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Errore nella generazione del report</AlertTitle>
        <AlertDescription>
          {error?.message || 
           "Si è verificato un errore durante la generazione del report sui pagamenti in sospeso. Riprova più tardi."}
        </AlertDescription>
      </Alert>
    );
  }

  if (isLoading) {
    return (
      <Card className={cn("w-full", className)}>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            Generazione del report in corso...
          </CardTitle>
          <CardDescription>
            L'intelligenza artificiale sta analizzando i pagamenti in sospeso...
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-[90%]" />
          <Skeleton className="h-4 w-[75%]" />
          <Separator className="my-2" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-[85%]" />
          <Skeleton className="h-4 w-[65%]" />
        </CardContent>
      </Card>
    );
  }

  if (!report) {
    return null;
  }

  // Parse il valore totale se è una stringa, altrimenti usa il valore direttamente
  const totalValue = typeof report.totalValue === 'string' 
    ? parseFloat(report.totalValue.replace(/[^\d.-]/g, '')) 
    : report.totalValue;

  return (
    <Card className={cn("w-full", className)}>
      <CardHeader>
        <CardTitle className="text-primary">Report dei Pagamenti in Sospeso</CardTitle>
        <CardDescription>
          Analisi e prioritizzazione dei pagamenti in sospeso
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Riepilogo del report */}
        <div>
          <h3 className="font-semibold text-lg mb-2 flex items-center">
            <PieChart className="h-4 w-4 mr-2 text-primary" />
            Riepilogo
          </h3>
          <p className="text-sm text-muted-foreground">{report.reportSummary}</p>
          
          <div className="mt-4 bg-secondary/30 p-3 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Valore totale in sospeso:</span>
              <span className="text-lg font-bold">{formatCurrency(totalValue)}</span>
            </div>
          </div>
        </div>

        {/* Fatture ad alto rischio */}
        <div>
          <h3 className="font-semibold text-lg mb-2 flex items-center">
            <AlertTriangle className="h-4 w-4 mr-2 text-primary" />
            Fatture ad Alto Rischio
          </h3>
          {Array.isArray(report.highRiskInvoices) && report.highRiskInvoices.length > 0 ? (
            <ul className="space-y-2">
              {report.highRiskInvoices.map((invoice: any, index: number) => (
                <li key={index} className="text-sm border-l-2 border-destructive pl-3 py-1">
                  {typeof invoice === 'string' ? (
                    <div>{invoice}</div>
                  ) : (
                    <div>
                      <div className="font-medium">{invoice.client || invoice.number || `Fattura #${index + 1}`}</div>
                      {invoice.amount && <div>{formatCurrency(invoice.amount)}</div>}
                      {invoice.reason && <div className="text-muted-foreground">{invoice.reason}</div>}
                    </div>
                  )}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-muted-foreground">
              {typeof report.highRiskInvoices === 'string' 
                ? report.highRiskInvoices 
                : "Nessuna fattura ad alto rischio identificata."}
            </p>
          )}
        </div>

        {/* Priorità di follow-up */}
        <div>
          <h3 className="font-semibold text-lg mb-2 flex items-center">
            <ListTodo className="h-4 w-4 mr-2 text-primary" />
            Priorità di Follow-up
          </h3>
          {Array.isArray(report.followUpPriorities) && report.followUpPriorities.length > 0 ? (
            <ol className="list-decimal pl-5 space-y-1">
              {report.followUpPriorities.map((priority: any, i: number) => (
                <li key={i} className="text-sm text-muted-foreground">
                  {typeof priority === 'string' ? priority : priority.description}
                </li>
              ))}
            </ol>
          ) : (
            <p className="text-sm text-muted-foreground">{report.followUpPriorities}</p>
          )}
        </div>

        {/* Strategie di recupero */}
        <div>
          <h3 className="font-semibold text-lg mb-2 flex items-center">
            <ArrowUpCircle className="h-4 w-4 mr-2 text-primary" />
            Strategie di Recupero
          </h3>
          {Array.isArray(report.recoveryStrategies) && report.recoveryStrategies.length > 0 ? (
            <ul className="list-disc pl-5 space-y-1">
              {report.recoveryStrategies.map((strategy: string, i: number) => (
                <li key={i} className="text-sm text-muted-foreground">{strategy}</li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-muted-foreground">{report.recoveryStrategies}</p>
          )}
        </div>
      </CardContent>
      <CardFooter className="text-xs text-muted-foreground">
        Generato dall'intelligenza artificiale in base ai dati disponibili al momento della richiesta.
      </CardFooter>
    </Card>
  );
}