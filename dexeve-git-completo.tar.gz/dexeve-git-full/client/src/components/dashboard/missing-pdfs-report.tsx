import React from 'react';
import { useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Loader2, AlertTriangle, CheckCircle, Upload } from 'lucide-react';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

// Funzione di utility per il caricamento dei PDF
const useInvoiceUpload = () => {
  const { toast } = useToast();
  const [uploading, setUploading] = React.useState<number | null>(null);

  const uploadPdfs = async (invoiceId: number, files: FileList) => {
    if (!files || files.length === 0) {
      throw new Error("Nessun file selezionato");
    }
    
    setUploading(invoiceId);
    
    try {
      const formData = new FormData();
      
      // Per questo endpoint serve un singolo file chiamato "pdf"
      formData.append('pdf', files[0]);
      
      const response = await fetch(`/api/admin/invoices/pdf-upload/${invoiceId}`, {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Errore durante il caricamento del PDF');
      }
      
      const result = await response.json();
      
      // Invalida la cache delle fatture dopo il caricamento
      queryClient.invalidateQueries({ queryKey: ['/api/invoices'] });
      queryClient.invalidateQueries({ queryKey: ['/api/invoices', invoiceId] });
      
      return result;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Errore sconosciuto durante il caricamento';
      throw err;
    } finally {
      setUploading(null);
    }
  };
  
  return {
    uploadPdfs,
    isUploading: !!uploading,
    uploadingId: uploading
  };
};

interface MissingPdfReport {
  hasMissingPdfs: boolean;
  missingCount: number;
  analysis: string;
  recommendedActions?: string[];
  invoicesWithMissingPdf: {
    id: number;
    number: string;
    issueDate: string;
    clientId: number;
    clientName: string;
    pdfPath: string;
  }[];
  urgencyLevel?: 'Bassa' | 'Media' | 'Alta';
}

export function MissingPdfsReport() {
  const { toast } = useToast();
  const { uploadPdfs } = useInvoiceUpload();
  const [selectedInvoice, setSelectedInvoice] = React.useState<number | null>(null);

  const {
    mutate: fetchMissingPdfsReport,
    data: report,
    isPending,
    isError,
    error
  } = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('GET', '/api/admin/missing-pdfs-report');
      const data = await res.json();
      return data as MissingPdfReport;
    },
    onError: (error: Error) => {
      toast({
        title: 'Errore',
        description: `Impossibile recuperare il report: ${error.message}`,
        variant: 'destructive'
      });
    }
  });

  const handleFileUpload = async (invoiceId: number, files: FileList | null) => {
    if (!files || files.length === 0) return;
    
    setSelectedInvoice(invoiceId);
    try {
      // Mostra notifica di inizio caricamento
      toast({
        title: 'Caricamento in corso...',
        description: 'Stiamo elaborando il tuo file PDF',
        variant: 'default'
      });
      
      await uploadPdfs(invoiceId, files);
      
      toast({
        title: 'PDF caricato con successo',
        description: 'Il PDF è stato associato alla fattura',
        variant: 'default'
      });
      
      // Aggiungiamo un piccolo ritardo per assicurarci che il server abbia tempo di processare il file
      setTimeout(() => {
        // Refresh the report after upload
        fetchMissingPdfsReport();
      }, 1000);
    } catch (error) {
      console.error("Errore durante il caricamento del PDF:", error);
      toast({
        title: 'Errore di caricamento',
        description: error instanceof Error ? error.message : 'Errore sconosciuto',
        variant: 'destructive'
      });
    } finally {
      setSelectedInvoice(null);
    }
  };

  React.useEffect(() => {
    fetchMissingPdfsReport();
  }, []);

  if (isPending) {
    return (
      <Card className="w-full mt-4">
        <CardHeader>
          <CardTitle>Analisi Fatture con PDF Mancanti</CardTitle>
          <CardDescription>Verifica in corso...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center items-center py-8">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  if (isError) {
    return (
      <Card className="w-full mt-4">
        <CardHeader>
          <CardTitle>Analisi Fatture con PDF Mancanti</CardTitle>
          <CardDescription>Si è verificato un errore</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Errore</AlertTitle>
            <AlertDescription>
              {error instanceof Error ? error.message : 'Errore sconosciuto'}
            </AlertDescription>
          </Alert>
          <Button
            onClick={() => fetchMissingPdfsReport()}
            className="mt-4"
          >
            Riprova
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (!report) {
    return null;
  }

  const getUrgencyColor = (level?: string) => {
    switch (level) {
      case 'Alta':
        return 'bg-red-500';
      case 'Media':
        return 'bg-yellow-500';
      case 'Bassa':
        return 'bg-blue-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <Card className="w-full mt-4">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle>Analisi Fatture con PDF Mancanti</CardTitle>
            <CardDescription>
              {report.hasMissingPdfs 
                ? `${report.missingCount} fatture senza PDF` 
                : 'Tutte le fatture hanno i PDF correttamente associati'}
            </CardDescription>
          </div>
          {report.urgencyLevel && (
            <Badge className={`${getUrgencyColor(report.urgencyLevel)} text-white`}>
              Urgenza: {report.urgencyLevel}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {!report.hasMissingPdfs ? (
          <Alert variant="default" className="bg-green-50 border-green-200">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertTitle className="text-green-800">Tutto a posto!</AlertTitle>
            <AlertDescription className="text-green-700">
              {report.analysis}
            </AlertDescription>
          </Alert>
        ) : (
          <>
            <Alert variant="default" className="bg-yellow-50 border-yellow-200 mb-6">
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
              <AlertTitle className="text-yellow-800">Attenzione</AlertTitle>
              <AlertDescription className="text-yellow-700">
                {report.analysis}
              </AlertDescription>
            </Alert>

            {report.recommendedActions && report.recommendedActions.length > 0 && (
              <div className="mb-6">
                <h3 className="text-md font-semibold mb-2">Azioni consigliate:</h3>
                <ul className="list-disc pl-5 space-y-1">
                  {report.recommendedActions.map((action, index) => (
                    <li key={index} className="text-sm text-gray-700">{action}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="mb-4">
              <h3 className="text-md font-semibold mb-2">Fatture senza PDF:</h3>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">Numero</th>
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">Data</th>
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">Cliente</th>
                      <th className="px-4 py-2 text-center text-sm font-medium text-gray-600">Azioni</th>
                    </tr>
                  </thead>
                  <tbody>
                    {report.invoicesWithMissingPdf.map((invoice) => (
                      <tr key={invoice.id} className="border-t border-gray-200">
                        <td className="px-4 py-3 text-sm">{invoice.number}</td>
                        <td className="px-4 py-3 text-sm">{invoice.issueDate ? new Date(invoice.issueDate).toLocaleDateString('it-IT') : '-'}</td>
                        <td className="px-4 py-3 text-sm">{invoice.clientName}</td>
                        <td className="px-4 py-3 text-center">
                          <div className="relative inline-block">
                            <input
                              type="file"
                              id={`pdf-upload-${invoice.id}`}
                              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                              accept=".pdf"
                              onChange={(e) => handleFileUpload(invoice.id, e.target.files)}
                              disabled={selectedInvoice === invoice.id}
                            />
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="text-xs"
                              disabled={selectedInvoice === invoice.id}
                            >
                              {selectedInvoice === invoice.id ? (
                                <>
                                  <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                                  Caricamento...
                                </>
                              ) : (
                                <>
                                  <Upload className="h-3 w-3 mr-1" />
                                  Carica PDF
                                </>
                              )}
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="flex justify-end mt-4">
              <Button 
                onClick={() => fetchMissingPdfsReport()} 
                variant="outline"
                className="text-sm"
              >
                Aggiorna analisi
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}