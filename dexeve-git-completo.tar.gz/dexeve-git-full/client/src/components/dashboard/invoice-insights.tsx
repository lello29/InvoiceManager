import { useInvoiceInsights, usePaymentProbability } from "@/hooks/use-ai-insights";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Loader2, AlertTriangle, Check, HelpCircle, Info, TrendingUp, TrendingDown } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { cn } from "@/lib/utils";

interface InvoiceInsightsProps {
  invoiceId?: number;
  className?: string;
}

export function InvoiceInsights({ invoiceId, className }: InvoiceInsightsProps) {
  const {
    data: insights,
    isLoading: insightsLoading,
    isError: insightsError,
    error: insightsErrorDetails
  } = useInvoiceInsights(invoiceId);

  const {
    data: probability,
    isLoading: probabilityLoading,
    isError: probabilityError,
    error: probabilityErrorDetails
  } = usePaymentProbability(invoiceId);

  if (insightsError || probabilityError) {
    return (
      <Alert variant="destructive" className={className}>
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Errore nell'analisi AI</AlertTitle>
        <AlertDescription>
          {insightsErrorDetails?.message || probabilityErrorDetails?.message || 
           "Si è verificato un errore durante l'analisi della fattura. Riprova più tardi."}
        </AlertDescription>
      </Alert>
    );
  }

  if (insightsLoading || probabilityLoading) {
    return (
      <Card className={cn("w-full", className)}>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            Analisi AI in corso...
          </CardTitle>
          <CardDescription>
            L'intelligenza artificiale sta analizzando questa fattura e il profilo del cliente...
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-[90%]" />
          <Skeleton className="h-4 w-[75%]" />
          <Separator className="my-2" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-[85%]" />
          <Skeleton className="h-4 w-[65%]" />
        </CardContent>
      </Card>
    );
  }

  if (!insights || !probability) {
    return null;
  }

  // Ottiene il colore appropriato per il badge della probabilità di pagamento
  const getProbabilityColor = (prob: number) => {
    if (prob >= 0.8) return "green";
    if (prob >= 0.5) return "yellow";
    return "red";
  };

  const probabilityColor = getProbabilityColor(probability.paymentProbability);

  return (
    <Card className={cn("w-full", className)}>
      <CardHeader>
        <CardTitle className="text-primary">Analisi AI della Fattura</CardTitle>
        <CardDescription>
          Insights generati dall'intelligenza artificiale per questa fattura
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Riepilogo */}
        <div>
          <h3 className="font-semibold text-lg mb-2 flex items-center">
            <Info className="h-4 w-4 mr-2 text-primary" />
            Riepilogo
          </h3>
          <p className="text-sm text-muted-foreground">{insights.summary}</p>
        </div>

        {/* Analisi del pagamento */}
        <div>
          <h3 className="font-semibold text-lg mb-2 flex items-center">
            <TrendingUp className="h-4 w-4 mr-2 text-primary" />
            Analisi del Pagamento
          </h3>
          <p className="text-sm text-muted-foreground">{insights.paymentInsight}</p>
        </div>

        {/* Valutazione del rischio */}
        <div>
          <h3 className="font-semibold text-lg mb-2 flex items-center">
            <AlertTriangle className="h-4 w-4 mr-2 text-primary" />
            Valutazione del Rischio
          </h3>
          <p className="text-sm text-muted-foreground">{insights.riskAssessment}</p>
        </div>

        {/* Previsione di pagamento */}
        <div className="bg-secondary/30 p-4 rounded-lg">
          <h3 className="font-semibold text-lg mb-3 flex items-center">
            <HelpCircle className="h-4 w-4 mr-2 text-primary" />
            Previsione di Pagamento
          </h3>
          
          <div className="grid grid-cols-2 gap-4 mb-3">
            <div>
              <span className="text-sm text-muted-foreground block">Probabilità di pagamento</span>
              <Badge variant={probabilityColor as any} className="mt-1">
                {(probability.paymentProbability * 100).toFixed(0)}%
              </Badge>
            </div>
            <div>
              <span className="text-sm text-muted-foreground block">Data prevista</span>
              <span className="font-medium">{new Date(probability.expectedPaymentDate).toLocaleDateString()}</span>
            </div>
          </div>
          
          <div className="mt-3">
            <span className="text-sm text-muted-foreground block mb-1">Fattori di rischio</span>
            <div className="flex flex-wrap gap-1">
              {Array.isArray(probability.riskFactors) ? (
                probability.riskFactors.map((factor: string, i: number) => (
                  <Badge key={i} variant="outline">{factor}</Badge>
                ))
              ) : (
                <span className="text-sm">{probability.riskFactors}</span>
              )}
            </div>
          </div>
        </div>

        {/* Raccomandazioni */}
        <div>
          <h3 className="font-semibold text-lg mb-2 flex items-center">
            <Check className="h-4 w-4 mr-2 text-primary" />
            Raccomandazioni
          </h3>
          {Array.isArray(insights.recommendations) ? (
            <ul className="list-disc pl-5 space-y-1">
              {insights.recommendations.map((rec: string, i: number) => (
                <li key={i} className="text-sm text-muted-foreground">{rec}</li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-muted-foreground">{insights.recommendations}</p>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between text-xs text-muted-foreground">
        <div>Generato dall'intelligenza artificiale</div>
        <div className="flex items-center">
          <div>Livello di confidenza: {(probability.confidenceScore * 100).toFixed(0)}%</div>
        </div>
      </CardFooter>
    </Card>
  );
}