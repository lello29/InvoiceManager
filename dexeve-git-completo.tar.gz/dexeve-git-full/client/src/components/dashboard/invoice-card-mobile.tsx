import { useState, useEffect } from "react";
import { Invoice, InvoiceWithClient } from "@shared/schema";
import { formatDate, formatCurrency, getSafeDateValue } from "@/lib/utils";
import { ChevronDown, ChevronUp, FileText, Download, AlertCircle, Loader2 } from "lucide-react";
import { StatusBadge } from "@/components/ui/status-badge";
import { Button } from "@/components/ui/button";
import { EditableCell } from "@/components/ui/editable-cell";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface InvoiceCardMobileProps {
  invoice: Invoice | InvoiceWithClient;
  onView: (invoice: Invoice | InvoiceWithClient) => void;
  onEdit?: (invoice: Invoice | InvoiceWithClient) => void;
  onUpdateInvoice?: (id: number, field: string, value: string | null) => void;
}

export function InvoiceCardMobile({ invoice, onView, onEdit, onUpdateInvoice }: InvoiceCardMobileProps) {
  const [expanded, setExpanded] = useState(false);
  const { toast } = useToast();
  const isAdmin = !!onEdit; // Se onEdit è definito, siamo in modalità admin

  // Check if invoice has client property (InvoiceWithClient)
  const hasClient = 'client' in invoice;
  
  // Funzione per gestire il download diretto del PDF
  const handleDownloadPdf = async (invoice: Invoice | InvoiceWithClient) => {
    if (!invoice.pdfPath) {
      toast({
        title: "PDF non disponibile",
        description: "Il documento PDF per questa fattura non è disponibile",
        variant: "destructive"
      });
      return;
    }
    
    // Assicuriamoci che il percorso inizi con / se non è un URL completo
    let path = invoice.pdfPath || '';
    if (path && !path.startsWith('http') && !path.startsWith('/')) {
      path = '/' + path;
    }
    
    // Prima verifichiamo che il file esista fisicamente
    try {
      // Effettua una richiesta HEAD per verificare se il file esiste
      // Aggiungiamo timestamp e header per evitare caching
      const nocacheUrl = `${path}${path.includes('?') ? '&' : '?'}_t=${Date.now()}`;
      
      const verifyResponse = await fetch(nocacheUrl, {
        method: 'HEAD',
        headers: { 'Pragma': 'no-cache', 'Cache-Control': 'no-cache' }
      });
      
      if (!verifyResponse.ok) {
        // Il file non esiste, notifica l'utente
        toast({
          title: "PDF non trovato",
          description: "Il file PDF è registrato nel database ma non è stato trovato sul server",
          variant: "destructive"
        });
        
        return;
      }
    } catch (error) {
      console.error("Errore nella verifica del PDF:", error);
      toast({
        title: "Errore nella verifica",
        description: "Non è stato possibile verificare l'esistenza del file PDF",
        variant: "destructive"
      });
      return;
    }
    
    // Usa il nuovo endpoint secure-pdf con parametro di download
    // Estrai il nome del file dal percorso originale
    const fileName = path.split('/').pop() || '';
    
    // Usa il nuovo endpoint secure-pdf con parametro di download
    // Aggiungiamo l'ID della fattura per ottenere un nome file descrittivo con i dati corretti
    path = `/api/secure-pdf/${encodeURIComponent(fileName)}?download=true&invoiceId=${invoice.id}&_t=${Date.now()}`;
    console.log("Download PDF con percorso (mobile):", path);
    
    // Creiamo un link temporaneo per il download
    const link = document.createElement('a');
    link.href = path;
    // Il nome del file sarà generato lato server, qui non impostiamo link.download
    // per permettere al server di definire il nome file
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Download avviato",
      description: "Il download del PDF è stato avviato"
    });
  };
  
  // Funzione di aggiornamento inline
  const updateInvoice = useMutation({
    mutationFn: async ({ id, field, value }: { id: number; field: string; value: string | null }) => {
      console.log(`InvoiceCardMobile - Aggiornamento: id=${id}, field=${field}, value=${value}`);
      // Converti i numeri in formato stringa quando necessario
      const finalValue = typeof value === 'number' ? String(value) : value;
      const response = await apiRequest("PATCH", `/api/admin/invoices/${id}`, { field, value: finalValue });
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Fattura aggiornata",
        description: "Il valore è stato aggiornato con successo.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/invoices'] });
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: `Impossibile aggiornare il valore: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Handler per l'aggiornamento inline
  const handleUpdateField = (field: string, value: string | null) => {
    // Per tutti i campi, incluse le date, usiamo il valore così com'è
    // La conversione verrà gestita dal server
    // Converti in stringa se è un numero
    const stringValue = typeof value === 'number' ? String(value) : value;
    
    if (onUpdateInvoice) {
      onUpdateInvoice(invoice.id, field, stringValue);
    } else {
      updateInvoice.mutate({ id: invoice.id, field, value: stringValue });
    }
  };
  
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden border mb-3">
      <div 
        className="p-4 flex items-center justify-between cursor-pointer"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center">
          <div 
            className="mr-3 p-2 rounded-full bg-primary/10 active:bg-primary/20"
            onClick={(e) => {
              e.stopPropagation();
              onView(invoice);
            }}
          >
            <FileText className="h-5 w-5 text-primary" />
          </div>
          <div>
            <div className="font-medium text-gray-900">
              {isAdmin ? (
                <EditableCell 
                  value={invoice.number} 
                  onChange={(value) => handleUpdateField("number", value)}
                  className="font-medium text-gray-900"
                />
              ) : (
                invoice.number
              )}
            </div>
            <div className="text-sm text-gray-500">
              {hasClient && (invoice as InvoiceWithClient).client ? 
                (invoice as InvoiceWithClient).client.name : 
                formatDate(new Date(invoice.issueDate))}
            </div>
          </div>
        </div>
        <div className="flex flex-col items-end">
          <div className="font-semibold text-gray-900">
            {isAdmin ? (
              <EditableCell 
                value={String(invoice.amount)} 
                onChange={(value) => handleUpdateField("amount", value)}
                type="text"
                className="font-semibold text-right"
              />
            ) : (
              formatCurrency(Number(invoice.amount))
            )}
          </div>
          {isAdmin ? (
            <EditableCell 
              value={invoice.status} 
              onChange={(value) => handleUpdateField("status", value)}
              type="select"
              options={[
                { value: "pending", label: "In attesa" },
                { value: "paid", label: "Pagata" },
                { value: "overdue", label: "Scaduta" },
                { value: "cancelled", label: "Annullata" }
              ]}
            />
          ) : (
            <StatusBadge status={invoice.status} />
          )}
        </div>
      </div>
      
      {expanded && (
        <div className="px-4 pb-4 pt-1 border-t border-gray-100">
          <div className="grid grid-cols-2 gap-2 mb-3">
            <div className="text-sm">
              <div className="text-gray-500">Data emissione</div>
              <div>
                {isAdmin ? (
                  <EditableCell 
                    value={getSafeDateValue(invoice.issueDate)} 
                    onChange={(value) => handleUpdateField("issueDate", value)}
                    type="date"
                  />
                ) : (
                  formatDate(new Date(invoice.issueDate as any))
                )}
              </div>
            </div>
            <div className="text-sm">
              <div className="text-gray-500">Data scadenza</div>
              <div>
                {isAdmin ? (
                  <EditableCell 
                    value={getSafeDateValue(invoice.dueDate)} 
                    onChange={(value) => handleUpdateField("dueDate", value)}
                    type="date"
                  />
                ) : (
                  formatDate(new Date(invoice.dueDate as any))
                )}
              </div>
            </div>
            <div className="text-sm">
              <div className="text-gray-500">Data pagamento</div>
              <div>
                {isAdmin ? (
                  <EditableCell 
                    value={invoice.paymentDate ? getSafeDateValue(invoice.paymentDate) : ''} 
                    onChange={(value) => handleUpdateField("paymentDate", value)}
                    type="date"
                    placeholder="Non impostata"
                  />
                ) : (
                  invoice.paymentDate ? formatDate(new Date(invoice.paymentDate as any)) : <span className="text-gray-400">Non impostata</span>
                )}
              </div>
            </div>
            <div className="text-sm">
              <div className="text-gray-500">Tipo pagamento</div>
              <div>
                {isAdmin ? (
                  <EditableCell 
                    value={invoice.paymentType || ''} 
                    onChange={(value) => handleUpdateField("paymentType", value)}
                    type="select"
                    options={[
                      { value: "", label: "Seleziona tipo pagamento" },
                      { value: "bank_transfer", label: "Bonifico bancario" },
                      { value: "credit_card", label: "Carta di credito" },
                      { value: "cash", label: "Contanti" },
                      { value: "paypal", label: "PayPal" }
                    ]}
                    placeholder="Non specificato"
                  />
                ) : (
                  invoice.paymentType ? getPaymentTypeName(invoice.paymentType) : <span className="text-gray-400">Non specificato</span>
                )}
              </div>
            </div>
          </div>
          
          <div className="flex gap-2 mt-3">
            <Button size="sm" variant="default" className="flex-1" onClick={() => onView(invoice)}>
              Visualizza
            </Button>
            {onEdit && (
              <Button size="sm" variant="outline" className="flex-1" onClick={() => onEdit(invoice)}>
                Modifica
              </Button>
            )}
            {/* Pulsante di download PDF con verifica */}
            <PdfDownloadButtonMobile invoice={invoice} onDownload={handleDownloadPdf} />
          </div>
        </div>
      )}
    </div>
  );
}

// Componente per gestire il pulsante di download con verifica di esistenza del file - versione mobile
interface PdfDownloadButtonMobileProps {
  invoice: Invoice | InvoiceWithClient;
  onDownload: (invoice: Invoice | InvoiceWithClient) => void;
}

function PdfDownloadButtonMobile({ invoice, onDownload }: PdfDownloadButtonMobileProps) {
  const [fileStatus, setFileStatus] = useState<'loading' | 'available' | 'not_found' | 'error'>('loading');
  
  useEffect(() => {
    // Se non c'è un percorso PDF, imposta subito come non disponibile
    if (!invoice.pdfPath) {
      setFileStatus('not_found');
      return;
    }
    
    // Verifica l'esistenza del file
    const checkFileExists = async () => {
      try {
        // Assicuriamoci che il percorso inizi con / se non è un URL completo
        let path = invoice.pdfPath || '';
        if (path && !path.startsWith('http') && !path.startsWith('/')) {
          path = '/' + path;
        }
        
        // Utilizziamo il nuovo endpoint secure-pdf per i controlli di disponibilità
        const fileName = path.split('/').pop() || '';
        path = `/api/secure-pdf/${encodeURIComponent(fileName)}`;
        
        console.log("Verifica disponibilità PDF (mobile):", path);
        
        // Aggiungiamo un timestamp per evitare il caching
        const nocacheUrl = `${path}${path.includes('?') ? '&' : '?'}_t=${Date.now()}`;
        
        // Utilizziamo GET invece di HEAD per maggiore compatibilità
        const response = await fetch(nocacheUrl, { 
          method: 'GET',
          headers: { 'Pragma': 'no-cache', 'Cache-Control': 'no-cache' }
        });
        
        if (response.ok) {
          console.log("File PDF disponibile (mobile):", path);
          setFileStatus('available');
        } else {
          console.warn("File PDF non disponibile (mobile):", path, "Status:", response.status);
          setFileStatus('not_found');
        }
      } catch (error) {
        console.error("Errore nella verifica del PDF (mobile):", error);
        setFileStatus('error');
      }
    };
    
    // Aggiungiamo un piccolo ritardo prima del controllo
    const timer = setTimeout(() => {
      checkFileExists();
    }, 500);  // 500ms di ritardo
    
    return () => clearTimeout(timer);
  }, [invoice.pdfPath]);
  
  // Rendering condizionale in base allo stato
  if (fileStatus === 'loading') {
    return (
      <Button 
        size="sm" 
        variant="outline" 
        className="flex-1 border-gray-300 opacity-70" 
        disabled
      >
        <Loader2 className="h-4 w-4 animate-spin mr-1" />
        PDF
      </Button>
    );
  }
  
  if (fileStatus === 'available') {
    return (
      <Button 
        size="sm" 
        variant="outline" 
        className="flex-1 border-green-500 text-green-700 hover:bg-green-50" 
        onClick={() => onDownload(invoice)}
      >
        <Download className="h-4 w-4 mr-1" />
        PDF
      </Button>
    );
  }
  
  // Per not_found o error
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            size="sm" 
            variant="outline" 
            className="flex-1 border-red-300 text-red-500 opacity-70" 
            disabled
          >
            <AlertCircle className="h-4 w-4 mr-1" />
            PDF
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>{fileStatus === 'not_found' ? 'PDF non trovato' : 'Errore nella verifica del PDF'}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

function getPaymentTypeName(type: string): string {
  switch (type) {
    case 'bank_transfer':
      return 'Bonifico bancario';
    case 'credit_card':
      return 'Carta di credito';
    case 'cash':
      return 'Contanti';
    case 'paypal':
      return 'PayPal';
    default:
      return type;
  }
}