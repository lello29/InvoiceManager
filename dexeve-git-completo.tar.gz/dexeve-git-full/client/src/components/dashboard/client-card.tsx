import { Client } from "@shared/schema";
import { formatCurrency, getInitials } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Eye, Edit, Trash, Phone, Mail } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

interface ClientCardProps {
  client: Client;
  onView: (client: Client) => void;
  onEdit?: (client: Client) => void;
  onDelete?: (client: Client) => void;
  totalInvoiced?: number;
  totalPaid?: number;
}

export function ClientCard({ 
  client, 
  onView, 
  onEdit, 
  onDelete,
  totalInvoiced = 0,
  totalPaid = 0
}: ClientCardProps) {
  const isMobile = useIsMobile();
  
  if (isMobile) {
    return (
      <div className="bg-white rounded-xl shadow-sm overflow-hidden border mb-3">
        <div className="p-4">
          <div className="flex items-start">
            <div className="flex-shrink-0 h-12 w-12 rounded-full bg-primary text-white flex items-center justify-center text-lg font-semibold">
              {getInitials(client.name)}
            </div>
            <div className="ml-4 flex-1">
              <h3 className="text-lg font-medium text-gray-900">{client.name}</h3>
              <div className="mt-1 flex flex-col space-y-1 text-sm text-gray-500">
                <div className="flex items-center">
                  <Mail className="h-3 w-3 mr-1" />
                  {client.email}
                </div>
                {client.phone && (
                  <div className="flex items-center">
                    <Phone className="h-3 w-3 mr-1" />
                    {client.phone}
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {(totalInvoiced > 0 || totalPaid > 0) && (
            <div className="mt-4 grid grid-cols-2 gap-4 border-t border-gray-100 pt-4">
              <div>
                <p className="text-xs text-gray-500">Totale fatturato</p>
                <p className="text-base font-semibold">{formatCurrency(totalInvoiced)}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500">Totale pagato</p>
                <p className="text-base font-semibold">{formatCurrency(totalPaid)}</p>
              </div>
            </div>
          )}
          
          <div className="mt-4 flex space-x-2">
            <Button size="sm" variant="default" className="flex-1" onClick={() => onView(client)}>
              <Eye className="h-4 w-4 mr-1" />
              Dettagli
            </Button>
            {onEdit && (
              <Button size="sm" variant="outline" onClick={() => onEdit(client)}>
                <Edit className="h-4 w-4" />
              </Button>
            )}
            {onDelete && (
              <Button size="sm" variant="outline" className="text-red-500" onClick={() => onDelete(client)}>
                <Trash className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </div>
    );
  }
  
  // Desktop version
  return (
    <tr className="hover:bg-gray-50">
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="flex items-center">
          <div className="flex-shrink-0 h-10 w-10 rounded-full bg-primary text-white flex items-center justify-center">
            {getInitials(client.name)}
          </div>
          <div className="ml-4">
            <div className="text-sm font-medium text-gray-900">{client.name}</div>
            <div className="text-sm text-gray-500">{client.email}</div>
          </div>
        </div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="text-sm text-gray-500">{client.phone || "-"}</div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="text-sm text-gray-900">{formatCurrency(totalInvoiced)}</div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="text-sm text-gray-900">{formatCurrency(totalPaid)}</div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
        <div className="flex justify-end space-x-2">
          <Button variant="ghost" size="icon" onClick={() => onView(client)} title="Visualizza">
            <Eye className="h-4 w-4 text-primary" />
          </Button>
          {onEdit && (
            <Button variant="ghost" size="icon" onClick={() => onEdit(client)} title="Modifica">
              <Edit className="h-4 w-4 text-gray-600" />
            </Button>
          )}
          {onDelete && (
            <Button variant="ghost" size="icon" onClick={() => onDelete(client)} title="Elimina">
              <Trash className="h-4 w-4 text-red-600" />
            </Button>
          )}
        </div>
      </td>
    </tr>
  );
}