import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Client } from "@shared/schema";
import { X, BrainCircuit } from "lucide-react";
import { PaymentTrends } from "./payment-trends";

interface ClientTrendsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  client: Client | null;
}

export function ClientTrendsModal({ open, onOpenChange, client }: ClientTrendsModalProps) {
  if (!client) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl p-0">
        <DialogHeader className="flex justify-between items-center px-6 py-4 bg-gray-50 border-b">
          <DialogTitle className="text-lg font-semibold text-gray-900 flex items-center">
            <BrainCircuit className="h-5 w-5 mr-2 text-primary" />
            Analisi AI: Tendenze di Pagamento - {client.name}
          </DialogTitle>
          <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)}>
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>

        <div className="px-6 py-4">
          <PaymentTrends clientId={client.id} />
        </div>

        <DialogFooter className="px-6 py-4 bg-gray-50 border-t">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Chiudi
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}