import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, File, X, BrainCircuit, FileText } from "lucide-react";

interface FileUploadProps {
  onFileChange: (file: File | null) => void;
  onImportData?: () => void;
  onPreviewPdf?: () => void;
  pdfUrl?: string | null;
  accept?: string;
  label?: string;
  initialFile?: string | null;
}

export function FileUpload({ onFileChange, onImportData, onPreviewPdf, pdfUrl, accept = "application/pdf", label = "Upload PDF", initialFile = null }: FileUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState<string | null>(initialFile ? initialFile.split('/').pop() || null : null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files && e.target.files[0];
    if (file) {
      setFileName(file.name);
      onFileChange(file);
    }
  };

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  const handleRemoveFile = () => {
    setFileName(null);
    onFileChange(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div className="space-y-2">
      <Label htmlFor="file-upload">{label}</Label>
      <Input
        id="file-upload"
        type="file"
        accept={accept}
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
      />

      {fileName ? (
        <div className="space-y-2">
          <div className="flex items-center gap-2 p-2 border rounded-md bg-gray-50">
            <File className="h-4 w-4 text-primary" />
            <span className="text-sm flex-1 truncate">{fileName}</span>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={handleRemoveFile}
              type="button"
              className="h-6 w-6 rounded-full"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={onImportData}
              className="w-full"
              disabled={!fileName}
            >
              <BrainCircuit className="mr-2 h-4 w-4" />
              Importa dati
            </Button>
            {(pdfUrl || fileName) && onPreviewPdf && (
              <Button
                type="button"
                variant="secondary"
                onClick={onPreviewPdf}
                className="w-full"
              >
                <FileText className="mr-2 h-4 w-4" />
                Anteprima
              </Button>
            )}
          </div>
        </div>
      ) : (
        <Button
          type="button"
          variant="outline"
          onClick={handleButtonClick}
          className="w-full"
        >
          <Upload className="mr-2 h-4 w-4" />
          Seleziona PDF
        </Button>
      )}
    </div>
  );
}