import { cn } from "@/lib/utils";

type StatusBadgeProps = {
  status: string;
  className?: string;
};

export function StatusBadge({ status, className }: StatusBadgeProps) {
  let badgeClass = "";
  let displayText = "";

  switch (status.toLowerCase()) {
    case "paid":
      badgeClass = "bg-green-100 text-green-800";
      displayText = "Pagata";
      break;
    case "pending":
      badgeClass = "bg-yellow-100 text-yellow-800";
      displayText = "In attesa";
      break;
    case "overdue":
      badgeClass = "bg-red-100 text-red-800";
      displayText = "Scaduta";
      break;
    default:
      badgeClass = "bg-gray-100 text-gray-800";
      displayText = status;
  }

  return (
    <span className={cn("px-2 inline-flex text-xs leading-5 font-semibold rounded-full", badgeClass, className)}>
      {displayText}
    </span>
  );
}
