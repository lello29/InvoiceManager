import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, File, X, FileText, Trash2, Eye, Download } from "lucide-react";
import { SimplePdfViewer } from "@/components/simple-pdf-viewer";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

export interface PdfFile {
  id?: number;
  name: string;
  url: string;
  file?: File;
  isNew?: boolean;
}

interface MultiFileUploadProps {
  onFilesChange: (files: PdfFile[]) => void;
  existingFiles?: PdfFile[];
  accept?: string;
  label?: string;
  maxFiles?: number;
}

export function MultiFileUpload({ 
  onFilesChange, 
  existingFiles = [], 
  accept = "application/pdf", 
  label = "Gestione documenti", 
  maxFiles = 10 
}: MultiFileUploadProps) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<PdfFile[]>(existingFiles);
  const [previewFile, setPreviewFile] = useState<PdfFile | null>(null);
  const [showPreview, setShowPreview] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files && e.target.files[0];
    if (selectedFile) {
      if (files.length >= maxFiles) {
        toast({
          title: "Limite raggiunto",
          description: `Puoi caricare al massimo ${maxFiles} file.`,
          variant: "destructive",
        });
        return;
      }

      // Crea un URL temporaneo per l'anteprima
      const fileUrl = URL.createObjectURL(selectedFile);
      
      const newFile: PdfFile = {
        name: selectedFile.name,
        url: fileUrl,
        file: selectedFile,
        isNew: true
      };
      
      const updatedFiles = [...files, newFile];
      setFiles(updatedFiles);
      onFilesChange(updatedFiles);
      
      // Reset input value to allow uploading the same file again
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      
      toast({
        title: "File aggiunto",
        description: `"${selectedFile.name}" è stato aggiunto all'elenco.`,
      });
    }
  };

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  const handleRemoveFile = (index: number) => {
    const fileToRemove = files[index];
    
    // Revoca URL per evitare perdite di memoria per i file nuovi
    if (fileToRemove.isNew && fileToRemove.url.startsWith('blob:')) {
      URL.revokeObjectURL(fileToRemove.url);
    }
    
    const updatedFiles = files.filter((_, i) => i !== index);
    setFiles(updatedFiles);
    onFilesChange(updatedFiles);
    
    toast({
      title: "File rimosso",
      description: `"${fileToRemove.name}" è stato rimosso dall'elenco.`,
    });
  };

  const handlePreview = (file: PdfFile) => {
    setPreviewFile(file);
    setShowPreview(true);
  };

  const handleDownload = (file: PdfFile) => {
    // Per i file esistenti utilizziamo la URL diretta
    if (!file.isNew) {
      window.open(`/api/download-pdf/${file.url.split('/').pop()}`, '_blank');
    } else {
      // Per i file nuovi, creiamo un link di download dal blob
      const link = document.createElement('a');
      link.href = file.url;
      link.download = file.name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <Input
        type="file"
        accept={accept}
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
      />

      <div className="space-y-2">
        {files.length > 0 ? (
          <div className="border rounded-md overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-muted">
                <tr>
                  <th className="px-4 py-2 text-left">Nome file</th>
                  <th className="px-4 py-2 text-center">Stato</th>
                  <th className="px-4 py-2 text-center">Azioni</th>
                </tr>
              </thead>
              <tbody>
                {files.map((file, index) => (
                  <tr key={index} className="border-t">
                    <td className="px-4 py-2 flex items-center">
                      <File className="h-4 w-4 text-primary mr-2" />
                      <span className="truncate max-w-[200px]">{file.name}</span>
                    </td>
                    <td className="px-4 py-2 text-center">
                      <span className={`px-2 py-1 text-xs rounded-full ${file.isNew ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'}`}>
                        {file.isNew ? 'Nuovo' : 'Esistente'}
                      </span>
                    </td>
                    <td className="px-4 py-2">
                      <div className="flex justify-center gap-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handlePreview(file)}
                          title="Anteprima"
                          className="h-8 w-8 text-blue-600"
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handleDownload(file)}
                          title="Scarica"
                          className="h-8 w-8 text-green-600"
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handleRemoveFile(index)}
                          title="Rimuovi"
                          className="h-8 w-8 text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center p-4 border rounded-md bg-muted/10">
            <p className="text-sm text-muted-foreground">Nessun documento allegato</p>
          </div>
        )}
        
        {files.length < maxFiles && (
          <Button
            type="button"
            variant="outline"
            onClick={handleButtonClick}
            className="w-full mt-2"
          >
            <Upload className="mr-2 h-4 w-4" />
            Aggiungi documento
          </Button>
        )}
      </div>

      {/* Dialog per l'anteprima del PDF */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Anteprima: {previewFile?.name}</DialogTitle>
          </DialogHeader>
          {previewFile && (
            <div className="h-[70vh]">
              <SimplePdfViewer 
                pdfUrl={previewFile.url} 
                className="w-full h-full"
                showControls={true}
                downloadUrl={previewFile.isNew ? undefined : `/api/download-pdf/${previewFile.url.split('/').pop()}`}
                downloadFilename={previewFile.name}
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}