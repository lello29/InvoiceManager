import { useState, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatDate, convertDateForInput, convertDateForDisplay } from "@/lib/utils";

interface EditableCellProps {
  value: string;
  onChange: (value: string | null) => void;
  type?: "text" | "number" | "date" | "select";
  options?: { value: string; label: string }[];
  className?: string;
  placeholder?: string;
}

export function EditableCell({ 
  value, 
  onChange, 
  type = "text", 
  options = [],
  className = "",
  placeholder
}: EditableCellProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(value);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [isEditing]);

  const handleDoubleClick = () => {
    setIsEditing(true);
    // Per le date, converti al formato di input (YYYY-MM-DD)
    if (type === "date") {
      setEditValue(convertDateForInput(value));
    } else {
      setEditValue(value);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      saveChanges();
    } else if (e.key === "Escape") {
      cancelEdit();
    }
  };

  const saveChanges = () => {
    // L'input type="date" restituisce YYYY-MM-DD, ma per alcuni
    // campi potremmo avere bisogno di convertire in DD/MM/YYYY per il display
    onChange(editValue);
    setIsEditing(false);
  };

  const cancelEdit = () => {
    // Per le date, converti al formato di input (YYYY-MM-DD)
    if (type === "date") {
      setEditValue(convertDateForInput(value));
    } else {
      setEditValue(value);
    }
    setIsEditing(false);
  };

  if (!isEditing) {
    return (
      <div 
        onDoubleClick={handleDoubleClick} 
        className={`cursor-pointer hover:bg-gray-100 rounded px-2 py-1 ${className}`}
        title="Doppio clic per modificare"
      >
        {type === "select" && options.length > 0 
          ? options.find(opt => opt.value === value)?.label || value
          : type === "date" && value 
            ? formatDate(new Date(value))
            : value || placeholder || ""}
      </div>
    );
  }

  return (
    <div className="flex space-x-1 items-center">
      {type === "select" && options.length > 0 ? (
        <select
          value={editValue}
          onChange={(e) => setEditValue(e.target.value)}
          className="w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
          autoFocus
          onKeyDown={handleKeyDown}
        >
          {options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      ) : (
        <Input
          ref={inputRef}
          type={type}
          value={editValue}
          onChange={(e) => setEditValue(e.target.value)}
          onKeyDown={handleKeyDown}
          className="h-8 py-1"
          placeholder={placeholder}
        />
      )}
      <div className="flex space-x-1">
        <Button variant="ghost" size="icon" onClick={saveChanges} className="h-7 w-7">
          <Check className="h-4 w-4 text-green-600" />
        </Button>
        <Button variant="ghost" size="icon" onClick={cancelEdit} className="h-7 w-7">
          <X className="h-4 w-4 text-red-600" />
        </Button>
      </div>
    </div>
  );
}