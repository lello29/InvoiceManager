import React from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  AlertTriangle,
  CalendarDays,
  Check,
  CircleHelp,
  Clock,
  XCircle,
  BarChart3,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { format } from "date-fns";
import { it } from "date-fns/locale";

interface PaymentPredictionProps {
  invoiceId: number;
}

interface PredictionData {
  paymentProbability: number;
  expectedPaymentDate: string;
  riskFactors: string[];
  confidenceScore: number;
  recommendedActions: string[];
  error?: string;
}

export function PaymentPrediction({ invoiceId }: PaymentPredictionProps) {
  const {
    data: prediction,
    isLoading,
    error,
  } = useQuery<PredictionData>({
    queryKey: [`/api/admin/invoices/${invoiceId}/payment-prediction`],
    enabled: !!invoiceId,
  });

  if (isLoading) {
    return <PredictionSkeleton />;
  }

  if (error || !prediction) {
    return (
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Errore</AlertTitle>
        <AlertDescription>
          Si è verificato un errore durante il caricamento della previsione.
          {error ? ` ${(error as Error).message}` : ""}
        </AlertDescription>
      </Alert>
    );
  }

  if (prediction.error) {
    return (
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Errore nell'analisi</AlertTitle>
        <AlertDescription>{prediction.error}</AlertDescription>
      </Alert>
    );
  }

  // Formatta la data attesa di pagamento
  const formatExpectedDate = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return format(date, 'dd MMMM yyyy', { locale: it });
    } catch (e) {
      return dateString; // Se non è una data valida, restituisci la stringa originale
    }
  };

  // Determina il colore del badge in base alla probabilità di pagamento
  const getProbabilityBadgeVariant = (probability: number) => {
    if (probability >= 0.75) return "outline" as const;  // invece di "success"
    if (probability >= 0.4) return "secondary" as const;  // invece di "warning"
    return "destructive" as const;
  };

  // Ottieni la descrizione testuale della probabilità
  const getProbabilityText = (probability: number) => {
    if (probability >= 0.75) return "Alta";
    if (probability >= 0.4) return "Media";
    return "Bassa";
  };

  // Converti la probabilità in percentuale
  const probabilityPercentage = Math.round(prediction.paymentProbability * 100);

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            Previsione di Pagamento
          </CardTitle>
          <CardDescription>
            Analisi predittiva basata su intelligenza artificiale
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Probabilità di pagamento */}
            <div className="flex justify-between items-center p-4 bg-muted rounded-md">
              <div>
                <h3 className="font-medium text-sm">Probabilità di Pagamento</h3>
                <Badge 
                  variant={getProbabilityBadgeVariant(prediction.paymentProbability)}
                  className="mt-1"
                >
                  {getProbabilityText(prediction.paymentProbability)}
                </Badge>
              </div>
              <div className="text-3xl font-bold">
                {probabilityPercentage}%
              </div>
            </div>

            <Separator />

            {/* Data di pagamento prevista */}
            <div className="mb-4">
              <div className="flex items-start gap-2">
                <CalendarDays className="h-5 w-5 text-blue-500 mt-0.5" />
                <div>
                  <h3 className="font-medium">Data di Pagamento Prevista</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {formatExpectedDate(prediction.expectedPaymentDate)}
                  </p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Fattori di rischio */}
            <div className="mb-4">
              <div className="flex items-start gap-2">
                <AlertTriangle className="h-5 w-5 text-yellow-500 mt-0.5" />
                <div>
                  <h3 className="font-medium">Fattori di Rischio</h3>
                  <ul className="list-disc list-inside text-sm text-muted-foreground mt-1 space-y-1">
                    {Array.isArray(prediction.riskFactors) 
                      ? prediction.riskFactors.map((factor, i) => (
                          <li key={i}>{factor}</li>
                        ))
                      : <li>{prediction.riskFactors as unknown as string}</li>
                    }
                  </ul>
                </div>
              </div>
            </div>

            <Separator />

            {/* Livello di confidenza */}
            <div className="mb-4">
              <div className="flex items-start gap-2">
                <CircleHelp className="h-5 w-5 text-indigo-500 mt-0.5" />
                <div>
                  <h3 className="font-medium">Livello di Confidenza</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="w-full bg-gray-200 h-2 rounded-full">
                      <div 
                        className="bg-primary h-2 rounded-full" 
                        style={{ width: `${prediction.confidenceScore * 100}%` }}
                      ></div>
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {Math.round(prediction.confidenceScore * 100)}%
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Azioni consigliate */}
            <div>
              <div className="flex items-start gap-2">
                <Check className="h-5 w-5 text-green-500 mt-0.5" />
                <div>
                  <h3 className="font-medium">Azioni Consigliate</h3>
                  <ul className="list-disc list-inside text-sm text-muted-foreground mt-1 space-y-1">
                    {Array.isArray(prediction.recommendedActions) 
                      ? prediction.recommendedActions.map((action, i) => (
                          <li key={i}>{action}</li>
                        ))
                      : <li>{prediction.recommendedActions as unknown as string}</li>
                    }
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function PredictionSkeleton() {
  return (
    <Card>
      <CardHeader className="pb-2">
        <Skeleton className="h-5 w-[200px]" />
        <Skeleton className="h-4 w-[300px] mt-2" />
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Skeleton className="h-16 w-full rounded-md" />
          
          {[1, 2, 3, 4, 5].map((i) => (
            <React.Fragment key={i}>
              <Skeleton className="h-[1px] w-full" />
              <div className="space-y-2">
                <Skeleton className="h-5 w-[150px]" />
                <Skeleton className="h-8 w-full" />
              </div>
            </React.Fragment>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}