import React from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import {
  AlertTriangle,
  ArrowRight,
  Clock,
  DollarSign,
  ShieldAlert,
  BadgeDollarSign,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface PendingPaymentsReportProps {
  onViewInvoice?: (invoiceId: number) => void;
}

interface ReportData {
  reportSummary: string;
  totalValue: number;
  highRiskInvoices: Array<{
    id: number;
    invoiceNumber: string;
    amount: number;
    client: string;
    daysOverdue: number;
    riskLevel: string;
  }>;
  followUpPriorities: Array<{
    id: number;
    invoiceNumber: string;
    client: string;
    priority: string;
    reason: string;
  }>;
  recoveryStrategies: string[];
  error?: string;
}

export function PendingPaymentsReport({ onViewInvoice }: PendingPaymentsReportProps) {
  const {
    data: report,
    isLoading,
    error,
  } = useQuery<ReportData>({
    queryKey: ["/api/admin/pending-payments-report"],
  });

  if (isLoading) {
    return <ReportSkeleton />;
  }

  if (error || !report) {
    return (
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Errore</AlertTitle>
        <AlertDescription>
          Si è verificato un errore durante il caricamento del report.
          {error ? ` ${(error as Error).message}` : ""}
        </AlertDescription>
      </Alert>
    );
  }

  if (report.error) {
    return (
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Errore nell'analisi</AlertTitle>
        <AlertDescription>{report.error}</AlertDescription>
      </Alert>
    );
  }
  
  // Formatta il valore in euro
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR'
    }).format(value);
  };

  // Determina il colore del badge in base al livello di rischio
  const getRiskBadgeVariant = (riskLevel: string) => {
    const lowerRisk = riskLevel.toLowerCase();
    if (lowerRisk.includes("basso") || lowerRisk.includes("low")) {
      return "secondary" as const;
    } else if (lowerRisk.includes("medio") || lowerRisk.includes("medium")) {
      return "outline" as const;  // invece di "warning"
    } else {
      return "destructive" as const;
    }
  };

  // Determina il colore del badge in base alla priorità
  const getPriorityBadgeVariant = (priority: string) => {
    const lowerPriority = priority.toLowerCase();
    if (lowerPriority.includes("alta")) {
      return "destructive" as const;
    } else if (lowerPriority.includes("media")) {
      return "outline" as const;  // invece di "warning"
    } else {
      return "secondary" as const;
    }
  };

  return (
    <div className="space-y-6">
      {/* Riepilogo del report */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-primary" />
            Report Pagamenti in Sospeso
          </CardTitle>
          <CardDescription>
            Analisi e strategie per la gestione dei pagamenti in sospeso
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <h3 className="font-medium mb-1">Riepilogo</h3>
            <p className="text-sm text-muted-foreground">{report.reportSummary}</p>
          </div>
          
          <div className="bg-muted p-4 rounded-md flex items-center justify-between mb-4">
            <div>
              <h4 className="text-sm font-medium">Valore Totale in Sospeso</h4>
              <p className="text-muted-foreground text-xs">Fatture non pagate</p>
            </div>
            <div className="text-2xl font-bold text-primary">
              {formatCurrency(report.totalValue)}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Fatture ad alto rischio */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium flex items-center gap-2">
            <ShieldAlert className="h-5 w-5 text-destructive" />
            Fatture ad Alto Rischio
          </CardTitle>
          <CardDescription>
            Fatture che potrebbero necessitare di attenzione immediata
          </CardDescription>
        </CardHeader>
        <CardContent>
          {report.highRiskInvoices && report.highRiskInvoices.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>N° Fattura</TableHead>
                    <TableHead>Cliente</TableHead>
                    <TableHead>Importo</TableHead>
                    <TableHead>Giorni Scaduti</TableHead>
                    <TableHead>Rischio</TableHead>
                    <TableHead className="text-right">Azioni</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {report.highRiskInvoices.map((invoice) => (
                    <TableRow key={invoice.id}>
                      <TableCell className="font-medium">{invoice.invoiceNumber}</TableCell>
                      <TableCell>{invoice.client}</TableCell>
                      <TableCell>{formatCurrency(invoice.amount)}</TableCell>
                      <TableCell>
                        <span className={invoice.daysOverdue > 30 ? "text-destructive" : ""}>
                          {invoice.daysOverdue} giorni
                        </span>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getRiskBadgeVariant(invoice.riskLevel)}>
                          {invoice.riskLevel}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        {onViewInvoice && (
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => onViewInvoice(invoice.id)}
                          >
                            <ArrowRight className="h-4 w-4" />
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <Alert>
              <AlertDescription>
                Nessuna fattura ad alto rischio rilevata.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Priorità di follow-up */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium flex items-center gap-2">
            <BadgeDollarSign className="h-5 w-5 text-yellow-500" />
            Priorità di Follow-Up
          </CardTitle>
          <CardDescription>
            Ordine consigliato per il follow-up dei pagamenti
          </CardDescription>
        </CardHeader>
        <CardContent>
          {report.followUpPriorities && report.followUpPriorities.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>N° Fattura</TableHead>
                    <TableHead>Cliente</TableHead>
                    <TableHead>Priorità</TableHead>
                    <TableHead>Motivazione</TableHead>
                    <TableHead className="text-right">Azioni</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {report.followUpPriorities.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.invoiceNumber}</TableCell>
                      <TableCell>{item.client}</TableCell>
                      <TableCell>
                        <Badge variant={getPriorityBadgeVariant(item.priority)}>
                          {item.priority}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-xs truncate">{item.reason}</TableCell>
                      <TableCell className="text-right">
                        {onViewInvoice && (
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => onViewInvoice(item.id)}
                          >
                            <ArrowRight className="h-4 w-4" />
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <Alert>
              <AlertDescription>
                Nessuna priorità di follow-up disponibile.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Strategie di recupero */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-green-500" />
            Strategie di Recupero
          </CardTitle>
          <CardDescription>
            Suggerimenti per massimizzare le probabilità di incasso
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm">
            {Array.isArray(report.recoveryStrategies) 
              ? report.recoveryStrategies.map((strategy, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <span className="text-primary font-medium">{index + 1}.</span>
                    <span>{strategy}</span>
                  </li>
                ))
              : <li className="text-muted-foreground">Nessuna strategia disponibile.</li>
            }
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}

function ReportSkeleton() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-[200px]" />
          <Skeleton className="h-4 w-[300px] mt-2" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-20 w-full mb-4" />
          <Skeleton className="h-16 w-full" />
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <Skeleton className="h-5 w-[180px]" />
          <Skeleton className="h-4 w-[250px] mt-2" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-40 w-full" />
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <Skeleton className="h-5 w-[160px]" />
          <Skeleton className="h-4 w-[280px] mt-2" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-40 w-full" />
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <Skeleton className="h-5 w-[170px]" />
          <Skeleton className="h-4 w-[260px] mt-2" />
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-6 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}