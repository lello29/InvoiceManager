import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  AlertTriangle,
  BarChart4,
  CheckCircle,
  Lightbulb,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

interface InvoiceInsightsProps {
  invoiceId: number;
}

interface InsightData {
  summary: string;
  paymentInsight: string;
  clientInsight: string;
  riskAssessment: string;
  recommendations: string[];
  error?: string;
}

export function InvoiceInsights({ invoiceId }: InvoiceInsightsProps) {
  const {
    data: insights,
    isLoading,
    error,
  } = useQuery<InsightData>({
    queryKey: [`/api/admin/invoices/${invoiceId}/insights`],
    enabled: !!invoiceId,
  });

  if (isLoading) {
    return <InsightsSkeleton />;
  }

  if (error || !insights) {
    return (
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Errore</AlertTitle>
        <AlertDescription>
          Si è verificato un errore durante il caricamento degli insights AI.
          {error ? ` ${(error as Error).message}` : ""}
        </AlertDescription>
      </Alert>
    );
  }

  if (insights.error) {
    return (
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Errore nell'analisi</AlertTitle>
        <AlertDescription>{insights.error}</AlertDescription>
      </Alert>
    );
  }

  // Determina il colore del badge in base alla valutazione del rischio
  const getRiskBadgeVariant = (riskText: string) => {
    const lowerRisk = riskText.toLowerCase();
    if (lowerRisk.includes("basso") || lowerRisk.includes("low")) {
      return "outline" as const;  // invece di "success"
    } else if (lowerRisk.includes("medio") || lowerRisk.includes("medium")) {
      return "secondary" as const;  // invece di "warning"
    } else if (lowerRisk.includes("alto") || lowerRisk.includes("high")) {
      return "destructive" as const;
    }
    return "secondary" as const;
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">
            Insights AI della Fattura
          </CardTitle>
          <CardDescription>
            Analisi generata tramite intelligenza artificiale
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Sommario */}
            <div className="mb-4">
              <div className="flex items-start gap-2">
                <Lightbulb className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <h3 className="font-medium">Sommario</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {insights.summary}
                  </p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Insights sul pagamento */}
            <div className="mb-4">
              <div className="flex items-start gap-2">
                <BarChart4 className="h-5 w-5 text-blue-500 mt-0.5" />
                <div>
                  <h3 className="font-medium">Insights sul Pagamento</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {insights.paymentInsight}
                  </p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Insights sul cliente */}
            <div className="mb-4">
              <div className="flex items-start gap-2">
                <TrendingUp className="h-5 w-5 text-green-500 mt-0.5" />
                <div>
                  <h3 className="font-medium">Insights sul Cliente</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {insights.clientInsight}
                  </p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Valutazione del rischio */}
            <div className="mb-4">
              <div className="flex items-start gap-2">
                <AlertTriangle className="h-5 w-5 text-yellow-500 mt-0.5" />
                <div>
                  <h3 className="font-medium">Valutazione del Rischio</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant={getRiskBadgeVariant(insights.riskAssessment)}>
                      {insights.riskAssessment.includes(":") 
                        ? insights.riskAssessment.split(":")[0] 
                        : "Rischio"}
                    </Badge>
                    <p className="text-sm text-muted-foreground">
                      {insights.riskAssessment.includes(":") 
                        ? insights.riskAssessment.split(":").slice(1).join(":").trim() 
                        : insights.riskAssessment}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Raccomandazioni */}
            <div>
              <div className="flex items-start gap-2">
                <CheckCircle className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <h3 className="font-medium">Raccomandazioni</h3>
                  <ul className="list-disc list-inside text-sm text-muted-foreground mt-1 space-y-1">
                    {Array.isArray(insights.recommendations) 
                      ? insights.recommendations.map((rec, i) => (
                          <li key={i}>{rec}</li>
                        ))
                      : <li>{insights.recommendations as unknown as string}</li>
                    }
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function InsightsSkeleton() {
  return (
    <Card>
      <CardHeader className="pb-2">
        <Skeleton className="h-5 w-[200px]" />
        <Skeleton className="h-4 w-[300px] mt-2" />
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Skeleton per ogni sezione */}
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="space-y-2">
              <Skeleton className="h-5 w-[150px]" />
              <Skeleton className="h-16 w-full" />
              {i < 5 && <Skeleton className="h-[1px] w-full mt-2" />}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}