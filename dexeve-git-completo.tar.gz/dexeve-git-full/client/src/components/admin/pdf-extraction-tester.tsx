import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Check, Edit2, Loader2, Save, FileText } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SimplePdfViewer } from "@/components/simple-pdf-viewer";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { insertInvoiceSchema, Client } from "@shared/schema";
import { useLocation } from "wouter";

type PDFExtractionResult = {
  pdfPath: string;
  textLength: number;
  textPreview: string;
  totalAmount?: number; // Valore numerico convertito
  total?: string;       // Valore originale come stringa
  invoiceNumber?: string;
  issueDate?: string;
  dueDate?: string;
  client?: string;
  paymentMethod?: string;
  clientId?: number;
  tempPath?: string;    // Percorso temporaneo del file caricato
  pdfUrl?: string;      // URL per accedere al PDF tramite API
  regexExtraction: {
    invoiceNumber?: string;
    issueDate?: string;
    totalAmount?: number;
    client?: string;
    dueDate?: string;
    paymentMethod?: string;
  };
  aiExtraction: {
    invoiceNumber?: string;
    issueDate?: string;
    total?: string;
    client?: string;
    dueDate?: string;
    paymentMethod?: string;
  };
  clientMatch?: {
    id: number;
    matchType: 'exact' | 'similar' | 'suggestion' | 'none';
    similarityScore?: number;
    suggestedName?: string;
  };
  extractionMethod?: string;
  warningMessage?: string; // Messaggio di avviso per problemi di estrazione
};

type InvoiceWithPdf = {
  id: number;
  number: string;
  pdfPath: string;
};

export function PdfExtractionTester({ invoices }: { invoices: InvoiceWithPdf[] }) {
  // Fetch clients to use in the form
  const { data: clients = [] } = useQuery<Client[]>({
    queryKey: ['/api/admin/clients'],
  });
  const [selectedPdfPath, setSelectedPdfPath] = useState<string>("");
  const [currentTab, setCurrentTab] = useState<string>("ai");
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [editableData, setEditableData] = useState<{
    invoiceNumber: string;
    issueDate: string;
    dueDate: string;
    totalAmount: string;
    client: string;
    paymentMethod: string;
    clientId?: number;
  } | null>(null);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const testExtraction = useMutation({
    mutationFn: async (data: { pdfPath?: string, file?: File }) => {
      // Caso 1: PDF già presente nel server (tramite path)
      if (data.pdfPath) {
        try {
          const response = await apiRequest("POST", "/api/admin/test-pdf-extraction", { pdfPath: data.pdfPath });
          if (!response.ok) {
            throw new Error(`Errore HTTP: ${response.status}`);
          }
          const result = await response.json();
          return result;
        } catch (error) {
          console.error("Errore durante l'estrazione dal PDF locale:", error);
          throw error;
        }
      } 
      // Caso 2: Nuovo file PDF caricato dall'utente
      else if (data.file) {
        try {
          console.log("Caricamento file PDF per estrazione:", data.file.name);
          const formData = new FormData();
          formData.append("pdf", data.file);
          formData.append("originalName", data.file.name);
          
          // NOTA: Questo endpoint non deve reindirizzare ma restituire solo JSON
          // Cambiamo l'URL dell'endpoint per evitare confusioni con altre rotte
          const response = await fetch("/api/admin/test-pdf-extraction-upload", {
            method: "POST",
            body: formData,
            credentials: "include",
            // Aggiungiamo un header per indicare che vogliamo solo JSON
            headers: {
              "Accept": "application/json"
            }
          });
          
          if (!response.ok) {
            let errorMessage = `Errore HTTP: ${response.status}`;
            try {
              const errorData = await response.json();
              if (errorData.message) {
                errorMessage = errorData.message;
              }
            } catch (_) {
              // Ignora errori nel parsing JSON
            }
            throw new Error(errorMessage);
          }
          
          const jsonResponse = await response.json();
          console.log("Dati estratti dal PDF:", jsonResponse);
          
          // Se non ci sono dati significativi, aggiungi un messaggio di avviso
          if (!jsonResponse.invoiceNumber && !jsonResponse.issueDate && 
              !jsonResponse.totalAmount && !jsonResponse.total && 
              !jsonResponse.client && !jsonResponse.dueDate) {
            console.warn("Nessun dato significativo estratto dal PDF");
            jsonResponse.warningMessage = "Nessun dato significativo estratto dal PDF. L'estrazione potrebbe non essere riuscita correttamente.";
          }
          
          return jsonResponse;
        } catch (error) {
          console.error("Errore durante il test di estrazione del PDF:", error);
          throw error;
        }
      }
      
      // Se non è stato specificato né un path né un file
      throw new Error("Nessun file o percorso specificato");
    },
    onSuccess: (data: PDFExtractionResult) => {
      console.log("Estrazione completata:", data);
      
      // Assicuriamoci che i dati vengano importati correttamente nel form
      // Controlliamo prima se abbiamo un importo totale (preferisci il valore convertito)
      const totalAmountString = data.totalAmount 
        ? data.totalAmount.toString() 
        : (data.aiExtraction?.total || data.regexExtraction?.totalAmount?.toString() || "");
      
      // Imposta i dati per la modifica
      setEditableData({
        invoiceNumber: data.invoiceNumber || data.aiExtraction?.invoiceNumber || data.regexExtraction?.invoiceNumber || "",
        issueDate: data.issueDate || data.aiExtraction?.issueDate || data.regexExtraction?.issueDate || "",
        dueDate: data.dueDate || data.aiExtraction?.dueDate || data.regexExtraction?.dueDate || "",
        totalAmount: totalAmountString,
        client: data.client || data.aiExtraction?.client || data.regexExtraction?.client || "",
        paymentMethod: data.paymentMethod || data.aiExtraction?.paymentMethod || data.regexExtraction?.paymentMethod || "",
        clientId: data.clientId
      });
      
      setIsEditing(true);
      
      toast({
        title: "Estrazione completata",
        description: "I dati sono stati estratti con successo. Puoi modificarli prima di salvare.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Errore nell'estrazione",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleTest = () => {
    if (!selectedPdfPath && !uploadedFile) {
      toast({
        title: "Seleziona una fattura",
        description: "Devi selezionare una fattura o caricare un file PDF",
        variant: "destructive",
      });
      return;
    }
    
    if (selectedPdfPath) {
      testExtraction.mutate({ pdfPath: selectedPdfPath });
    } else if (uploadedFile) {
      testExtraction.mutate({ file: uploadedFile });
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Se carichiamo un file, resettiamo la selezione dal dropdown
      setSelectedPdfPath("");
      setUploadedFile(file);
      toast({
        title: "File selezionato",
        description: `File "${file.name}" selezionato. Premi "Testa Estrazione" per analizzarlo.`,
      });
    }
  };
  
  // Funzione per formattare JSON in maniera leggibile
  const formatJson = (data: any) => {
    return (
      <pre className="bg-gray-100 p-4 rounded-md text-xs overflow-auto max-h-80">
        {JSON.stringify(data, null, 2)}
      </pre>
    );
  };

  // Genera una tabella di confronto
  const comparisonTable = () => {
    if (!testExtraction.data) return null;
    
    const { regexExtraction, aiExtraction } = testExtraction.data;
    
    return (
      <div className="mt-6">
        <h3 className="text-lg font-medium mb-2">Confronto risultati:</h3>
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-100">
              <th className="border p-2 text-left">Campo</th>
              <th className="border p-2 text-left">Regex Extraction</th>
              <th className="border p-2 text-left">AI Extraction</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border p-2 font-medium">Numero fattura</td>
              <td className="border p-2">{regexExtraction.invoiceNumber || "-"}</td>
              <td className="border p-2">{aiExtraction.invoiceNumber || "-"}</td>
            </tr>
            <tr>
              <td className="border p-2 font-medium">Data emissione</td>
              <td className="border p-2">{regexExtraction.issueDate || "-"}</td>
              <td className="border p-2">{aiExtraction.issueDate || "-"}</td>
            </tr>
            <tr>
              <td className="border p-2 font-medium">Importo totale</td>
              <td className="border p-2">{regexExtraction.totalAmount?.toString() || "-"}</td>
              <td className="border p-2">
                {aiExtraction.total 
                  ? (<>
                      <span className="font-medium">{aiExtraction.total}</span>
                      {testExtraction.data?.totalAmount && (
                        <div className="text-xs text-gray-500 mt-1">
                          Convertito: {testExtraction.data.totalAmount.toFixed(2)} €
                        </div>
                      )}
                    </>)
                  : "-"}
              </td>
            </tr>
            <tr>
              <td className="border p-2 font-medium">Cliente</td>
              <td className="border p-2">{regexExtraction.client || "-"}</td>
              <td className="border p-2">{aiExtraction.client || "-"}</td>
            </tr>
            <tr>
              <td className="border p-2 font-medium">Data scadenza</td>
              <td className="border p-2">{regexExtraction.dueDate || "-"}</td>
              <td className="border p-2">{aiExtraction.dueDate || "-"}</td>
            </tr>
            <tr>
              <td className="border p-2 font-medium">Metodo pagamento</td>
              <td className="border p-2">{regexExtraction.paymentMethod || "-"}</td>
              <td className="border p-2">{aiExtraction.paymentMethod || "-"}</td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  };
  
  return (
    <Card className="w-full shadow-md">
      <CardHeader>
        <CardTitle>Test Estrazione PDF</CardTitle>
        <CardDescription>
          Confronta l'estrazione di dati dalle fatture PDF utilizzando regex e OpenAI
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Seleziona una fattura dal database</label>
              <div className="flex gap-2">
                <Select 
                  value={selectedPdfPath} 
                  onValueChange={(value) => {
                    setSelectedPdfPath(value);
                    // Reset upload when selecting from dropdown
                    setUploadedFile(null);
                  }}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Seleziona una fattura" />
                  </SelectTrigger>
                  <SelectContent>
                    {invoices.filter(inv => inv.pdfPath).map((invoice) => (
                      <SelectItem key={invoice.id} value={invoice.pdfPath}>
                        {invoice.number} (ID: {invoice.id})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="border-t pt-4">
              <label className="block text-sm font-medium mb-2">Oppure carica un PDF dal tuo computer</label>
              <div className="flex flex-col gap-2">
                <div className="relative rounded-md border border-dashed border-gray-300 p-4 text-center">
                  <input
                    type="file"
                    accept=".pdf"
                    onChange={handleFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  <div className="space-y-1 text-gray-500">
                    <p className="text-sm">
                      {uploadedFile ? uploadedFile.name : "Trascina qui un file PDF o clicca per selezionarlo"}
                    </p>
                    <p className="text-xs">Supportati solo file PDF</p>
                  </div>
                </div>
                
                {uploadedFile && (
                  <div className="bg-blue-50 p-2 rounded text-sm flex items-center">
                    <span className="font-medium mr-1">File selezionato:</span> {uploadedFile.name}
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex justify-end">
              <Button 
                onClick={handleTest} 
                disabled={testExtraction.isPending || (!selectedPdfPath && !uploadedFile)}
                className="mt-2"
              >
                {testExtraction.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analisi in corso...
                  </>
                ) : "Testa Estrazione"}
              </Button>
            </div>
          </div>
          
          {testExtraction.data && (
            <>
              <div className="bg-gray-50 p-4 rounded-md">
                <div className="flex justify-between items-center">
                  <h3 className="text-sm font-medium">Anteprima testo estratto:</h3>
                  {testExtraction.data.extractionMethod && (
                    <div className="px-2 py-1 rounded-full text-xs font-medium capitalize bg-blue-100 text-blue-800">
                      Metodo: {testExtraction.data.extractionMethod.replace("-", " ")}
                    </div>
                  )}
                </div>
                <p className="text-xs mt-2 text-gray-700">{testExtraction.data.textPreview}</p>
                <p className="text-xs mt-1 text-gray-500">Lunghezza totale: {testExtraction.data.textLength} caratteri</p>
              </div>
              
              {testExtraction.data.warningMessage && (
                <div className="mt-4 bg-yellow-50 border border-yellow-200 p-4 rounded-md text-yellow-800">
                  <h3 className="text-sm font-medium mb-1">Attenzione</h3>
                  <p className="text-xs">{testExtraction.data.warningMessage}</p>
                </div>
              )}
              
              {comparisonTable()}
              
              {testExtraction.data.clientMatch && (
                <div className="mt-6 bg-blue-50 p-4 rounded-md border border-blue-200">
                  <h3 className="text-lg font-medium mb-2">Corrispondenza cliente:</h3>
                  <div className="space-y-2">
                    <p>
                      <span className="font-medium">Tipo di match:</span>{" "}
                      {testExtraction.data.clientMatch.matchType === "exact" ? (
                        <span className="text-green-600 font-medium">Esatto</span>
                      ) : testExtraction.data.clientMatch.matchType === "similar" ? (
                        <span className="text-blue-600 font-medium">Simile</span>
                      ) : testExtraction.data.clientMatch.matchType === "suggestion" ? (
                        <span className="text-orange-600 font-medium">Suggerimento</span>
                      ) : (
                        <span className="text-red-600 font-medium">Nessuna corrispondenza</span>
                      )}
                    </p>
                    
                    {testExtraction.data.clientMatch.suggestedName && (
                      <p>
                        <span className="font-medium">Nome cliente:</span>{" "}
                        {testExtraction.data.clientMatch.suggestedName}
                      </p>
                    )}
                    
                    {testExtraction.data.clientMatch.similarityScore && (
                      <p>
                        <span className="font-medium">Percentuale di somiglianza:</span>{" "}
                        {testExtraction.data.clientMatch.similarityScore}%
                      </p>
                    )}
                    
                    {testExtraction.data.clientMatch.id && (
                      <p>
                        <span className="font-medium">ID cliente nel database:</span>{" "}
                        {testExtraction.data.clientMatch.id}
                      </p>
                    )}
                  </div>
                </div>
              )}
              
              <Tabs defaultValue="ai" value={currentTab} onValueChange={setCurrentTab}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="ai">Risultati AI</TabsTrigger>
                  <TabsTrigger value="regex">Risultati Regex</TabsTrigger>
                  <TabsTrigger value="all">Dati completi</TabsTrigger>
                </TabsList>
                <TabsContent value="ai" className="mt-4">
                  <h3 className="text-sm font-medium mb-2">Dati estratti con OpenAI:</h3>
                  {formatJson(testExtraction.data.aiExtraction)}
                </TabsContent>
                <TabsContent value="regex" className="mt-4">
                  <h3 className="text-sm font-medium mb-2">Dati estratti con Regex:</h3>
                  {formatJson(testExtraction.data.regexExtraction)}
                </TabsContent>
                <TabsContent value="all" className="mt-4">
                  <h3 className="text-sm font-medium mb-2">Tutti i dati estratti:</h3>
                  {formatJson(testExtraction.data)}
                </TabsContent>
              </Tabs>
            </>
          )}
        </div>
      </CardContent>
      {/* Form per la modifica dei dati estratti */}
      {editableData && testExtraction.data && isEditing && (
        <div className="border-t mt-6 pt-6">
          <h3 className="text-lg font-medium mb-4">Modifica dati estratti</h3>
          
          {/* Anteprima PDF in tempo reale */}
          <div className="mb-6 border rounded-lg overflow-hidden">
            <div className="flex flex-col lg:flex-row">
              {/* Colonna sinistra: Visualizzatore PDF */}
              <div className="w-full lg:w-1/2 border-r">
                <div className="p-4 bg-gray-50 border-b">
                  <div className="flex items-center">
                    <FileText className="h-5 w-5 mr-2 text-blue-600" />
                    <h4 className="text-md font-medium">Anteprima PDF</h4>
                  </div>
                </div>
                <div className="h-[500px]">
                  {testExtraction.data && (
                    <SimplePdfViewer 
                      pdfUrl={
                        testExtraction.data.pdfUrl 
                        || testExtraction.data.pdfPath 
                        || (testExtraction.data.tempPath ? `/api/temp/${encodeURIComponent(testExtraction.data.tempPath.split('/').pop() || '')}` : '')
                      }
                      className="h-full w-full" 
                      showControls={true}
                    />
                  )}
                </div>
              </div>
              
              {/* Colonna destra: Form di modifica dati */}
              <div className="w-full lg:w-1/2 p-4">
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <Label htmlFor="invoiceNumber">Numero fattura</Label>
                    <Input 
                      id="invoiceNumber" 
                      value={editableData.invoiceNumber}
                      onChange={(e) => setEditableData({...editableData, invoiceNumber: e.target.value})}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="issueDate">Data emissione</Label>
                    <Input 
                      id="issueDate" 
                      value={editableData.issueDate}
                      onChange={(e) => setEditableData({...editableData, issueDate: e.target.value})}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="dueDate">Data scadenza</Label>
                    <Input 
                      id="dueDate" 
                      value={editableData.dueDate}
                      onChange={(e) => setEditableData({...editableData, dueDate: e.target.value})}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="totalAmount">Importo totale</Label>
                    <Input 
                      id="totalAmount" 
                      value={editableData.totalAmount}
                      onChange={(e) => setEditableData({...editableData, totalAmount: e.target.value})}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="paymentMethod">Metodo pagamento</Label>
                    <Input 
                      id="paymentMethod" 
                      value={editableData.paymentMethod}
                      onChange={(e) => setEditableData({...editableData, paymentMethod: e.target.value})}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="client">Cliente</Label>
                    <Select 
                      value={editableData.clientId?.toString() || ""} 
                      onValueChange={(value) => {
                        const clientId = parseInt(value);
                        const client = clients.find((c: Client) => c.id === clientId);
                        setEditableData({
                          ...editableData, 
                          clientId,
                          client: client?.name || editableData.client
                        });
                      }}
                    >
                      <SelectTrigger className="w-full mt-1">
                        <SelectValue placeholder="Seleziona un cliente" />
                      </SelectTrigger>
                      <SelectContent>
                        {clients.map((client: Client) => (
                          <SelectItem key={client.id} value={client.id.toString()}>
                            {client.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="flex justify-end mt-6 gap-2">
                  <Button 
                    variant="outline" 
                    onClick={() => setIsEditing(false)}
                  >
                    Annulla
                  </Button>
                  <Button 
                    onClick={() => {
                      if (!testExtraction.data || !editableData) return;
                      
                      // Crea i dati per la nuova fattura
                      const invoiceData = {
                        number: editableData.invoiceNumber,
                        issueDate: editableData.issueDate,
                        dueDate: editableData.dueDate,
                        amount: parseFloat(editableData.totalAmount), // "amount" invece di "totalAmount"
                        paymentType: editableData.paymentMethod, // "paymentType" invece di "paymentMethod"
                        status: "pending",
                        clientId: editableData.clientId,
                        notes: `Fattura estratta con metodo: ${testExtraction.data.extractionMethod || "automatico"}`,
                        items: [{ // Aggiungiamo items per formattare correttamente i dati
                          description: "Importo totale fattura",
                          quantity: 1,
                          price: parseFloat(editableData.totalAmount),
                          total: parseFloat(editableData.totalAmount)
                        }]
                      };
                      
                      // Creare FormData e aggiungere i dati della fattura
                      const formData = new FormData();
                      
                      // Log per debug
                      console.log("Dati fattura da salvare:", invoiceData);
                      
                      // Assicurati che le date siano nel formato corretto (YYYY-MM-DD)
                      const formattedData = {
                        ...invoiceData,
                        issueDate: invoiceData.issueDate ? new Date(invoiceData.issueDate).toISOString().split('T')[0] : '',
                        dueDate: invoiceData.dueDate ? new Date(invoiceData.dueDate).toISOString().split('T')[0] : ''
                      };
                      
                      console.log("Dati fattura formattati:", formattedData);
                      
                      formData.append('data', JSON.stringify(formattedData));
                      
                      // Se abbiamo un file caricato, aggiungiamolo alla richiesta
                      if (uploadedFile) {
                        formData.append('pdf', uploadedFile);
                      } else if (testExtraction.data?.tempPath) {
                        // Se non abbiamo un file caricato ma abbiamo un percorso temporaneo,
                        // includiamo questo come path nel JSON
                        const updatedData = {
                          ...formattedData,
                          pdfPath: testExtraction.data.tempPath
                        };
                        console.log("Dati fattura con percorso temporaneo:", updatedData);
                        // Aggiorna il campo 'data' con i nuovi dati
                        formData.set('data', JSON.stringify(updatedData));
                      }
                      
                      // Chiamare l'API per salvare la fattura
                      fetch("/api/admin/invoices", {
                        method: "POST",
                        body: formData,
                        credentials: "include"
                      })
                        .then(async response => {
                          console.log("Response status:", response.status);
                          
                          if (!response.ok) {
                            // Prova a leggere il messaggio di errore dal server
                            try {
                              const errorText = await response.text();
                              console.error("Response error text:", errorText);
                              
                              try {
                                const errorData = JSON.parse(errorText);
                                console.error("Parsed error data:", errorData);
                                
                                if (errorData.errors) {
                                  const errorMessages = errorData.errors.map((err: any) => 
                                    `${err.path}: ${err.message}`).join(', ');
                                  throw new Error(`Errore di validazione: ${errorMessages}`);
                                } else if (errorData.details) {
                                  throw new Error(`${errorData.message}: ${errorData.details}`);
                                } else {
                                  throw new Error(errorData.message || `Errore HTTP: ${response.status}`);
                                }
                              } catch (jsonError) {
                                throw new Error(`Errore durante il salvataggio: ${errorText || response.status}`);
                              }
                            } catch (textError) {
                              throw new Error(`Errore durante il salvataggio della fattura: ${response.status}`);
                            }
                          }
                          
                          return response.json();
                        })
                        .then(data => {
                          toast({
                            title: "Successo",
                            description: "Fattura salvata correttamente",
                          });
                          
                          // Invalida la cache per aggiornare l'elenco delle fatture
                          queryClient.invalidateQueries({ queryKey: ['/api/admin/invoices'] });
                          
                          // Resettare i dati e rimanere nella stessa pagina
                          setEditableData(null);
                          setIsEditing(false);
                          
                          // Resetta lo stato per consentire una nuova estrazione
                          setSelectedPdfPath("");
                          setUploadedFile(null);
                        })
                        .catch(error => {
                          toast({
                            title: "Errore",
                            description: error.message,
                            variant: "destructive",
                          });
                        });
                    }}
                  >
                    <Save className="mr-2 h-4 w-4" />
                    Salva Fattura
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <CardFooter className="flex justify-between border-t pt-4">
        <div className="text-xs text-gray-500">
          {testExtraction.data ? "Estrazione completata con successo" : "Seleziona una fattura e clicca su 'Testa Estrazione'"}
        </div>
      </CardFooter>
    </Card>
  );
}