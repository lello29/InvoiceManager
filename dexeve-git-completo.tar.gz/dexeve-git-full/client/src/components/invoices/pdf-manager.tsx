import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, Upload, Trash2, Info, AlertTriangle, Download, Eye } from "lucide-react";
import { SimplePdfViewer } from "@/components/simple-pdf-viewer";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { MultiFileUpload, PdfFile } from "@/components/ui/multi-file-upload";
import { Invoice } from "@shared/schema";

interface PdfManagerProps {
  invoiceId: number;
  initialPdfPath?: string | null;
  onSuccessfulUpload?: () => void;
}

export function PdfManager({ invoiceId, initialPdfPath, onSuccessfulUpload }: PdfManagerProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [attachments, setAttachments] = useState<PdfFile[]>([]);
  const [tab, setTab] = useState<string>("documents");
  
  // Caricamento degli allegati dall'API
  const { data: invoice, isLoading } = useQuery<Invoice & { attachments?: { name: string; path: string }[] }>({
    queryKey: [`/api/admin/invoices/${invoiceId}`],
    enabled: !!invoiceId,
  });

  // Preparazione degli allegati esistenti
  useEffect(() => {
    if (invoice) {
      const files: PdfFile[] = [];
      
      // Aggiungi il PDF principale se esiste
      if (invoice && invoice.pdfPath) {
        files.push({
          id: 0,
          name: invoice.pdfPath.split('/').pop() || 'Documento principale.pdf',
          url: invoice.pdfPath,
        });
      }
      
      // Aggiungi gli allegati aggiuntivi se esistono
      if (invoice.attachments && Array.isArray(invoice.attachments)) {
        invoice.attachments.forEach((attachment: { name: string; path: string }, index: number) => {
          files.push({
            id: index + 1, // Inizia da 1 per gli allegati aggiuntivi
            name: attachment.name || `Allegato ${index + 1}.pdf`,
            url: attachment.path,
          });
        });
      }
      
      setAttachments(files);
    }
  }, [invoice]);

  // Mutation per caricare nuovi allegati
  const uploadAttachments = useMutation({
    mutationFn: async (files: File[]) => {
      if (!files.length) return null;
      
      const formData = new FormData();
      files.forEach(file => {
        formData.append('pdfs', file);
      });
      
      const response = await fetch(`/api/admin/invoices/${invoiceId}/attachments`, {
        method: 'POST',
        body: formData,
        credentials: 'include'
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Errore durante il caricamento degli allegati');
      }
      
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/admin/invoices/${invoiceId}`] });
      toast({
        title: 'Allegati caricati',
        description: 'I documenti sono stati caricati con successo',
      });
      if (onSuccessfulUpload) {
        onSuccessfulUpload();
      }
    },
    onError: (error: Error) => {
      toast({
        title: 'Errore',
        description: `Impossibile caricare gli allegati: ${error.message}`,
        variant: 'destructive',
      });
    }
  });

  // Mutation per eliminare un allegato
  const deleteAttachment = useMutation({
    mutationFn: async ({ index }: { index: number }) => {
      const response = await fetch(`/api/admin/invoices/${invoiceId}/attachments/${index}`, {
        method: 'DELETE',
        credentials: 'include'
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Errore durante l\'eliminazione dell\'allegato');
      }
      
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/admin/invoices/${invoiceId}`] });
      toast({
        title: 'Allegato eliminato',
        description: 'Il documento è stato eliminato con successo',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Errore',
        description: `Impossibile eliminare l'allegato: ${error.message}`,
        variant: 'destructive',
      });
    }
  });

  // Gestione del caricamento file
  const handleFilesChange = (files: PdfFile[]) => {
    // Identifica i nuovi file da caricare
    const newFiles = files.filter(f => f.isNew && f.file);
    
    if (newFiles.length > 0) {
      // Estrai i file per il caricamento
      const filesToUpload = newFiles.map(f => f.file!);
      uploadAttachments.mutate(filesToUpload);
    }
    
    setAttachments(files);
  };

  // Gestione dell'anteprima
  const handlePreview = (file: PdfFile) => {
    setPreviewUrl(file.url);
    setShowPreview(true);
  };

  if (isLoading) {
    return (
      <Card className="w-full">
        <CardContent className="p-4">
          <div className="flex items-center justify-center h-24">
            <div className="animate-spin h-6 w-6 border-2 border-primary rounded-full border-t-transparent"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          <span>Gestione Documenti</span>
        </CardTitle>
        <CardDescription>
          Visualizza, aggiungi o rimuovi documenti associati a questa fattura
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="documents">Documenti ({attachments.length})</TabsTrigger>
            <TabsTrigger value="upload">Carica Nuovi</TabsTrigger>
          </TabsList>
          
          <TabsContent value="documents" className="space-y-4 mt-4">
            {attachments.length > 0 ? (
              <div className="border rounded-md overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-muted">
                    <tr>
                      <th className="px-4 py-2 text-left">Nome documento</th>
                      <th className="px-4 py-2 text-right">Azioni</th>
                    </tr>
                  </thead>
                  <tbody>
                    {attachments.map((file, index) => (
                      <tr key={index} className="border-t">
                        <td className="px-4 py-2 flex items-center">
                          <FileText className="h-4 w-4 text-primary mr-2" />
                          <span className="truncate max-w-[200px]">{file.name}</span>
                          {index === 0 && (
                            <span className="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full">
                              Principale
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-2">
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => handlePreview(file)}
                              title="Anteprima"
                              className="h-8 w-8 text-blue-600"
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => window.open(`/api/download-pdf/${file.url.split('/').pop()}`, '_blank')}
                              title="Scarica"
                              className="h-8 w-8 text-green-600"
                            >
                              <Download className="h-4 w-4" />
                            </Button>
                            {index > 0 && (
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => deleteAttachment.mutate({ index: index - 1 })}
                                title="Elimina"
                                className="h-8 w-8 text-red-600"
                                disabled={deleteAttachment.isPending}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center p-6 border rounded-md">
                <FileText className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                <h3 className="text-lg font-medium">Nessun documento allegato</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Aggiungi documenti per questa fattura utilizzando la scheda "Carica Nuovi"
                </p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="upload" className="space-y-4 mt-4">
            <div className="p-4 border rounded-md bg-muted/10">
              <div className="flex items-start gap-3 mb-4">
                <Info className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-medium">Informazioni sul caricamento</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    Puoi caricare uno o più documenti PDF. Il primo documento caricato sarà considerato
                    il documento principale della fattura.
                  </p>
                </div>
              </div>
              
              <MultiFileUpload
                onFilesChange={handleFilesChange}
                existingFiles={[]}
                label="Carica documenti"
                maxFiles={5}
              />
            </div>
            
            {uploadAttachments.isPending && (
              <div className="flex items-center justify-center p-4">
                <div className="animate-spin h-5 w-5 border-2 border-primary rounded-full border-t-transparent mr-2"></div>
                <span className="text-sm">Caricamento in corso...</span>
              </div>
            )}
            
            {uploadAttachments.isError && (
              <div className="p-3 border border-red-200 bg-red-50 rounded-md flex items-start gap-2">
                <AlertTriangle className="h-5 w-5 text-red-500 flex-shrink-0" />
                <div>
                  <h4 className="text-sm font-medium text-red-700">Errore durante il caricamento</h4>
                  <p className="text-xs text-red-600 mt-1">
                    {uploadAttachments.error instanceof Error ? uploadAttachments.error.message : 'Si è verificato un errore durante il caricamento dei file'}
                  </p>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
      
      {/* Dialog per l'anteprima */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Anteprima documento</DialogTitle>
            <DialogDescription>
              Visualizzazione del documento selezionato
            </DialogDescription>
          </DialogHeader>
          {previewUrl && (
            <div className="h-[70vh]">
              <SimplePdfViewer 
                pdfUrl={previewUrl}
                className="w-full h-full"
                showControls={true}
                downloadUrl={`/api/download-pdf/${previewUrl.split('/').pop()}`}
                downloadFilename={previewUrl.split('/').pop()}
              />
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPreview(false)}>
              Chiudi
            </Button>
            {previewUrl && (
              <Button 
                onClick={() => window.open(`/api/download-pdf/${previewUrl.split('/').pop()}`, '_blank')}
              >
                <Download className="mr-2 h-4 w-4" />
                Scarica
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}