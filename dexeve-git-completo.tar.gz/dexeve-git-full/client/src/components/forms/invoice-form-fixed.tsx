import { useState } from "react";
import { useFieldArray, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { z } from "zod";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Trash, Plus, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { FileUpload } from "@/components/ui/file-upload";
import { SimplePdfViewer } from "@/components/simple-pdf-viewer";
import { Client, Invoice, InvoiceItem } from "@shared/schema";
import { PdfManager } from "@/components/invoices/pdf-manager";

// Schema per un elemento della fattura
const invoiceItemSchema = z.object({
  id: z.number().optional(),
  description: z.string().min(1, "La descrizione è obbligatoria"),
  quantity: z.string().min(1, "La quantità è obbligatoria"),
  price: z.string().min(1, "Il prezzo è obbligatorio"),
  total: z.string(),
});

// Schema per la validazione del form della fattura
const formSchema = z.object({
  number: z.string().min(1, "Il numero fattura è obbligatorio"),
  clientId: z.string().min(1, "Il cliente è obbligatorio"),
  issueDate: z.string().min(1, "La data di emissione è obbligatoria"),
  dueDate: z.string().min(1, "La data di scadenza è obbligatoria"),
  amount: z.string().min(1, "L'importo è obbligatorio").refine((val) => !isNaN(Number(val)) && Number(val) > 0, {
    message: "L'importo deve essere un numero positivo",
  }),
  status: z.string().min(1, "Lo stato è obbligatorio"),
  paymentType: z.string().optional(),
  paymentDate: z.string().optional(),
  notes: z.string().optional(),
  items: z.array(invoiceItemSchema).optional(),
  isFromPdf: z.boolean().optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface InvoiceFormProps {
  onSuccess: () => void;
  invoice?: Invoice & { items?: InvoiceItem[] };
}

export function InvoiceFormFixed({ onSuccess, invoice }: InvoiceFormProps) {
  const { toast } = useToast();
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [showPreviewModal, setShowPreviewModal] = useState<boolean>(false);
  const [showPdfPreview, setShowPdfPreview] = useState<boolean>(false);
  const [showPdfManager, setShowPdfManager] = useState<boolean>(false);
  const [extractedData, setExtractedData] = useState<{
    invoiceNumber: string;
    issueDate: string;
    dueDate: string;
    totalAmount: string;
    client: string;
    paymentMethod: string;
    tempPdfPath?: string;
    pdfUrl?: string;
    clientId?: number;
  } | null>(null);
  const [originalExtractedData, setOriginalExtractedData] = useState<any | null>(null);
  const [pdfPreviewUrl, setPdfPreviewUrl] = useState<string | null>(
    invoice?.pdfPath ? `/api/uploads/${invoice.pdfPath.split('/').pop()}` : null
  );

  // Fetch dei clienti dal server
  const { data: clients = [] } = useQuery<Client[]>({
    queryKey: ['/api/admin/clients'],
    staleTime: 60000, // 1 minute
  });

  // Configurazione del form con valori predefiniti
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: invoice
      ? {
          number: invoice.number,
          clientId: String(invoice.clientId),
          issueDate: new Date(invoice.issueDate).toISOString().split('T')[0],
          dueDate: new Date(invoice.dueDate).toISOString().split('T')[0],
          amount: String(invoice.amount),
          status: invoice.status,
          paymentType: invoice.paymentType || "",
          paymentDate: invoice.paymentDate 
            ? new Date(invoice.paymentDate).toISOString().split('T')[0] 
            : "",
          notes: invoice.notes || "",
          items: invoice.items?.map(item => ({
            id: item.id,
            description: item.description,
            quantity: String(item.quantity),
            price: String(item.price),
            total: String(item.total)
          })) || [],
        }
      : {
          number: "",
          clientId: "",
          issueDate: new Date().toISOString().split('T')[0],
          dueDate: new Date(new Date().setDate(new Date().getDate() + 30)).toISOString().split('T')[0],
          amount: "",
          status: "pending",
          paymentType: "",
          paymentDate: "",
          notes: "",
          items: [
            {
              description: "",
              quantity: "1",
              price: "0",
              total: "0"
            }
          ],
        }
  });

  // Configurazione del campo array per le voci fattura
  const { fields, append, remove, update } = useFieldArray({
    control: form.control,
    name: "items",
  });

  // Funzione per aggiornare il totale di un elemento e il totale complessivo
  const updateItemTotal = (index: number) => {
    try {
      // Ottieni l'elemento corrente
      const currentItems = form.getValues("items");
      if (!currentItems || !currentItems[index]) return;
      
      // Calcola il nuovo totale
      const item = currentItems[index];
      const quantity = parseFloat(item.quantity) || 0;
      const price = parseFloat(item.price) || 0;
      const total = (quantity * price).toFixed(2);
      
      // Aggiorna l'elemento con il nuovo totale
      const updatedItem = {
        ...item,
        total: total
      };
      
      // Aggiorna l'array
      const updatedItems = [...currentItems];
      updatedItems[index] = updatedItem;
      
      // Aggiorna il campo nel form
      form.setValue(`items.${index}.total`, total);
      
      // Calcola e aggiorna il totale complessivo
      let totalAmount = 0;
      updatedItems.forEach(item => {
        totalAmount += parseFloat(item.total) || 0;
      });
      
      form.setValue("amount", totalAmount.toFixed(2));
    } catch (error) {
      console.error("Errore nell'aggiornamento del totale:", error);
    }
  };

  // Mutation per creare una nuova fattura
  const createInvoice = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await fetch("/api/admin/invoices", {
        method: "POST",
        body: data,
        credentials: "include"
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to create invoice");
      }
      
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Fattura creata",
        description: "La fattura è stata creata con successo",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/invoices'] });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: `Impossibile creare la fattura: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Mutation per aggiornare una fattura esistente
  const updateInvoice = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await fetch(`/api/admin/invoices/${invoice?.id}`, {
        method: "PUT",
        body: data,
        credentials: "include"
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to update invoice");
      }
      
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Fattura aggiornata",
        description: "La fattura è stata aggiornata con successo",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/invoices'] });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: `Impossibile aggiornare la fattura: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Gestione dell'invio del form
  const onSubmit = (values: FormValues) => {
    const formData = new FormData();
    
    console.log("Form values before formatting:", values);
    
    // Se l'utente compila la data di pagamento ma dimentica di cambiare lo stato in "paid"
    if (values.paymentDate && values.status === "pending") {
      values.status = "paid";
      
      toast({
        title: "Nota",
        description: "Stato impostato automaticamente a 'Pagata' poiché è presente una data di pagamento.",
      });
    }
    
    // Prepara i valori formattati per l'invio
    const formattedValues = {
      ...values,
      clientId: parseInt(values.clientId),
      // Inviamo le date come stringhe ISO per evitare problemi di serializzazione
      issueDate: values.issueDate,
      dueDate: values.dueDate,
      paymentDate: values.paymentDate || undefined,
      // Convertiamo l'amount in numero
      amount: parseFloat(values.amount),
      // Formatta correttamente le voci
      items: values.items?.map(item => ({
        ...item,
        id: item.id || undefined,
        quantity: parseFloat(item.quantity),
        price: parseFloat(item.price),
        total: parseFloat(item.total)
      }))
    };
    
    console.log("Formatted values:", formattedValues);
    
    // Aggiungi i dati JSON alla richiesta
    formData.append("data", JSON.stringify(formattedValues));
    
    // Se abbiamo un PDF, lo alleghiamo alla richiesta
    if (pdfFile) {
      formData.append("pdf", pdfFile);
    }
    
    // Invia la richiesta appropriata (create/update)
    if (invoice) {
      // Aggiungi informazioni aggiuntive per l'aggiornamento
      formData.append("invoiceId", String(invoice.id));
      if (invoice.pdfPath && !pdfFile) {
        formData.append("existingPdfPath", invoice.pdfPath);
      }
      updateInvoice.mutate(formData);
    } else {
      createInvoice.mutate(formData);
    }
  };

  // Funzione per aggiungere i dati estratti ai valori del form
  const applyExtractedData = () => {
    if (!extractedData) return;
    
    // Imposta i valori dei campi dal PDF
    form.setValue("number", extractedData.invoiceNumber || "");
    
    // Imposta il cliente se è stato trovato un ID
    if (extractedData.clientId) {
      form.setValue("clientId", String(extractedData.clientId));
    }
    
    // Imposta le date
    if (extractedData.issueDate) {
      form.setValue("issueDate", extractedData.issueDate);
    }
    
    if (extractedData.dueDate) {
      form.setValue("dueDate", extractedData.dueDate);
    }
    
    // Imposta l'importo
    if (extractedData.totalAmount) {
      const amount = parseFloat(extractedData.totalAmount);
      form.setValue("amount", isNaN(amount) ? "0" : amount.toFixed(2));
    }
    
    // Imposta il metodo di pagamento
    if (extractedData.paymentMethod) {
      form.setValue("paymentType", extractedData.paymentMethod);
    }
    
    // Imposta il flag per indicare che è stato importato da PDF
    form.setValue("isFromPdf", true);
    
    // Chiudi il modale di anteprima
    setShowPreviewModal(false);
    
    toast({
      title: "Dati applicati",
      description: "I dati estratti dal PDF sono stati applicati al form",
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        {/* Header con titolo e pulsanti */}
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold">{invoice ? "Modifica Fattura" : "Nuova Fattura"}</h2>
            <p className="text-sm text-muted-foreground">
              {invoice ? "Modifica i dettagli della fattura" : "Inserisci i dettagli della nuova fattura"}
            </p>
          </div>
          
          {/* Mostra il pulsante per gestire i documenti solo quando la fattura è stata salvata */}
          {invoice && invoice.id && (
            <div className="mt-2 md:mt-0">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowPdfManager(true)}
                className="flex items-center gap-2"
              >
                <FileText className="h-4 w-4" />
                <span>Gestisci Documenti</span>
              </Button>
            </div>
          )}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Colonna sinistra: dati principali fattura */}
          <div className="space-y-6">
            <FormField
              control={form.control}
              name="number"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Numero Fattura</FormLabel>
                  <FormControl>
                    <Input placeholder="FTTR-2023/001" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="clientId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Cliente</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleziona cliente" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {clients.map((client) => (
                        <SelectItem key={client.id} value={String(client.id)}>
                          {client.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="issueDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Data Emissione</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Data Scadenza</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Stato</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleziona stato" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="pending">In attesa</SelectItem>
                      <SelectItem value="paid">Pagata</SelectItem>
                      <SelectItem value="overdue">Scaduta</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="paymentType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tipo Pagamento</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleziona tipo" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="bank_transfer">Bonifico bancario</SelectItem>
                        <SelectItem value="credit_card">Carta di credito</SelectItem>
                        <SelectItem value="cash">Contanti</SelectItem>
                        <SelectItem value="paypal">PayPal</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="paymentDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Data Pagamento</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Note</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Aggiungi note o dettagli aggiuntivi..." 
                      className="min-h-[120px]" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Colonna destra: voci fattura e file PDF */}
          <div className="space-y-6">
            {!form.getValues("isFromPdf") ? (
              <div>
                <h3 className="text-lg font-medium mb-4">Voci fattura</h3>
                
                {fields.map((field, index) => (
                  <Card key={field.id} className="mb-4">
                    <CardContent className="pt-4">
                      <div className="grid grid-cols-[1fr,auto] gap-2">
                        <FormField
                          control={form.control}
                          name={`items.${index}.description`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Descrizione</FormLabel>
                              <FormControl>
                                <Input {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="pt-8">
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              if (fields.length > 1) {
                                remove(index);
                                // Ricalcola il totale dopo la rimozione
                                setTimeout(() => {
                                  const items = form.getValues("items") || [];
                                  let total = 0;
                                  items.forEach(item => {
                                    total += parseFloat(item.total) || 0;
                                  });
                                  form.setValue("amount", total.toFixed(2));
                                }, 10);
                              }
                            }}
                            disabled={fields.length <= 1}
                          >
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-2 mt-2">
                        <FormField
                          control={form.control}
                          name={`items.${index}.quantity`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Quantità</FormLabel>
                              <FormControl>
                                <Input 
                                  {...field} 
                                  type="number" 
                                  min="1" 
                                  step="1"
                                  onChange={(e) => {
                                    field.onChange(e);
                                    // Aggiorna il totale con un piccolo ritardo
                                    setTimeout(() => updateItemTotal(index), 10);
                                  }}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name={`items.${index}.price`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Prezzo unitario (€)</FormLabel>
                              <FormControl>
                                <Input 
                                  {...field} 
                                  type="number" 
                                  min="0" 
                                  step="0.01"
                                  onChange={(e) => {
                                    field.onChange(e);
                                    // Aggiorna il totale con un piccolo ritardo
                                    setTimeout(() => updateItemTotal(index), 10);
                                  }}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name={`items.${index}.total`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Totale (€)</FormLabel>
                              <FormControl>
                                <Input {...field} readOnly />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </CardContent>
                  </Card>
                ))}
                
                <Button
                  type="button"
                  variant="outline"
                  className="w-full mt-2"
                  onClick={() => {
                    append({
                      description: "",
                      quantity: "1",
                      price: "0",
                      total: "0"
                    });
                  }}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Aggiungi voce
                </Button>
              </div>
            ) : (
              <div className="bg-muted p-4 rounded-md mb-4">
                <h3 className="text-lg font-medium mb-2">Importato da PDF</h3>
                <p className="text-muted-foreground mb-2">Questa fattura è stata importata direttamente da un PDF.</p>
                <p>Viene utilizzato l'importo totale estratto dal documento senza dettaglio voci.</p>
              </div>
            )}
            
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Importo Totale (€)</FormLabel>
                  <FormControl>
                    <Input {...field} readOnly={!form.getValues("isFromPdf")} />
                  </FormControl>
                  <FormDescription>
                    {!form.getValues("isFromPdf") 
                      ? "Calcolato automaticamente dalle voci." 
                      : "Inserito manualmente per fatture importate da PDF."}
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Solo per fatture nuove, mostro il caricamento singolo con estrazione */}
            {!invoice && (
              <div className="mt-4">
                <FileUpload
                  onFileChange={(file) => {
                    if (file) {
                      setPdfFile(file);
                      
                      // Crea URL per l'anteprima del file appena caricato
                      const fileUrl = URL.createObjectURL(file);
                      setPdfPreviewUrl(fileUrl);
                      
                      // Mostra un toast che conferma il caricamento del file
                      toast({
                        title: "File caricato",
                        description: `File "${file.name}" pronto per l'estrazione. Usa il pulsante "Estrai dati da PDF" per importare i valori.`,
                      });
                    }
                  }}
                  onPreviewPdf={() => {
                    // Se abbiamo un pdfPreviewUrl, mostriamo il PDF
                    if (pdfPreviewUrl) {
                      setShowPdfPreview(true);
                    } else {
                      toast({
                        title: "Nessun PDF disponibile",
                        description: "Non c'è nessun PDF associato a questa fattura",
                        variant: "destructive",
                      });
                    }
                  }}
                  pdfUrl={pdfPreviewUrl}
                  onImportData={async () => {
                    if (!pdfFile) {
                      toast({
                        title: "Errore",
                        description: "Nessun file PDF selezionato",
                        variant: "destructive",
                      });
                      return;
                    }
                  
                  const formData = new FormData();
                  formData.append("pdf", pdfFile);
                  formData.append("originalName", pdfFile.name);
                  
                  try {
                    toast({
                      title: "Elaborazione in corso",
                      description: "Stiamo estraendo i dati dal PDF...",
                    });
                    
                    const response = await fetch("/api/admin/invoices/extract", {
                      method: "POST",
                      body: formData,
                      credentials: "include"
                    });
                    
                    if (!response.ok) {
                      const errorData = await response.json();
                      throw new Error(errorData.message || "Errore nell'estrazione dei dati");
                    }
                    
                    const data = await response.json();
                    console.log("Dati estratti dal PDF:", data);
                    
                    // Verifica che ci siano dati validi
                    if (!data.invoiceNumber && !data.issueDate && 
                        !data.totalAmount && !data.total && 
                        !data.client && !data.dueDate) {
                      console.error("Nessun dato estratto dal PDF:", data);
                      toast({
                        title: "Attenzione",
                        description: "Non è stato possibile estrarre dati significativi dal PDF. Compilare i campi manualmente.",
                        variant: "destructive",
                      });
                      return;
                    }
                    
                    // Prepara i dati estratti
                    setExtractedData({
                      invoiceNumber: data.invoiceNumber || "",
                      issueDate: data.issueDate || "",
                      dueDate: data.dueDate || "",
                      totalAmount: String(data.totalAmount || data.total || ""),
                      client: data.client || "",
                      paymentMethod: data.paymentMethod || "",
                      tempPdfPath: data.tempPath || "",
                      pdfUrl: data.pdfUrl || "",
                      clientId: data.clientId
                    });
                    
                    // Imposta l'URL del PDF per l'anteprima
                    if (data.pdfUrl) {
                      setPdfPreviewUrl(data.pdfUrl);
                    }
                    
                    // Mostra il modale di anteprima
                    setShowPreviewModal(true);
                    
                    // Salva i dati originali per riferimento
                    setOriginalExtractedData(data);
                    
                    toast({
                      title: "Anteprima dati",
                      description: "Controlla e modifica i dati estratti prima di applicarli",
                    });
                  } catch (error: any) {
                    console.error("Errore nell'estrazione dei dati dal PDF:", error);
                    toast({
                      title: "Errore",
                      description: typeof error === 'object' && error !== null && 'message' in error 
                        ? String(error.message) 
                        : "Impossibile estrarre i dati dal PDF",
                      variant: "destructive",
                    });
                  }
                }}
                label="PDF Fattura"
              />
            </div>
            )}
            
            {/* Per fatture esistenti, mostro la gestione completa dei documenti */}
            {invoice && invoice.id && (
              <div className="mt-4">
                <div className="text-sm text-muted-foreground mb-2">
                  Per sostituire il PDF principale usa il selettore di seguito. Per gestire tutti i documenti, salva prima la fattura.
                </div>
                <FileUpload
                  onFileChange={(file) => {
                    if (file) {
                      setPdfFile(file);
                      const fileUrl = URL.createObjectURL(file);
                      setPdfPreviewUrl(fileUrl);
                      
                      toast({
                        title: "File selezionato",
                        description: `Il file "${file.name}" verrà caricato al salvataggio della fattura.`,
                      });
                    }
                  }}
                  onPreviewPdf={() => {
                    if (pdfPreviewUrl) {
                      setShowPdfPreview(true);
                    } else if (invoice?.pdfPath) {
                      // Usa il percorso esistente per l'anteprima
                      setShowPdfPreview(true);
                    } else {
                      toast({
                        title: "Nessun file disponibile",
                        description: "Non c'è nessun PDF da visualizzare.",
                        variant: "destructive",
                      });
                    }
                  }}
                  pdfUrl={pdfPreviewUrl || invoice?.pdfPath}
                  label="Sostituisci PDF principale"
                  initialFile={invoice?.pdfPath}
                />
              </div>
            )}
          </div>
        </div>
        
        {/* Pulsanti del form */}
        <div className="flex justify-end space-x-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => onSuccess()}
          >
            Annulla
          </Button>
          <Button 
            type="submit" 
            disabled={createInvoice.isPending || updateInvoice.isPending}
          >
            {createInvoice.isPending || updateInvoice.isPending ? 
              "Salvataggio..." : 
              invoice ? "Aggiorna Fattura" : "Crea Fattura"}
          </Button>
        </div>
      </form>

      {/* Modal per visualizzare l'anteprima PDF e i dati estratti */}
      <Dialog open={showPreviewModal} onOpenChange={setShowPreviewModal}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle>Anteprima dati estratti</DialogTitle>
            <DialogDescription>
              Puoi modificare i dati estratti prima di applicarli al form
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-4">
            {/* Colonna sinistra: anteprima PDF */}
            <div className="h-[70vh] border rounded-md overflow-hidden bg-gray-50">
              {pdfPreviewUrl && (
                <SimplePdfViewer 
                  pdfUrl={pdfPreviewUrl} 
                  className="w-full h-full"
                  showControls={true}
                />
              )}
              {!pdfPreviewUrl && (
                <div className="flex items-center justify-center h-full">
                  <p className="text-gray-500">Nessun PDF disponibile per l'anteprima</p>
                </div>
              )}
            </div>
            
            {/* Colonna destra: dati estratti */}
            <div className="space-y-4">
              {extractedData && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Numero Fattura</label>
                    <Input
                      value={extractedData.invoiceNumber}
                      onChange={(e) => setExtractedData({
                        ...extractedData,
                        invoiceNumber: e.target.value
                      })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Data Emissione</label>
                    <Input
                      type="date"
                      value={extractedData.issueDate}
                      onChange={(e) => setExtractedData({
                        ...extractedData,
                        issueDate: e.target.value
                      })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Data Scadenza</label>
                    <Input
                      type="date"
                      value={extractedData.dueDate}
                      onChange={(e) => setExtractedData({
                        ...extractedData,
                        dueDate: e.target.value
                      })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Importo Totale</label>
                    <Input
                      type="number"
                      step="0.01"
                      value={extractedData.totalAmount}
                      onChange={(e) => setExtractedData({
                        ...extractedData,
                        totalAmount: e.target.value
                      })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Cliente</label>
                    <div className="flex space-x-2">
                      <Input
                        value={extractedData.client}
                        onChange={(e) => setExtractedData({
                          ...extractedData,
                          client: e.target.value
                        })}
                        className="flex-1"
                      />
                      
                      {extractedData.clientId && (
                        <Select
                          value={String(extractedData.clientId)}
                          onValueChange={(value) => setExtractedData({
                            ...extractedData,
                            clientId: parseInt(value)
                          })}
                        >
                          <SelectTrigger className="w-[180px]">
                            <SelectValue placeholder="Cliente..." />
                          </SelectTrigger>
                          <SelectContent>
                            {clients.map((client) => (
                              <SelectItem key={client.id} value={String(client.id)}>
                                {client.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Metodo di Pagamento</label>
                    <Input
                      value={extractedData.paymentMethod}
                      onChange={(e) => setExtractedData({
                        ...extractedData,
                        paymentMethod: e.target.value
                      })}
                    />
                  </div>
                </div>
              )}
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowPreviewModal(false)}
                >
                  Annulla
                </Button>
                <Button onClick={applyExtractedData}>
                  Usa Questi Dati
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal per la visualizzazione del PDF a schermo intero */}
      <Dialog open={showPdfPreview} onOpenChange={setShowPdfPreview}>
        <DialogContent className="max-w-5xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Anteprima PDF</DialogTitle>
          </DialogHeader>
          
          <div className="h-[80vh] border rounded-md overflow-hidden">
            {pdfPreviewUrl ? (
              <SimplePdfViewer 
                pdfUrl={pdfPreviewUrl} 
                className="w-full h-full"
                showControls={true}
              />
            ) : (
              <div className="flex items-center justify-center h-full">
                <p className="text-gray-500">Nessun PDF disponibile per l'anteprima</p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
      {/* Dialog per il gestore dei documenti */}
      <Dialog open={showPdfManager} onOpenChange={setShowPdfManager}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Gestione Documenti</DialogTitle>
            <DialogDescription>
              Gestisci i documenti associati a questa fattura
            </DialogDescription>
          </DialogHeader>
          
          {invoice && invoice.id && (
            <PdfManager 
              invoiceId={invoice.id} 
              initialPdfPath={invoice.pdfPath}
              onSuccessfulUpload={() => {
                queryClient.invalidateQueries({ queryKey: [`/api/admin/invoices/${invoice.id}`] });
                toast({
                  title: "Documenti aggiornati",
                  description: "I documenti sono stati aggiornati con successo",
                });
              }}
            />
          )}
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowPdfManager(false)}
            >
              Chiudi
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Form>
  );
}