import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { formatDate, convertDateForInput, convertDateForDisplay } from "@/lib/utils";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FileUpload } from "@/components/ui/file-upload";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Trash, Plus, File, Check, X, Edit, FileText } from "lucide-react";
import { Client, Invoice, InvoiceItem } from "@shared/schema";
import { useEffect, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { SimplePdfViewer } from "@/components/simple-pdf-viewer";

interface InvoiceFormProps {
  onSuccess: () => void;
  invoice?: Invoice & { items?: InvoiceItem[] };
}

const invoiceItemSchema = z.object({
  id: z.number().optional(),
  description: z.string().min(1, "La descrizione è obbligatoria"),
  quantity: z.string().min(1, "La quantità è obbligatoria").refine((val) => !isNaN(Number(val)) && Number(val) > 0, {
    message: "La quantità deve essere un numero positivo",
  }),
  price: z.string().min(1, "Il prezzo è obbligatorio").refine((val) => !isNaN(Number(val)) && Number(val) >= 0, {
    message: "Il prezzo deve essere un numero positivo",
  }),
  total: z.string().optional(),
});

const formSchema = z.object({
  number: z.string().min(1, "Il numero fattura è obbligatorio"),
  clientId: z.string().min(1, "Il cliente è obbligatorio"),
  issueDate: z.string().min(1, "La data di emissione è obbligatoria"),
  dueDate: z.string().min(1, "La data di scadenza è obbligatoria"),
  amount: z.string().min(1, "L'importo è obbligatorio").refine((val) => !isNaN(Number(val)) && Number(val) > 0, {
    message: "L'importo deve essere un numero positivo",
  }),
  status: z.string().min(1, "Lo stato è obbligatorio"),
  paymentType: z.string().optional(),
  paymentDate: z.string().optional(),
  notes: z.string().optional(),
  items: z.array(invoiceItemSchema).optional(),
  isFromPdf: z.boolean().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export function InvoiceForm({ onSuccess, invoice }: InvoiceFormProps) {
  const { toast } = useToast();
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [showPreviewModal, setShowPreviewModal] = useState<boolean>(false);
  const [extractedData, setExtractedData] = useState<{
    invoiceNumber: string;
    issueDate: string;
    dueDate: string;
    totalAmount: string;
    client: string;
    paymentMethod: string;
    tempPdfPath?: string;
    pdfUrl?: string;  // Aggiungiamo questo campo per l'URL diretto al PDF
    clientId?: number;
  } | null>(null);
  const [originalExtractedData, setOriginalExtractedData] = useState<any>(null);
  const [pdfPreviewUrl, setPdfPreviewUrl] = useState<string | null>(
    invoice?.pdfPath ? `/uploads/${invoice.pdfPath.split('/').pop()}` : null
  );
  const [showPdfPreview, setShowPdfPreview] = useState<boolean>(false);
  
  // Fetch clients
  const { data: clients = [] } = useQuery<Client[]>({
    queryKey: ['/api/admin/clients'],
    staleTime: 60000, // 1 minute
  });

  // Set up form with default values
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: invoice
      ? {
          number: invoice.number,
          clientId: String(invoice.clientId),
          // Usiamo il formato ISO per l'input type="date" (YYYY-MM-DD)
          issueDate: new Date(invoice.issueDate).toISOString().split('T')[0],
          dueDate: new Date(invoice.dueDate).toISOString().split('T')[0],
          amount: String(invoice.amount),
          status: invoice.status,
          paymentType: invoice.paymentType || "",
          paymentDate: invoice.paymentDate 
            ? new Date(invoice.paymentDate).toISOString().split('T')[0] 
            : "",
          notes: invoice.notes || "",
          items: invoice.items?.map(item => ({
            id: item.id,
            description: item.description,
            quantity: String(item.quantity),
            price: String(item.price),
            total: String(item.total)
          })) || [],
        }
      : {
          number: "",
          clientId: "",
          // Date nel formato ISO (YYYY-MM-DD) richiesto dall'input HTML
          issueDate: new Date().toISOString().split('T')[0],
          dueDate: new Date(new Date().setDate(new Date().getDate() + 30)).toISOString().split('T')[0],
          amount: "",
          status: "pending",
          paymentType: "",
          paymentDate: "",
          notes: "",
          items: [
            {
              description: "",
              quantity: "1",
              price: "0",
              total: "0"
            }
          ],
        },
  });

  // Ottieni i controlli per il campo 'items'
  const { fields, append, remove, update } = useFieldArray({
    control: form.control,
    name: "items",
  });

  // Update item total when quantity or price changes
  const updateItemTotal = (index: number) => {
    try {
      const items = form.getValues("items") || [];
      if (!items[index]) return;
      
      const item = items[index];
      const quantity = parseFloat(item.quantity) || 0;
      const price = parseFloat(item.price) || 0;
      const total = (quantity * price).toFixed(2);
      
      // Aggiorna direttamente usando l'API useFieldArray
      update(index, {
        ...item,
        quantity: String(quantity), // Assicurati che siano stringhe
        price: String(price),
        total: total
      });
      
      // Ricalcola il totale complessivo
      setTimeout(() => {
        const updatedItems = form.getValues("items") || [];
        let totalAmount = 0;
        updatedItems.forEach(item => {
          totalAmount += parseFloat(item.total || "0");
        });
        
        form.setValue("amount", totalAmount.toFixed(2));
      }, 0);
    } catch (error) {
      console.error("Errore nell'aggiornamento del totale:", error);
    }
  };

  // Handle form submission
  const createInvoice = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await fetch("/api/admin/invoices", {
        method: "POST",
        body: data,
        credentials: "include"
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to create invoice");
      }
      
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Fattura creata",
        description: "La fattura è stata creata con successo",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/invoices'] });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: `Impossibile creare la fattura: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const updateInvoice = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await fetch(`/api/admin/invoices/${invoice?.id}`, {
        method: "PUT",
        body: data,
        credentials: "include"
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to update invoice");
      }
      
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Fattura aggiornata",
        description: "La fattura è stata aggiornata con successo",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/invoices'] });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: `Impossibile aggiornare la fattura: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const onSubmit = (values: FormValues) => {
    const formData = new FormData();
    
    console.log("Form values before formatting:", values);
    
    // Risolviamo un bug comune: se l'utente compila la data di pagamento ma dimentica
    // di cambiare lo stato in "paid", lo facciamo automaticamente.
    if (values.paymentDate && values.status === "pending") {
      values.status = "paid";
      
      // Aggiorniamo visivamente il valore dell'input select
      toast({
        title: "Nota",
        description: "Stato impostato automaticamente a 'Pagata' poiché è presente una data di pagamento.",
      });
    }
    
    // Convert clientId to number and format dates as strings
    const formattedValues = {
      ...values,
      clientId: parseInt(values.clientId),
      // Inviamo le date come stringhe ISO per evitare problemi di serializzazione
      issueDate: values.issueDate,
      dueDate: values.dueDate,
      paymentDate: values.paymentDate || undefined,
      // Convertiamo l'amount in numero
      amount: parseFloat(values.amount),
    };
    
    console.log("Formatted values:", formattedValues);
    
    formData.append("data", JSON.stringify(formattedValues));
    
    // Se abbiamo un PDF, lo alleghiamo alla richiesta
    if (pdfFile) {
      formData.append("pdf", pdfFile);
    }
    
    // Quando modifichiamo una fattura esistente
    if (invoice) {
      // Aggiungiamo l'ID della fattura come parametro esplicito per evitare problemi
      formData.append("invoiceId", String(invoice.id));
      // Inviamo anche il path del file PDF esistente, se presente
      if (invoice.pdfPath && !pdfFile) {
        formData.append("existingPdfPath", invoice.pdfPath);
      }
      updateInvoice.mutate(formData);
    } else {
      createInvoice.mutate(formData);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-6">
            <FormField
              control={form.control}
              name="number"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Numero Fattura</FormLabel>
                  <FormControl>
                    <Input placeholder="FTTR-2023/001" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="clientId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Cliente</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleziona cliente" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {clients.map((client) => (
                        <SelectItem key={client.id} value={String(client.id)}>
                          {client.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="issueDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Data Emissione</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Data Scadenza</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Stato</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleziona stato" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="pending">In attesa</SelectItem>
                      <SelectItem value="paid">Pagata</SelectItem>
                      <SelectItem value="overdue">Scaduta</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="paymentType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tipo Pagamento</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleziona tipo pagamento" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="">Seleziona tipo pagamento</SelectItem>
                        <SelectItem value="bank_transfer">Bonifico bancario</SelectItem>
                        <SelectItem value="credit_card">Carta di credito</SelectItem>
                        <SelectItem value="cash">Contanti</SelectItem>
                        <SelectItem value="paypal">PayPal</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="paymentDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Data Pagamento</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Note</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Aggiungi note o dettagli aggiuntivi..." 
                      className="min-h-[120px]" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="space-y-6">
            {!form.getValues("isFromPdf") ? (
              <div>
                <h3 className="text-lg font-medium mb-4">Voci fattura</h3>
                
                {fields.map((field, index) => (
                <Card key={index} className="mb-4">
                  <CardContent className="pt-4">
                    <div className="grid grid-cols-[1fr,auto] gap-2">
                      <FormField
                        control={form.control}
                        name={`items.${index}.description`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Descrizione</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="pt-8">
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => remove(index)}
                          disabled={(form.getValues("items")?.length || 0) <= 1}
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-2 mt-2">
                      <FormField
                        control={form.control}
                        name={`items.${index}.quantity`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Quantità</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                type="number" 
                                min="1" 
                                step="1"
                                onChange={(e) => {
                                  field.onChange(e);
                                  updateItemTotal(index);
                                }}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name={`items.${index}.price`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Prezzo unitario (€)</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                type="number" 
                                min="0" 
                                step="0.01"
                                onChange={(e) => {
                                  field.onChange(e);
                                  updateItemTotal(index);
                                }}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name={`items.${index}.total`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Totale (€)</FormLabel>
                            <FormControl>
                              <Input {...field} readOnly />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              <Button
                type="button"
                variant="outline"
                className="w-full mt-2"
                onClick={() => 
                  append({
                    description: "",
                    quantity: "1",
                    price: "0",
                    total: "0"
                  })
                }
              >
                <Plus className="mr-2 h-4 w-4" />
                Aggiungi voce
              </Button>
              </div>
            ) : (
              <div className="bg-muted p-4 rounded-md mb-4">
                <h3 className="text-lg font-medium mb-2">Importato da PDF</h3>
                <p className="text-muted-foreground mb-2">Questa fattura è stata importata direttamente da un PDF.</p>
                <p>Viene utilizzato l'importo totale estratto dal documento senza dettaglio voci.</p>
              </div>
            )}
            
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Importo Totale (€)</FormLabel>
                  <FormControl>
                    <Input {...field} readOnly />
                  </FormControl>
                  <FormDescription>
                    Calcolato automaticamente dalle voci.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="mt-4">
              <FileUpload
                onFileChange={(file) => {
                  if (file) {
                    setPdfFile(file);
                    
                    // Crea URL per l'anteprima del file appena caricato
                    const fileUrl = URL.createObjectURL(file);
                    setPdfPreviewUrl(fileUrl);
                    
                    // Mostra un toast che conferma il caricamento del file
                    toast({
                      title: "File caricato",
                      description: `File "${file.name}" pronto per l'estrazione. Usa il pulsante "Estrai dati da PDF" per importare i valori.`,
                    });
                  }
                }}
                onPreviewPdf={() => {
                  // Se abbiamo un pdfPreviewUrl, mostriamo il PDF
                  if (pdfPreviewUrl) {
                    setShowPdfPreview(true);
                  } else {
                    toast({
                      title: "Nessun PDF disponibile",
                      description: "Non c'è nessun PDF associato a questa fattura",
                      variant: "destructive",
                    });
                  }
                }}
                pdfUrl={pdfPreviewUrl}
                onImportData={async () => {
                  if (!pdfFile) {
                    toast({
                      title: "Errore",
                      description: "Nessun file PDF selezionato",
                      variant: "destructive",
                    });
                    return;
                  }
                  
                  const formData = new FormData();
                  formData.append("pdf", pdfFile);
                  // Usa il file name originale per evitare problemi di visualizzazione
                  formData.append("originalName", pdfFile.name);
                  
                  try {
                    // Mostra un toast di caricamento
                    toast({
                      title: "Elaborazione in corso",
                      description: "Stiamo estraendo i dati dal PDF...",
                    });
                    
                    const response = await fetch("/api/admin/invoices/extract", {
                      method: "POST",
                      body: formData,
                      credentials: "include"
                    });
                    
                    if (!response.ok) {
                      const errorData = await response.json();
                      throw new Error(errorData.message || "Errore nell'estrazione dei dati");
                    }
                    
                    const data = await response.json();
                    console.log("Dati estratti dal PDF:", data);
                    
                    // Se non ci sono dati estratti
                    // Controlliamo per essere sicuri che ci siano dati validi
                    // Utilizziamo sia il formato vecchio (totalAmount) che quello nuovo (total) introdotto nell'API
                    if (!data.invoiceNumber && !data.issueDate && 
                        !data.totalAmount && !data.total && 
                        !data.client && !data.dueDate) {
                      console.error("Nessun dato estratto dal PDF:", data);
                      toast({
                        title: "Attenzione",
                        description: "Non è stato possibile estrarre dati significativi dal PDF. Compilare i campi manualmente.",
                        variant: "destructive",
                      });
                      return;
                    }
                    
                    // Mostra l'interfaccia di modifica con i dati estratti
                    setExtractedData({
                      invoiceNumber: data.invoiceNumber || "",
                      issueDate: data.issueDate || "",
                      dueDate: data.dueDate || "",
                      totalAmount: String(data.totalAmount || data.total || ""),
                      client: data.client || "",
                      paymentMethod: data.paymentMethod || "",
                      tempPdfPath: data.tempPath || "",
                      pdfUrl: data.pdfUrl || "",
                      clientId: data.clientId
                    });
                    
                    // Imposta l'URL del PDF per l'anteprima
                    if (data.pdfUrl) {
                      setPdfPreviewUrl(data.pdfUrl);
                    }
                    
                    // Mostra il modale di anteprima
                    setShowPreviewModal(true);
                    
                    // In questo punto non aggiorniamo più il form direttamente,
                    // ma lo faremo dopo che l'utente ha confermato i dati nel modale
                    
                    // Salviamo i dati originali per debug/riferimento
                    setOriginalExtractedData(data);
                    
                    // Ora mostriamo tutto nel modale e non aggiorniamo automaticamente il form
                    toast({
                      title: "Anteprima dati",
                      description: "Controlla e modifica i dati estratti prima di applicarli",
                    });
                  } catch (error: any) {
                    console.error("Errore nell'estrazione dei dati dal PDF:", error);
                    toast({
                      title: "Errore",
                      description: typeof error === 'object' && error !== null && 'message' in error 
                        ? String(error.message) 
                        : "Impossibile estrarre i dati dal PDF",
                      variant: "destructive",
                    });
                  }
                }}
                label="PDF Fattura"
              />
            </div>
          </div>
        </div>
        
        {/* Modal per visualizzare l'anteprima PDF e i dati estratti */}
        <Dialog open={showPreviewModal} onOpenChange={setShowPreviewModal}>
          <DialogContent className="max-w-5xl max-h-[90vh] overflow-auto">
            <DialogHeader>
              <DialogTitle>Anteprima dati estratti</DialogTitle>
              <DialogDescription>
                Puoi modificare i dati estratti prima di applicarli al form
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-4">
              {/* Colonna sinistra: anteprima PDF */}
              <div className="h-[70vh] border rounded-md overflow-hidden bg-gray-50">
                {/* Utilizziamo prima l'URL preso direttamente dalla risposta API */}
                {pdfPreviewUrl && (
                  <SimplePdfViewer 
                    pdfUrl={pdfPreviewUrl} 
                    className="w-full h-full"
                    showControls={true}
                  />
                )}
                {/* Fallback al percorso dalla proprietà pdfUrl dell'API */}
                {!pdfPreviewUrl && originalExtractedData?.pdfUrl && (
                  <SimplePdfViewer 
                    pdfUrl={originalExtractedData.pdfUrl} 
                    className="w-full h-full"
                    showControls={true}
                  />
                )}
                {/* Secondo fallback: utilizza direttamente pdfUrl dall'extracted data */}
                {!pdfPreviewUrl && !originalExtractedData?.pdfUrl && extractedData?.pdfUrl && (
                  <SimplePdfViewer 
                    pdfUrl={extractedData.pdfUrl} 
                    className="w-full h-full"
                    showControls={true}
                  />
                )}
                {/* Terzo fallback: costruisci l'URL usando il percorso del file */}
                {!pdfPreviewUrl && !originalExtractedData?.pdfUrl && !extractedData?.pdfUrl && extractedData?.tempPdfPath && (
                  <SimplePdfViewer 
                    pdfUrl={`/api/temp/${encodeURIComponent(extractedData.tempPdfPath.split('/').pop() || '')}`} 
                    className="w-full h-full"
                    showControls={true}
                  />
                )}
                {/* Debug dell'URL - mostrato per diagnostica */}
                {(extractedData?.tempPdfPath || extractedData?.pdfUrl) && (
                  <div className="bg-amber-50 p-2 text-xs rounded mb-2 border border-amber-200">
                    <div><strong>Debug percorsi PDF:</strong></div>
                    {extractedData?.pdfUrl && (
                      <div>URL diretto: <code>{extractedData.pdfUrl}</code></div>
                    )}
                    {extractedData?.tempPdfPath && (
                      <>
                        <div>URL costruito: <code>{`/api/temp/${encodeURIComponent(extractedData.tempPdfPath.split('/').pop() || '')}`}</code></div>
                        <div>Percorso originale: <code>{extractedData.tempPdfPath}</code></div>
                        <div>Nome file estratto: <code>{extractedData.tempPdfPath.split('/').pop()}</code></div>
                      </>
                    )}
                    {originalExtractedData && (
                      <>
                        <div>tempPath da API: <code>{originalExtractedData.tempPath}</code></div>
                        <div>pdfUrl da API: <code>{originalExtractedData.pdfUrl}</code></div>
                      </>
                    )}
                  </div>
                )}
                {/* Nessun percorso disponibile */}
                {!pdfPreviewUrl && !originalExtractedData?.pdfUrl && !extractedData?.tempPdfPath && (
                  <div className="flex items-center justify-center h-full">
                    <p className="text-gray-500">Nessun PDF disponibile per l'anteprima</p>
                  </div>
                )}
              </div>
              
              {/* Colonna destra: dati estratti */}
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Dati estratti dal PDF</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {extractedData && (
                      <>
                        <div className="space-y-2">
                          <Label htmlFor="preview-invoice-number">Numero Fattura</Label>
                          <Input 
                            id="preview-invoice-number" 
                            value={extractedData.invoiceNumber}
                            onChange={(e) => setExtractedData({
                              ...extractedData,
                              invoiceNumber: e.target.value
                            })}
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="preview-issue-date">Data Emissione</Label>
                            <Input 
                              id="preview-issue-date" 
                              value={extractedData.issueDate}
                              onChange={(e) => setExtractedData({
                                ...extractedData,
                                issueDate: e.target.value
                              })}
                            />
                          </div>
                          
                          <div className="space-y-2">
                            <Label htmlFor="preview-due-date">Data Scadenza</Label>
                            <Input 
                              id="preview-due-date" 
                              value={extractedData.dueDate}
                              onChange={(e) => setExtractedData({
                                ...extractedData,
                                dueDate: e.target.value
                              })}
                            />
                          </div>
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="preview-total-amount">Importo Totale</Label>
                          <Input 
                            id="preview-total-amount" 
                            value={extractedData.totalAmount}
                            onChange={(e) => setExtractedData({
                              ...extractedData,
                              totalAmount: e.target.value
                            })}
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="preview-client">Cliente</Label>
                          <div className="flex gap-2">
                            <Input 
                              id="preview-client" 
                              value={extractedData.client}
                              onChange={(e) => setExtractedData({
                                ...extractedData,
                                client: e.target.value
                              })}
                              className="flex-grow"
                            />
                            {extractedData.clientId && (
                              <div className="flex items-center gap-1 px-2 py-1 bg-green-50 text-green-700 rounded-md border border-green-200 text-xs">
                                <Check className="h-3 w-3" /> 
                                Cliente trovato
                              </div>
                            )}
                          </div>
                          
                          {!extractedData.clientId && extractedData.client && (
                            <div className="mt-2">
                              <Select 
                                onValueChange={(value) => setExtractedData({
                                  ...extractedData,
                                  clientId: parseInt(value)
                                })}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="Associa a un cliente esistente" />
                                </SelectTrigger>
                                <SelectContent>
                                  {clients.map((client) => (
                                    <SelectItem key={client.id} value={String(client.id)}>
                                      {client.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          )}
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="preview-payment-method">Metodo Pagamento</Label>
                          <Input 
                            id="preview-payment-method" 
                            value={extractedData.paymentMethod}
                            onChange={(e) => setExtractedData({
                              ...extractedData,
                              paymentMethod: e.target.value
                            })}
                          />
                        </div>
                      </>
                    )}
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button 
                      variant="outline" 
                      onClick={() => setShowPreviewModal(false)}
                    >
                      <X className="mr-2 h-4 w-4" />
                      Annulla
                    </Button>
                    <Button 
                      onClick={() => {
                        if (!extractedData) return;
                        
                        // Applica i dati estratti al form
                        if (extractedData.invoiceNumber) {
                          form.setValue("number", extractedData.invoiceNumber);
                        }
                        
                        // Formatta e applica le date
                        const formatDate = (dateStr: string) => {
                          try {
                            if (!dateStr) return null;
                            
                            // Se è una data nel formato DD/MM/YYYY
                            if (dateStr.includes('/')) {
                              const parts = dateStr.split('/');
                              if (parts.length === 3) {
                                // Converto nel formato YYYY-MM-DD per l'input HTML
                                return `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
                              }
                            }
                            
                            // Se è già in formato ISO o altro formato valido
                            const date = new Date(dateStr);
                            if (!isNaN(date.getTime())) {
                              return date.toISOString().split('T')[0];
                            }
                            
                            return dateStr;
                          } catch (e) {
                            console.error("Errore nella formattazione della data:", e);
                            return dateStr;
                          }
                        };
                        
                        if (extractedData.issueDate) {
                          const formattedDate = formatDate(extractedData.issueDate);
                          if (formattedDate) form.setValue("issueDate", formattedDate);
                        }
                        
                        if (extractedData.dueDate) {
                          const formattedDate = formatDate(extractedData.dueDate);
                          if (formattedDate) form.setValue("dueDate", formattedDate);
                        } else if (extractedData.issueDate) {
                          // Se non c'è data di scadenza ma c'è data di emissione, imposta la data di scadenza 30 giorni dopo
                          try {
                            const issueDate = new Date(formatDate(extractedData.issueDate) || '');
                            if (!isNaN(issueDate.getTime())) {
                              const dueDate = new Date(issueDate);
                              dueDate.setDate(issueDate.getDate() + 30);
                              form.setValue("dueDate", dueDate.toISOString().split('T')[0]);
                            }
                          } catch (e) {
                            console.error("Errore nel calcolo della data di scadenza:", e);
                          }
                        }
                        
                        // Imposta l'importo totale
                        if (extractedData.totalAmount) {
                          try {
                            // Assicurati che l'importo sia un numero valido
                            let amountStr = String(extractedData.totalAmount).trim();
                            let amount;
                            
                            // Gestisci diversi formati di numeri
                            if (amountStr.includes(',') && amountStr.includes('.')) {
                              // Formato con separatori di migliaia e decimali
                              const lastCommaIndex = amountStr.lastIndexOf(',');
                              const lastDotIndex = amountStr.lastIndexOf('.');
                              
                              if (lastCommaIndex > lastDotIndex) {
                                // Formato italiano: 1.234,56 (virgola per decimali)
                                amountStr = amountStr.replace(/\./g, '').replace(',', '.');
                              } else {
                                // Formato inglese: 1,234.56 (punto per decimali)
                                amountStr = amountStr.replace(/,/g, '');
                              }
                            } else if (amountStr.includes(',')) {
                              // Solo virgole (es. 1234,56) - assumiamo formato italiano
                              amountStr = amountStr.replace(',', '.');
                            }
                            
                            // Rimuovi eventuali simboli valuta e spazi
                            amountStr = amountStr.replace(/[€$£]/g, '').trim();
                            
                            amount = parseFloat(amountStr);
                            
                            if (!isNaN(amount)) {
                              form.setValue("amount", amount.toFixed(2));
                              
                              // Imposta isFromPdf a true
                              form.setValue("isFromPdf", true);
                              
                              // Per le fatture caricate da PDF, usa una singola voce con l'importo totale
                              form.setValue("items", [{
                                description: "Importo totale fattura",
                                quantity: "1",
                                price: amount.toFixed(2),
                                total: amount.toFixed(2)
                              }]);
                            }
                          } catch (e) {
                            console.error("Errore nella formattazione dell'importo:", e);
                          }
                        }
                        
                        // Imposta il cliente
                        if (extractedData.clientId) {
                          form.setValue("clientId", String(extractedData.clientId));
                        }
                        
                        // Imposta il metodo di pagamento
                        if (extractedData.paymentMethod) {
                          // Cerca di mappare il testo del metodo di pagamento ai valori del form
                          const paymentMethodText = extractedData.paymentMethod.toLowerCase();
                          
                          if (paymentMethodText.includes('bonifico')) {
                            form.setValue("paymentType", "bank_transfer");
                          } else if (paymentMethodText.includes('carta')) {
                            form.setValue("paymentType", "credit_card");
                          } else if (paymentMethodText.includes('contanti')) {
                            form.setValue("paymentType", "cash");
                          } else if (paymentMethodText.includes('paypal')) {
                            form.setValue("paymentType", "paypal");
                          }
                        }
                        
                        // Chiudi il modale
                        setShowPreviewModal(false);
                        
                        toast({
                          title: "Dati applicati",
                          description: "I dati estratti sono stati applicati al form",
                        });
                      }}
                    >
                      <Check className="mr-2 h-4 w-4" />
                      Applica dati
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </div>
          </DialogContent>
        </Dialog>
        
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onSuccess}>
            Annulla
          </Button>
          <Button type="submit" disabled={createInvoice.isPending || updateInvoice.isPending}>
            {createInvoice.isPending || updateInvoice.isPending
              ? "Salvataggio in corso..."
              : invoice
              ? "Aggiorna Fattura"
              : "Crea Fattura"
            }
          </Button>
        </div>
      </form>
      
      {/* Modal per visualizzare l'anteprima PDF */}
      <Dialog open={showPdfPreview} onOpenChange={setShowPdfPreview}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle>Anteprima PDF</DialogTitle>
            <DialogDescription>
              Visualizza il documento PDF associato a questa fattura
            </DialogDescription>
          </DialogHeader>
          
          <div className="h-[70vh] border rounded-md overflow-hidden bg-gray-50">
            {pdfPreviewUrl && (
              <SimplePdfViewer 
                pdfUrl={pdfPreviewUrl} 
                className="w-full h-full"
                showControls={true}
              />
            )}
            {!pdfPreviewUrl && (
              <div className="flex items-center justify-center h-full">
                <p className="text-gray-500">Nessun PDF disponibile per l'anteprima</p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </Form>
  );
}
