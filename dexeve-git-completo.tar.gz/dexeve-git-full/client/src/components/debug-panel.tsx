import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { useLocation } from "wouter";
import { useIsMobile } from "@/hooks/use-mobile";

export function DebugPanel() {
  const [isOpen, setIsOpen] = useState(false);
  const { user, isLoading, error, loginMutation, logoutMutation } = useAuth();
  const [location, setLocation] = useLocation();
  const isMobile = useIsMobile();

  const handleLogin = (role: string) => {
    if (role === 'admin') {
      loginMutation.mutate({
        username: "admin",
        password: "password"
      });
    } else {
      loginMutation.mutate({
        username: "mario",
        password: "password"
      });
    }
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const navigateTo = (path: string) => {
    setLocation(path);
  };

  if (!isOpen) {
    return (
      <Button 
        onClick={() => setIsOpen(true)} 
        className="fixed bottom-20 right-4 z-50 bg-gray-800 hover:bg-gray-700"
        size="sm"
      >
        Debug
      </Button>
    );
  }

  return (
    <div className="fixed bottom-20 right-4 z-50 bg-white shadow-lg rounded-lg p-4 w-80 border overflow-auto max-h-[80vh]">
      <div className="flex justify-between items-center mb-2">
        <h3 className="font-semibold">Debug Panel</h3>
        <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      
      <div className="space-y-2 text-xs">
        <div className="bg-gray-100 p-2 rounded">
          <p><b>Auth Status:</b> {isLoading ? "Loading..." : user ? "Authenticated" : "Not authenticated"}</p>
          {user && (
            <p><b>User:</b> {user.name} ({user.role})</p>
          )}
          <p><b>Current Path:</b> {location}</p>
          <p><b>Device:</b> {isMobile ? "Mobile" : "Desktop"}</p>
          <p><b>Screen Width:</b> <span id="screen-width">{typeof window !== 'undefined' ? window.innerWidth : '--'}</span>px</p>
          {error && (
            <p className="text-red-500"><b>Error:</b> {error.message}</p>
          )}
          <p><b>Auth Provider Status:</b> {isLoading ? "Loading..." : "Ready"}</p>
        </div>
        
        <div className="space-y-2">
          <div className="flex flex-col space-y-1">
            <h4 className="font-medium">Authentication</h4>
            <div className="flex space-x-2">
              <Button 
                onClick={() => handleLogin('admin')} 
                size="sm" 
                variant="default" 
                className="text-xs"
                disabled={loginMutation.isPending}
              >
                Login as Admin
              </Button>
              <Button 
                onClick={() => handleLogin('client')} 
                size="sm" 
                variant="default" 
                className="text-xs"
                disabled={loginMutation.isPending}
              >
                Login as Client
              </Button>
            </div>
            <Button 
              onClick={handleLogout} 
              size="sm" 
              variant="destructive" 
              className="text-xs"
              disabled={logoutMutation.isPending}
            >
              Logout
            </Button>
          </div>
          
          <div className="flex flex-col space-y-1">
            <h4 className="font-medium">Navigation</h4>
            <div className="grid grid-cols-2 gap-1">
              <Button 
                onClick={() => navigateTo("/")} 
                size="sm" 
                variant="outline" 
                className="text-xs"
              >
                Dashboard
              </Button>
              <Button 
                onClick={() => navigateTo("/invoices")} 
                size="sm" 
                variant="outline" 
                className="text-xs"
              >
                Invoices
              </Button>
              <Button 
                onClick={() => navigateTo("/clients")} 
                size="sm" 
                variant="outline" 
                className="text-xs"
              >
                Clients
              </Button>
              <Button 
                onClick={() => navigateTo("/settings")} 
                size="sm" 
                variant="outline" 
                className="text-xs"
              >
                Settings
              </Button>
              <div className="col-span-2">
                <Button 
                  onClick={() => navigateTo("/auth")} 
                  size="sm" 
                  variant="outline" 
                  className="text-xs w-full"
                >
                  Login Page
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}