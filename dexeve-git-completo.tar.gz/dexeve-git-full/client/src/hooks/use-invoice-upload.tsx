import { useState } from 'react';
import { queryClient } from '@/lib/queryClient';

interface UploadResponse {
  success: boolean;
  message: string;
  pdfPath?: string;
}

export function useInvoiceUpload() {
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const uploadPdfs = async (invoiceId: number, files: FileList): Promise<UploadResponse> => {
    if (!files || files.length === 0) {
      throw new Error("Nessun file selezionato");
    }
    
    setIsUploading(true);
    setError(null);
    
    try {
      const formData = new FormData();
      formData.append('invoiceId', invoiceId.toString());
      
      // Aggiungi tutti i file alla FormData
      Array.from(files).forEach((file, index) => {
        formData.append(`pdfFile${index}`, file);
      });
      
      const response = await fetch('/api/invoices/upload-pdf', {
        method: 'POST',
        body: formData,
        // Non impostare Content-Type, verrà impostato automaticamente con boundary
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Errore durante il caricamento del PDF');
      }
      
      const result = await response.json();
      
      // Invalida la cache delle fatture dopo il caricamento
      queryClient.invalidateQueries({ queryKey: ['/api/invoices'] });
      queryClient.invalidateQueries({ queryKey: ['/api/invoices', invoiceId] });
      
      return result;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Errore sconosciuto durante il caricamento';
      setError(errorMessage);
      throw err;
    } finally {
      setIsUploading(false);
    }
  };
  
  return {
    uploadPdfs,
    isUploading,
    error
  };
}