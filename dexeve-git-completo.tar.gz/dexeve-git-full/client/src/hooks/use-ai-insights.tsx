import { useMutation, useQuery } from "@tanstack/react-query";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Hook per ottenere insights AI su una fattura
export function useInvoiceInsights(invoiceId?: number) {
  const { toast } = useToast();
  
  return useQuery({
    queryKey: [`/api/admin/invoices/${invoiceId}/insights`],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!invoiceId,
    staleTime: 1000 * 60 * 5, // 5 minuti
    retry: 1,
    onError: (error: Error) => {
      toast({
        title: "Errore nell'analisi della fattura",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Hook per ottenere analisi delle tendenze di pagamento di un cliente
export function usePaymentTrends(clientId?: number) {
  const { toast } = useToast();
  
  return useQuery({
    queryKey: [`/api/admin/clients/${clientId}/payment-trends`],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!clientId,
    staleTime: 1000 * 60 * 5, // 5 minuti
    retry: 1,
    onError: (error: Error) => {
      toast({
        title: "Errore nell'analisi delle tendenze di pagamento",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Hook per ottenere il report sui pagamenti in sospeso
export function usePendingPaymentsReport() {
  const { toast } = useToast();
  
  return useQuery({
    queryKey: ["/api/admin/pending-payments-report"],
    queryFn: getQueryFn({ on401: "throw" }),
    staleTime: 1000 * 60 * 5, // 5 minuti
    retry: 1,
    onError: (error: Error) => {
      toast({
        title: "Errore nella generazione del report sui pagamenti in sospeso",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Hook per ottenere la probabilità di pagamento di una fattura
export function usePaymentProbability(invoiceId?: number) {
  const { toast } = useToast();
  
  return useQuery({
    queryKey: [`/api/admin/invoices/${invoiceId}/payment-probability`],
    queryFn: getQueryFn({ on401: "throw" }),
    enabled: !!invoiceId,
    staleTime: 1000 * 60 * 5, // 5 minuti
    retry: 1,
    onError: (error: Error) => {
      toast({
        title: "Errore nella previsione della probabilità di pagamento",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}