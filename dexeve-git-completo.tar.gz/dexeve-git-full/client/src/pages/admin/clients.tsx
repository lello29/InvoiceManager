import { useState } from "react";
import { ClientTrendsModal } from "@/components/dashboard/client-trends-modal";
import { Sidebar } from "@/components/dashboard/sidebar";
import { useQuery } from "@tanstack/react-query";
import { useIsMobile } from "@/hooks/use-mobile";
import { useAuth } from "@/hooks/use-auth";
import { Client } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardContent, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog, 
  DialogContent, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogDescription, 
  DialogClose 
} from "@/components/ui/dialog";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Search, Plus, Edit, Trash, User, Mail, Phone, MapPin, CreditCard, BrainCircuit } from "lucide-react";
import { formatCurrency } from "@/lib/utils";

// Client form schema
const clientSchema = z.object({
  name: z.string().min(1, "Il nome è obbligatorio"),
  email: z.string().email("Email non valida"),
  phone: z.string().optional(),
  address: z.string().optional(),
  taxId: z.string().optional(),
  userId: z.number().optional(),
});

type ClientFormValues = z.infer<typeof clientSchema>;

export default function AdminClients() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [clientToDelete, setClientToDelete] = useState<Client | null>(null);
  const [isTrendsModalOpen, setIsTrendsModalOpen] = useState(false);
  const [clientForTrends, setClientForTrends] = useState<Client | null>(null);
  const { toast } = useToast();

  // Fetch all clients
  const { data: clients = [], isLoading } = useQuery<Client[]>({
    queryKey: ['/api/admin/clients'],
  });

  // Filter clients based on search term
  const filteredClients = clients.filter(client => 
    client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (client.phone && client.phone.includes(searchTerm)) ||
    (client.taxId && client.taxId.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Setup forms
  const createForm = useForm<ClientFormValues>({
    resolver: zodResolver(clientSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      address: "",
      taxId: "",
      userId: 1, // Default to admin user for now
    },
  });

  const editForm = useForm<ClientFormValues>({
    resolver: zodResolver(clientSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      address: "",
      taxId: "",
      userId: 1,
    },
  });

  // Create client mutation
  const createClient = useMutation({
    mutationFn: async (data: ClientFormValues) => {
      const res = await apiRequest("POST", "/api/admin/clients", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Cliente creato",
        description: "Il cliente è stato creato con successo",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
      setIsCreateModalOpen(false);
      createForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: `Impossibile creare il cliente: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Update client mutation
  const updateClient = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: ClientFormValues }) => {
      const res = await apiRequest("PUT", `/api/admin/clients/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Cliente aggiornato",
        description: "Il cliente è stato aggiornato con successo",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
      setIsEditModalOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: `Impossibile aggiornare il cliente: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Delete client mutation
  const deleteClient = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/clients/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Cliente eliminato",
        description: "Il cliente è stato eliminato con successo",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
      setIsDeleteDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: `Impossibile eliminare il cliente: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Form handlers
  const onCreateSubmit = (values: ClientFormValues) => {
    createClient.mutate(values);
  };

  const onEditSubmit = (values: ClientFormValues) => {
    if (selectedClient) {
      updateClient.mutate({ id: selectedClient.id, data: values });
    }
  };

  const handleEditClick = (client: Client) => {
    setSelectedClient(client);
    editForm.reset({
      name: client.name,
      email: client.email,
      phone: client.phone || "",
      address: client.address || "",
      taxId: client.taxId || "",
      userId: client.userId,
    });
    setIsEditModalOpen(true);
  };

  const handleDeleteClick = (client: Client) => {
    setClientToDelete(client);
    setIsDeleteDialogOpen(true);
  };

  const handleConfirmDelete = () => {
    if (clientToDelete) {
      deleteClient.mutate(clientToDelete.id);
    }
  };
  
  const handleTrendsClick = (client: Client) => {
    setClientForTrends(client);
    setIsTrendsModalOpen(true);
  };

  const isMobile = useIsMobile();
  const { logoutMutation } = useAuth();

  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  return (
    <div className="flex h-screen overflow-hidden">
      {!isMobile && <Sidebar />}
      
      <div className={`flex-1 overflow-y-auto ${!isMobile ? "md:ml-64" : "ml-0"}`}>
        <main className="p-4 md:p-6 pb-20 md:pb-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-xl md:text-2xl font-semibold text-gray-900">Gestione Clienti</h1>
            <div className="flex items-center gap-2">
              {isMobile && (
                <Button variant="outline" size="sm" onClick={handleLogout}>
                  Esci
                </Button>
              )}
              <Button onClick={() => setIsCreateModalOpen(true)} size={isMobile ? "sm" : "default"}>
                <Plus className="mr-2 h-4 w-4" />
                {isMobile ? "Nuovo" : "Nuovo Cliente"}
              </Button>
            </div>
          </div>

          {/* Search */}
          <div className="mb-6 relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <Input 
              placeholder="Cerca clienti..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Clients Grid */}
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <p className="text-gray-500">Caricamento clienti...</p>
            </div>
          ) : (
            <div className="grid gap-6 grid-cols-1 lg:grid-cols-2">
              {filteredClients.length === 0 ? (
                <div className="col-span-full text-center py-12">
                  <p className="text-gray-500">Nessun cliente trovato</p>
                </div>
              ) : (
                filteredClients.map((client) => (
                  <Card key={client.id} className="overflow-hidden">
                    <CardHeader className="bg-gray-50 pb-4">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{client.name}</CardTitle>
                        <div className="flex space-x-1">
                          <Button variant="ghost" size="icon" onClick={() => handleEditClick(client)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDeleteClick(client)}>
                            <Trash className="h-4 w-4 text-red-600" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="pt-4">
                      <div className="space-y-3">
                        <div className="flex items-center">
                          <Mail className="h-4 w-4 text-gray-400 mr-2" />
                          <span className="text-sm">{client.email}</span>
                        </div>
                        
                        {client.phone && (
                          <div className="flex items-center">
                            <Phone className="h-4 w-4 text-gray-400 mr-2" />
                            <span className="text-sm">{client.phone}</span>
                          </div>
                        )}
                        
                        {client.address && (
                          <div className="flex items-center">
                            <MapPin className="h-4 w-4 text-gray-400 mr-2" />
                            <span className="text-sm">{client.address}</span>
                          </div>
                        )}
                        
                        {client.taxId && (
                          <div className="flex items-center">
                            <CreditCard className="h-4 w-4 text-gray-400 mr-2" />
                            <span className="text-sm">{client.taxId}</span>
                          </div>
                        )}
                      </div>
                    </CardContent>
                    
                    <CardFooter className="bg-gray-50 pt-4 flex justify-between border-t">
                      <div className="flex flex-col">
                        <div>
                          <p className="text-xs text-gray-500">Fatture totali: <span className="font-semibold">{client.totalInvoices}</span></p>
                          <p className="text-xs text-gray-500">
                            <span className="text-green-600 font-semibold">{client.paidInvoices} pagate</span> • 
                            <span className="text-yellow-600 font-semibold"> {client.pendingInvoices} in attesa</span> • 
                            <span className="text-red-600 font-semibold"> {client.overdueInvoices} scadute</span>
                          </p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="mt-2 text-xs flex gap-1 w-fit" 
                          onClick={(e) => {
                            e.preventDefault();
                            handleTrendsClick(client);
                          }}
                        >
                          <BrainCircuit className="h-3 w-3" />
                          Analisi AI
                        </Button>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-gray-500">Totale pagato</p>
                        <p className="font-semibold text-gray-900">{formatCurrency(Number(client.totalPaid) || 0)}</p>
                      </div>
                    </CardFooter>
                  </Card>
                ))
              )}
            </div>
          )}

          {/* Create Client Modal */}
          <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Nuovo Cliente</DialogTitle>
                <DialogDescription>
                  Inserisci i dati del nuovo cliente.
                </DialogDescription>
              </DialogHeader>
              
              <Form {...createForm}>
                <form onSubmit={createForm.handleSubmit(onCreateSubmit)} className="space-y-4">
                  <FormField
                    control={createForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nome</FormLabel>
                        <FormControl>
                          <Input placeholder="Mario Rossi" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={createForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input placeholder="mario.rossi@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={createForm.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Telefono</FormLabel>
                        <FormControl>
                          <Input placeholder="+39 123 456 7890" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={createForm.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Indirizzo</FormLabel>
                        <FormControl>
                          <Input placeholder="Via Roma 123, 00100 Roma (RM)" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={createForm.control}
                    name="taxId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Partita IVA</FormLabel>
                        <FormControl>
                          <Input placeholder="IT12345678901" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter>
                    <Button type="submit" disabled={createClient.isPending}>
                      {createClient.isPending ? "Creazione..." : "Crea Cliente"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>

          {/* Edit Client Modal */}
          <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Modifica Cliente</DialogTitle>
                <DialogDescription>
                  Modifica i dati del cliente.
                </DialogDescription>
              </DialogHeader>
              
              <Form {...editForm}>
                <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
                  <FormField
                    control={editForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nome</FormLabel>
                        <FormControl>
                          <Input placeholder="Mario Rossi" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input placeholder="mario.rossi@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editForm.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Telefono</FormLabel>
                        <FormControl>
                          <Input placeholder="+39 123 456 7890" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editForm.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Indirizzo</FormLabel>
                        <FormControl>
                          <Input placeholder="Via Roma 123, 00100 Roma (RM)" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editForm.control}
                    name="taxId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Partita IVA</FormLabel>
                        <FormControl>
                          <Input placeholder="IT12345678901" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter>
                    <Button type="submit" disabled={updateClient.isPending}>
                      {updateClient.isPending ? "Aggiornamento..." : "Aggiorna Cliente"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>

          {/* Delete Confirmation Dialog */}
          <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Sei sicuro di voler eliminare questo cliente?</AlertDialogTitle>
                <AlertDialogDescription>
                  Questa azione eliminerà definitivamente il cliente {clientToDelete?.name} e tutti i dati correlati. 
                  Questa azione non può essere annullata.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Annulla</AlertDialogCancel>
                <AlertDialogAction 
                  onClick={handleConfirmDelete} 
                  className="bg-red-600 hover:bg-red-700"
                  disabled={deleteClient.isPending}
                >
                  {deleteClient.isPending ? "Eliminazione..." : "Elimina"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          
          {/* Client Trends Modal */}
          <ClientTrendsModal 
            open={isTrendsModalOpen} 
            onOpenChange={setIsTrendsModalOpen} 
            client={clientForTrends} 
          />
        </main>
      </div>
    </div>
  );
}
