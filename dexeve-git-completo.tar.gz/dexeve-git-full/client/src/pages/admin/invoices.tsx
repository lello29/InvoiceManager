import { useState } from "react";
import { Sidebar } from "@/components/dashboard/sidebar";
import { InvoiceTable } from "@/components/dashboard/invoice-table";
import { InvoiceModal } from "@/components/dashboard/invoice-modal";
import { InvoiceFormFixed } from "@/components/forms/invoice-form-fixed";
import { PdfExtractionTester } from "@/components/admin/pdf-extraction-tester";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Select, 
  SelectTrigger, 
  SelectValue, 
  SelectContent, 
  SelectItem 
} from "@/components/ui/select";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Invoice, InvoiceWithClient, Client, InvoiceItem } from "@shared/schema";
import { Download, ExternalLink, FileText, LayoutDashboard, Plus, Search, TestTube } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function AdminInvoices() {
  const [searchTerm, setSearchTerm] = useState("");
  const [clientFilter, setClientFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [yearFilter, setYearFilter] = useState("all");
  
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10); // Stato per numero di righe per pagina

  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [invoiceToEdit, setInvoiceToEdit] = useState<Invoice | null>(null);
  const [viewItems, setViewItems] = useState<InvoiceItem[]>([]);
  const [viewClient, setViewClient] = useState<Client | null>(null);
  
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);

  // Fetch all invoices
  const { data: invoices = [], isLoading: isLoadingInvoices } = useQuery<InvoiceWithClient[]>({
    queryKey: ['/api/admin/invoices'],
  });

  // Fetch all clients
  const { data: clients = [], isLoading: isLoadingClients } = useQuery<Client[]>({
    queryKey: ['/api/admin/clients'],
  });

  // Get available years from invoices
  const availableYears = invoices.length > 0 
    ? Array.from(new Set(invoices.map(invoice => new Date(invoice.issueDate).getFullYear())))
      .sort((a, b) => b - a)
    : [];

  // Filter invoices
  const filteredInvoices = invoices.filter(invoice => {
    // Search filter
    const searchMatch = 
      searchTerm === "" || 
      invoice.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (invoice.client?.name && invoice.client.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (invoice.client?.email && invoice.client.email.toLowerCase().includes(searchTerm.toLowerCase()));
    
    // Client filter
    const clientMatch = 
      clientFilter === "all" || 
      invoice.clientId === parseInt(clientFilter);
    
    // Status filter
    const statusMatch = 
      statusFilter === "all" || 
      invoice.status === statusFilter;
    
    // Year filter
    const invoiceYear = new Date(invoice.issueDate).getFullYear();
    const yearMatch = 
      yearFilter === "all" || 
      invoiceYear === parseInt(yearFilter);
    
    return searchMatch && clientMatch && statusMatch && yearMatch;
  });

  // Pagination
  const paginatedInvoices = filteredInvoices.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const handleViewInvoice = async (invoice: Invoice | InvoiceWithClient) => {
    try {
      const response = await fetch(`/api/admin/invoices/${invoice.id}`);
      
      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }
      
      const data = await response.json();
      
      setSelectedInvoice(invoice);
      setViewItems(data.items || []);
      setViewClient(data.client || null);
      setIsViewModalOpen(true);
    } catch (error) {
      console.error("Error fetching invoice details:", error);
    }
  };

  const handleEditInvoice = async (invoice: Invoice | InvoiceWithClient) => {
    try {
      const response = await fetch(`/api/admin/invoices/${invoice.id}`);
      
      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }
      
      const data = await response.json();
      
      setInvoiceToEdit({
        ...invoice,
        items: data.items || []
      });
      setIsFormModalOpen(true);
    } catch (error) {
      console.error("Error fetching invoice details:", error);
    }
  };

  const handleCreateNewInvoice = () => {
    setInvoiceToEdit(null);
    setIsFormModalOpen(true);
  };

  const handleFormSubmitSuccess = () => {
    setIsFormModalOpen(false);
    setInvoiceToEdit(null);
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };
  
  const handleViewPdf = (invoice: Invoice | InvoiceWithClient) => {
    if (invoice.pdfPath) {
      setPdfUrl(invoice.pdfPath);
      setIsPdfModalOpen(true);
    }
  };
  
  // Funzione per l'aggiornamento rapido delle fatture in-line
  const { toast } = useToast();
  const updateInvoice = useMutation({
    mutationFn: async ({ id, field, value }: { id: number; field: string; value: string | null }) => {
      console.log(`Aggiornamento rapido: id=${id}, field=${field}, value=${value}`);
      return await apiRequest("PATCH", `/api/admin/invoices/${id}`, { field, value });
    },
    onSuccess: () => {
      toast({
        title: "Fattura aggiornata",
        description: "Dato aggiornato con successo",
      });
      // Forza refresh dei dati
      queryClient.invalidateQueries({ queryKey: ['/api/admin/invoices'] });
    },
    onError: (error) => {
      toast({
        title: "Errore",
        description: `Impossibile aggiornare: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const handleUpdateInvoice = (id: number, field: string, value: string | null) => {
    console.log(`handleUpdateInvoice: id=${id}, field=${field}, value=${value}`);
    updateInvoice.mutate({ id, field, value });
  };

  const isLoading = isLoadingInvoices || isLoadingClients;

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar visibile solo su desktop */}
      <div className="hidden md:block">
        <Sidebar />
      </div>
      
      <div className="flex-1 overflow-y-auto md:ml-64">
        <main className="p-4 md:p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-semibold text-gray-900">Gestione Fatture</h1>
            <Button onClick={handleCreateNewInvoice}>
              <Plus className="mr-2 h-4 w-4" />
              Nuova Fattura
            </Button>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <p className="text-gray-500">Caricamento dati...</p>
            </div>
          ) : (
            <Tabs defaultValue="invoices" className="mb-8">
              <TabsList className="mb-6">
                <TabsTrigger value="invoices" className="flex items-center">
                  <LayoutDashboard className="mr-2 h-4 w-4" />
                  Elenco Fatture
                </TabsTrigger>
                <TabsTrigger value="extraction-test" className="flex items-center">
                  <TestTube className="mr-2 h-4 w-4" />
                  Test Estrazione PDF
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="invoices">
                {/* Filters */}
                <div className="mb-6">
                  {/* Search */}
                  <div className="relative mb-4 w-full">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                    <Input 
                      placeholder="Cerca fatture per numero o cliente..." 
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 w-full"
                    />
                  </div>
                  
                  {/* Filtri in griglia */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {/* Filtro cliente */}
                    <Select value={clientFilter} onValueChange={setClientFilter}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Cliente" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Tutti i clienti</SelectItem>
                        {clients.map((client) => (
                          <SelectItem key={client.id} value={String(client.id)}>
                            {client.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    {/* Filtro stato */}
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Stato" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Tutti gli stati</SelectItem>
                        <SelectItem value="paid">Pagata</SelectItem>
                        <SelectItem value="pending">In attesa</SelectItem>
                        <SelectItem value="overdue">Scaduta</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    {/* Filtro anno */}
                    <Select value={yearFilter} onValueChange={setYearFilter}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Anno" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Tutti gli anni</SelectItem>
                        {availableYears.map((year) => (
                          <SelectItem key={year} value={String(year)}>
                            {year}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    {/* Selettore righe per pagina */}
                    <Select 
                      value={String(pageSize)} 
                      onValueChange={(value) => {
                        setPageSize(Number(value));
                        setCurrentPage(1); // Reset alla prima pagina quando cambia il numero di righe
                      }}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Righe per pagina" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="10">10 righe</SelectItem>
                        <SelectItem value="20">20 righe</SelectItem>
                        <SelectItem value="30">30 righe</SelectItem>
                        <SelectItem value="40">40 righe</SelectItem>
                        <SelectItem value="50">50 righe</SelectItem>
                        <SelectItem value="75">75 righe</SelectItem>
                        <SelectItem value="100">100 righe</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Invoice Table or Empty State */}
                {invoices.length === 0 ? (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <FileText className="mr-2 h-5 w-5" />
                        <span>Fatture</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-center py-8 text-gray-500">
                        Non ci sono fatture disponibili. Clicca su "Nuova Fattura" per crearne una.
                      </p>
                    </CardContent>
                  </Card>
                ) : filteredInvoices.length === 0 ? (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <FileText className="mr-2 h-5 w-5" />
                        <span>Fatture</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-center py-8 text-gray-500">
                        Nessuna fattura corrisponde ai filtri selezionati.
                      </p>
                    </CardContent>
                  </Card>
                ) : (
                  <InvoiceTable 
                    invoices={paginatedInvoices}
                    isAdmin={true}
                    onView={handleViewInvoice}
                    onEdit={handleEditInvoice}
                    total={filteredInvoices.length}
                    currentPage={currentPage}
                    onPageChange={handlePageChange}
                    pageSize={pageSize}
                    onUpdateInvoice={handleUpdateInvoice}
                  />
                )}
              </TabsContent>
              
              <TabsContent value="extraction-test">
                <div className="mb-6">
                  <h2 className="text-xl font-medium text-gray-800 mb-4">Strumento di Test Estrazione PDF</h2>
                  <p className="text-gray-600 mb-6">
                    Questo strumento ti permette di confrontare i risultati dell'estrazione dei dati dalle fatture PDF
                    utilizzando sia il metodo con espressioni regolari che con OpenAI.
                  </p>
                  
                  <PdfExtractionTester 
                    invoices={invoices
                      .filter(inv => inv.pdfPath !== null)
                      .map(inv => ({
                        id: inv.id,
                        number: inv.number,
                        pdfPath: inv.pdfPath as string
                      }))}
                  />
                </div>
              </TabsContent>
            </Tabs>
          )}

          {/* Invoice View Modal */}
          {selectedInvoice && (
            <InvoiceModal
              open={isViewModalOpen}
              onOpenChange={setIsViewModalOpen}
              invoice={selectedInvoice}
              items={viewItems}
              client={viewClient}
              onViewPdf={handleViewPdf}
            />
          )}
          
          {/* PDF Viewer Modal */}
          <Dialog open={isPdfModalOpen} onOpenChange={setIsPdfModalOpen}>
            <DialogContent className="max-w-4xl h-[80vh] flex flex-col">
              <DialogHeader>
                <DialogTitle>Visualizzazione documento</DialogTitle>
              </DialogHeader>
              
              <div className="flex-1 overflow-hidden rounded border border-gray-200 bg-white">
                {pdfUrl ? (
                  <iframe 
                    src={pdfUrl} 
                    className="w-full h-full" 
                    title="Visualizzazione documento PDF" 
                  />
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <p className="text-gray-500">Nessun documento disponibile</p>
                  </div>
                )}
              </div>
              
              <DialogFooter className="gap-2">
                <Button 
                  variant="outline" 
                  onClick={() => setIsPdfModalOpen(false)}
                >
                  Chiudi
                </Button>
                
                {pdfUrl && (
                  <a 
                    href={pdfUrl} 
                    download 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex"
                  >
                    <Button>
                      <Download className="mr-2 h-4 w-4" />
                      Scarica PDF
                    </Button>
                  </a>
                )}
                
                {pdfUrl && (
                  <a 
                    href={pdfUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex"
                  >
                    <Button variant="secondary">
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Apri in nuova finestra
                    </Button>
                  </a>
                )}
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Invoice Form Modal */}
          <Dialog open={isFormModalOpen} onOpenChange={setIsFormModalOpen}>
            <DialogContent className="max-w-5xl">
              <DialogHeader>
                <DialogTitle>
                  {invoiceToEdit ? "Modifica Fattura" : "Nuova Fattura"}
                </DialogTitle>
              </DialogHeader>
              <InvoiceFormFixed 
                invoice={invoiceToEdit}
                onSuccess={handleFormSubmitSuccess}
              />
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  );
}
