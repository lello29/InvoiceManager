import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Sidebar } from "@/components/dashboard/sidebar";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Plus, Search, Trash, Edit, UserCheck, UserX } from "lucide-react";

// Tipi delle entità che useremo
type User = {
  id: number;
  username: string;
  email: string;
  name: string;
  role: string;
};

type Client = {
  id: number;
  name: string;
  email: string;
  phone: string | null;
  address: string | null;
  taxId: string | null;
};

type UserClient = {
  id: number;
  userId: number;
  clientId: number;
  isDefault: boolean;
  // Campi aggiuntivi che verranno popolati nel frontend
  userName?: string;
  clientName?: string;
};

// Schema di validazione per i form
const userClientSchema = z.object({
  userId: z.number().positive({ message: "Seleziona un utente" }),
  clientId: z.number().positive({ message: "Seleziona un cliente" }),
  isDefault: z.boolean().default(false),
  accessLevel: z.string().default("view"),
});

type UserClientFormValues = z.infer<typeof userClientSchema>;

export default function AdminUserClients() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedUserClient, setSelectedUserClient] = useState<UserClient | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [userClientToDelete, setUserClientToDelete] = useState<UserClient | null>(null);
  const [selectedUser, setSelectedUser] = useState<number | null>(null);
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const { logoutMutation } = useAuth();

  // Fetch utenti
  const { data: users = [] } = useQuery<User[]>({
    queryKey: ['/api/admin/users'],
  });

  // Fetch clienti
  const { data: clients = [] } = useQuery<Client[]>({
    queryKey: ['/api/admin/clients'],
  });

  // Fetch associazioni utente-cliente basate sull'utente selezionato
  const { data: userClients = [], isLoading: isLoadingUserClients } = useQuery<UserClient[]>({
    queryKey: ['/api/admin/user-clients/user', selectedUser],
    queryFn: async () => {
      if (!selectedUser) return [];
      const res = await apiRequest("GET", `/api/admin/user-clients/user/${selectedUser}`);
      const data = await res.json();
      
      // Arricchisci i dati con i nomi degli utenti e dei clienti
      return data.map((uc: UserClient) => ({
        ...uc,
        userName: users.find(u => u.id === uc.userId)?.name || 'Utente sconosciuto',
        clientName: clients.find(c => c.id === uc.clientId)?.name || 'Cliente sconosciuto'
      }));
    },
    enabled: !!selectedUser, // Esegui la query solo se un utente è selezionato
  });

  // Setup form di creazione
  const createForm = useForm<UserClientFormValues>({
    resolver: zodResolver(userClientSchema),
    defaultValues: {
      userId: 0,
      clientId: 0,
      isDefault: false,
      accessLevel: "view",
    },
  });

  // Setup form di modifica
  const editForm = useForm<UserClientFormValues>({
    resolver: zodResolver(userClientSchema),
    defaultValues: {
      userId: 0,
      clientId: 0,
      isDefault: false,
      accessLevel: "view",
    },
  });

  // Mutation per creare un'associazione
  const createUserClient = useMutation({
    mutationFn: async (data: UserClientFormValues) => {
      const res = await apiRequest("POST", "/api/admin/user-clients", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Associazione creata",
        description: "L'associazione utente-cliente è stata creata con successo.",
      });
      setIsCreateModalOpen(false);
      createForm.reset();
      if (selectedUser) {
        queryClient.invalidateQueries({ queryKey: ['/api/admin/user-clients/user', selectedUser] });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Errore",
        description: `Non è stato possibile creare l'associazione: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Mutation per aggiornare un'associazione
  const updateUserClient = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<UserClientFormValues> }) => {
      const res = await apiRequest("PUT", `/api/admin/user-clients/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Associazione aggiornata",
        description: "L'associazione utente-cliente è stata aggiornata con successo.",
      });
      setIsEditModalOpen(false);
      editForm.reset();
      if (selectedUser) {
        queryClient.invalidateQueries({ queryKey: ['/api/admin/user-clients/user', selectedUser] });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Errore",
        description: `Non è stato possibile aggiornare l'associazione: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Mutation per eliminare un'associazione
  const deleteUserClient = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/user-clients/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Associazione eliminata",
        description: "L'associazione utente-cliente è stata eliminata con successo.",
      });
      setIsDeleteDialogOpen(false);
      if (selectedUser) {
        queryClient.invalidateQueries({ queryKey: ['/api/admin/user-clients/user', selectedUser] });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Errore",
        description: `Non è stato possibile eliminare l'associazione: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Gestione del form di creazione
  const onCreateSubmit = (data: UserClientFormValues) => {
    createUserClient.mutate(data);
  };

  // Gestione del form di modifica
  const onEditSubmit = (data: UserClientFormValues) => {
    if (selectedUserClient) {
      updateUserClient.mutate({ id: selectedUserClient.id, data });
    }
  };

  // Gestione del click sul pulsante di modifica
  const handleEditClick = (userClient: UserClient) => {
    setSelectedUserClient(userClient);
    editForm.reset({
      userId: userClient.userId,
      clientId: userClient.clientId,
      isDefault: userClient.isDefault,
      accessLevel: "view", // Impostiamo un valore predefinito poiché potrebbe non essere presente nel record esistente
    });
    setIsEditModalOpen(true);
  };

  // Gestione del click sul pulsante di eliminazione
  const handleDeleteClick = (userClient: UserClient) => {
    setUserClientToDelete(userClient);
    setIsDeleteDialogOpen(true);
  };

  // Conferma eliminazione
  const handleConfirmDelete = () => {
    if (userClientToDelete) {
      deleteUserClient.mutate(userClientToDelete.id);
    }
  };

  const handleUserChange = (userId: string) => {
    setSelectedUser(parseInt(userId));
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Reset il form quando si apre il modal di creazione
  useEffect(() => {
    if (isCreateModalOpen) {
      createForm.reset();
    }
  }, [isCreateModalOpen, createForm]);

  // Filtra le associazioni in base al termine di ricerca
  const filteredUserClients = userClients.filter(userClient => 
    userClient.userName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    userClient.clientName?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex h-screen overflow-hidden">
      {!isMobile && <Sidebar />}
      
      <div className={`flex-1 overflow-y-auto ${!isMobile ? "md:ml-64" : "ml-0"}`}>
        <main className="p-4 md:p-6 pb-20 md:pb-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-xl md:text-2xl font-semibold text-gray-900">Gestione Utenti-Clienti</h1>
            <div className="flex items-center gap-2">
              {isMobile && (
                <Button variant="outline" size="sm" onClick={handleLogout}>
                  Esci
                </Button>
              )}
              <Button onClick={() => setIsCreateModalOpen(true)} size={isMobile ? "sm" : "default"}>
                <Plus className="mr-2 h-4 w-4" />
                {isMobile ? "Nuova" : "Nuova Associazione"}
              </Button>
            </div>
          </div>

          {/* Selettore utente e barra di ricerca */}
          <div className="mb-6 flex flex-col md:flex-row gap-4">
            <div className="w-full md:w-1/3">
              <label className="block text-sm font-medium text-gray-700 mb-1">Seleziona utente</label>
              <Select onValueChange={handleUserChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Seleziona un utente" />
                </SelectTrigger>
                <SelectContent>
                  {users.map((user) => (
                    <SelectItem key={user.id} value={user.id.toString()}>
                      {user.name} ({user.email})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="w-full md:w-2/3">
              <label className="block text-sm font-medium text-gray-700 mb-1">Cerca nelle associazioni</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                <Input 
                  placeholder="Cerca per nome cliente..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                  disabled={!selectedUser}
                />
              </div>
            </div>
          </div>

          {/* Lista delle associazioni */}
          {!selectedUser ? (
            <div className="text-center py-10">
              <p className="text-gray-500">Seleziona un utente per visualizzare le sue associazioni con i clienti</p>
            </div>
          ) : isLoadingUserClients ? (
            <div className="text-center py-10">
              <p className="text-gray-500">Caricamento associazioni...</p>
            </div>
          ) : filteredUserClients.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-gray-500">Nessuna associazione trovata per questo utente</p>
            </div>
          ) : (
            <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
              {filteredUserClients.map((userClient) => (
                <Card key={userClient.id} className={`overflow-hidden ${userClient.isDefault ? 'border-primary' : ''}`}>
                  <CardHeader className={`bg-gray-50 pb-4 ${userClient.isDefault ? 'border-b-2 border-primary' : ''}`}>
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{userClient.clientName}</CardTitle>
                      <div className="flex space-x-1">
                        <Button variant="ghost" size="icon" onClick={() => handleEditClick(userClient)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteClick(userClient)}>
                          <Trash className="h-4 w-4 text-red-600" />
                        </Button>
                      </div>
                    </div>
                    <CardDescription>
                      {userClient.isDefault ? (
                        <div className="flex items-center text-primary">
                          <UserCheck className="h-4 w-4 mr-1" />
                          Cliente predefinito
                        </div>
                      ) : (
                        <div className="flex items-center text-muted-foreground">
                          <UserX className="h-4 w-4 mr-1" />
                          Cliente secondario
                        </div>
                      )}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <div className="space-y-2">
                      <div>
                        <span className="text-sm font-medium text-gray-500">Utente:</span>
                        <span className="text-sm ml-2">{userClient.userName}</span>
                      </div>
                      <div>
                        <span className="text-sm font-medium text-gray-500">Cliente:</span>
                        <span className="text-sm ml-2">{userClient.clientName}</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="bg-gray-50 py-2 text-xs text-gray-500">
                    ID: {userClient.id}
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}

          {/* Modal per creare una nuova associazione */}
          <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Crea Nuova Associazione</DialogTitle>
                <DialogDescription>
                  Associa un utente a un cliente. Ogni utente può essere associato a più clienti.
                </DialogDescription>
              </DialogHeader>
              <Form {...createForm}>
                <form onSubmit={createForm.handleSubmit(onCreateSubmit)} className="space-y-4">
                  <FormField
                    control={createForm.control}
                    name="userId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Utente</FormLabel>
                        <Select onValueChange={(value) => field.onChange(parseInt(value))} value={field.value.toString()}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleziona un utente" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {users.map((user) => (
                              <SelectItem key={user.id} value={user.id.toString()}>
                                {user.name} ({user.email})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={createForm.control}
                    name="clientId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cliente</FormLabel>
                        <Select onValueChange={(value) => field.onChange(parseInt(value))} value={field.value.toString()}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleziona un cliente" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {clients.map((client) => (
                              <SelectItem key={client.id} value={client.id.toString()}>
                                {client.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={createForm.control}
                    name="isDefault"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Cliente predefinito</FormLabel>
                          <p className="text-sm text-muted-foreground">
                            Se selezionato, questo cliente sarà il cliente predefinito per l'utente selezionato.
                          </p>
                        </div>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={createForm.control}
                    name="accessLevel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Livello di accesso</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleziona un livello di accesso" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="view">Visualizzazione</SelectItem>
                            <SelectItem value="edit">Modifica</SelectItem>
                            <SelectItem value="admin">Amministratore</SelectItem>
                          </SelectContent>
                        </Select>
                        <p className="text-sm text-muted-foreground">
                          Determina quali azioni l'utente può eseguire sui dati del cliente.
                        </p>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter>
                    <Button 
                      type="submit" 
                      disabled={createUserClient.isPending}
                    >
                      {createUserClient.isPending ? "Creazione..." : "Crea Associazione"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>

          {/* Modal per modificare un'associazione */}
          <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Modifica Associazione</DialogTitle>
                <DialogDescription>
                  Modifica l'associazione tra utente e cliente.
                </DialogDescription>
              </DialogHeader>
              <Form {...editForm}>
                <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
                  <FormField
                    control={editForm.control}
                    name="userId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Utente</FormLabel>
                        <Select onValueChange={(value) => field.onChange(parseInt(value))} value={field.value.toString()}>
                          <FormControl>
                            <SelectTrigger disabled>
                              <SelectValue placeholder="Seleziona un utente" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {users.map((user) => (
                              <SelectItem key={user.id} value={user.id.toString()}>
                                {user.name} ({user.email})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editForm.control}
                    name="clientId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cliente</FormLabel>
                        <Select onValueChange={(value) => field.onChange(parseInt(value))} value={field.value.toString()}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleziona un cliente" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {clients.map((client) => (
                              <SelectItem key={client.id} value={client.id.toString()}>
                                {client.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editForm.control}
                    name="isDefault"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Cliente predefinito</FormLabel>
                          <p className="text-sm text-muted-foreground">
                            Se selezionato, questo cliente sarà il cliente predefinito per l'utente selezionato.
                          </p>
                        </div>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editForm.control}
                    name="accessLevel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Livello di accesso</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleziona un livello di accesso" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="view">Visualizzazione</SelectItem>
                            <SelectItem value="edit">Modifica</SelectItem>
                            <SelectItem value="admin">Amministratore</SelectItem>
                          </SelectContent>
                        </Select>
                        <p className="text-sm text-muted-foreground">
                          Determina quali azioni l'utente può eseguire sui dati del cliente.
                        </p>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter>
                    <Button 
                      type="submit" 
                      disabled={updateUserClient.isPending}
                    >
                      {updateUserClient.isPending ? "Aggiornamento..." : "Aggiorna Associazione"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>

          {/* Dialog di conferma eliminazione */}
          <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Sei sicuro di voler eliminare questa associazione?</AlertDialogTitle>
                <AlertDialogDescription>
                  Questa azione rimuoverà l'associazione tra l'utente "{userClientToDelete?.userName}" e il cliente "{userClientToDelete?.clientName}".
                  Questa azione non può essere annullata.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Annulla</AlertDialogCancel>
                <AlertDialogAction 
                  onClick={handleConfirmDelete} 
                  className="bg-red-600 hover:bg-red-700"
                  disabled={deleteUserClient.isPending}
                >
                  {deleteUserClient.isPending ? "Eliminazione..." : "Elimina"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </main>
      </div>
    </div>
  );
}