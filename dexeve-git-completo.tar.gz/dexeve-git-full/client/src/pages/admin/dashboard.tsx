import { useEffect, useState } from "react";
import { Sidebar } from "@/components/dashboard/sidebar";
import { useQuery } from "@tanstack/react-query";
import { Invoice, Client } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  FileText, 
  Users, 
  CreditCard, 
  Clock, 
  AlertCircle, 
  BarChart3, 
  TrendingUp, 
  TrendingDown
} from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import { StatusBadge } from "@/components/ui/status-badge";
import { InvoiceModal } from "@/components/dashboard/invoice-modal";

export default function AdminDashboard() {
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [invoiceItems, setInvoiceItems] = useState<any[]>([]);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Fetch all invoices
  const { data: invoices = [] } = useQuery<any[]>({
    queryKey: ['/api/admin/invoices'],
  });

  // Fetch all clients
  const { data: clients = [] } = useQuery<Client[]>({
    queryKey: ['/api/admin/clients'],
  });

  // Fetch invoice details when an invoice is selected
  useEffect(() => {
    if (selectedInvoice) {
      fetch(`/api/admin/invoices/${selectedInvoice.id}`)
        .then(res => res.json())
        .then(data => {
          setInvoiceItems(data.items || []);
          setSelectedClient(data.client || null);
          setIsModalOpen(true);
        })
        .catch(error => console.error("Error fetching invoice details:", error));
    }
  }, [selectedInvoice]);

  // Calculate summary statistics
  const totalInvoices = invoices.length;
  
  const totalAmount = invoices.reduce((sum, invoice) => 
    sum + Number(invoice.amount), 0
  );
  
  const paidInvoices = invoices.filter(invoice => 
    invoice.status === 'paid'
  );
  
  const paidAmount = paidInvoices.reduce((sum, invoice) => 
    sum + Number(invoice.amount), 0
  );
  
  const pendingInvoices = invoices.filter(invoice => 
    invoice.status === 'pending'
  );
  
  const pendingAmount = pendingInvoices.reduce((sum, invoice) => 
    sum + Number(invoice.amount), 0
  );
  
  const overdueInvoices = invoices.filter(invoice => 
    invoice.status === 'overdue'
  );
  
  const overdueAmount = overdueInvoices.reduce((sum, invoice) => 
    sum + Number(invoice.amount), 0
  );

  // Recent invoices and clients (last 5)
  const recentInvoices = [...invoices]
    .sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime())
    .slice(0, 5);

  const handleViewInvoice = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
  };

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar visibile solo su desktop */}
      <div className="hidden md:block">
        <Sidebar />
      </div>
      
      <div className="flex-1 overflow-y-auto md:ml-64">
        <main className="p-4 md:p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
            <div className="text-sm text-gray-500">
              {new Date().toLocaleDateString('it-IT', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid gap-6 mb-8 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Fatture Totali</p>
                    <p className="text-2xl font-bold">{totalInvoices}</p>
                  </div>
                  <div className="p-3 rounded-full bg-primary/10">
                    <FileText className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <div className="mt-4 text-sm text-gray-500">
                  Importo totale: <span className="font-semibold text-gray-700">{formatCurrency(totalAmount)}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Fatture Pagate</p>
                    <p className="text-2xl font-bold text-green-600">{paidInvoices.length}</p>
                  </div>
                  <div className="p-3 rounded-full bg-green-100">
                    <CreditCard className="h-6 w-6 text-green-600" />
                  </div>
                </div>
                <div className="mt-4 text-sm text-gray-500">
                  Importo: <span className="font-semibold text-green-600">{formatCurrency(paidAmount)}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">In Attesa</p>
                    <p className="text-2xl font-bold text-yellow-600">{pendingInvoices.length}</p>
                  </div>
                  <div className="p-3 rounded-full bg-yellow-100">
                    <Clock className="h-6 w-6 text-yellow-600" />
                  </div>
                </div>
                <div className="mt-4 text-sm text-gray-500">
                  Importo: <span className="font-semibold text-yellow-600">{formatCurrency(pendingAmount)}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Scadute</p>
                    <p className="text-2xl font-bold text-red-600">{overdueInvoices.length}</p>
                  </div>
                  <div className="p-3 rounded-full bg-red-100">
                    <AlertCircle className="h-6 w-6 text-red-600" />
                  </div>
                </div>
                <div className="mt-4 text-sm text-gray-500">
                  Importo: <span className="font-semibold text-red-600">{formatCurrency(overdueAmount)}</span>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 mb-8 grid-cols-1 lg:grid-cols-3">
            {/* Clients Summary */}
            <Card className="lg:col-span-1">
              <CardHeader className="pb-2">
                <CardTitle className="text-xl flex items-center">
                  <Users className="mr-2 h-5 w-5" />
                  Clienti ({clients.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {clients.slice(0, 5).map((client) => (
                    <div key={client.id} className="flex items-center">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold">
                        {client.name.substring(0, 2).toUpperCase()}
                      </div>
                      <div className="ml-4 flex-1">
                        <p className="text-sm font-medium">{client.name}</p>
                        <p className="text-xs text-gray-500">{client.email}</p>
                      </div>
                      <div>
                        <p className="text-sm font-semibold">{client.totalInvoices} fatture</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Invoices */}
            <Card className="lg:col-span-2">
              <CardHeader className="pb-2">
                <CardTitle className="text-xl flex items-center">
                  <FileText className="mr-2 h-5 w-5" />
                  Fatture Recenti
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentInvoices.map((invoice) => (
                    <div 
                      key={invoice.id} 
                      className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer"
                      onClick={() => handleViewInvoice(invoice)}
                    >
                      <div className="mr-4">
                        <p className="text-sm font-mono font-medium">{invoice.number}</p>
                        <p className="text-xs text-gray-500">{new Date(invoice.issueDate).toLocaleDateString('it-IT')}</p>
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{invoice.client.name}</p>
                      </div>
                      <div className="mr-4">
                        <p className="text-sm font-semibold">{formatCurrency(Number(invoice.amount))}</p>
                      </div>
                      <div>
                        <StatusBadge status={invoice.status} />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Invoice Modal */}
          <InvoiceModal
            open={isModalOpen}
            onOpenChange={setIsModalOpen}
            invoice={selectedInvoice}
            items={invoiceItems}
            client={selectedClient}
          />
        </main>
      </div>
    </div>
  );
}
