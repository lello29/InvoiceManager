import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PendingPaymentsReport } from "@/components/ai/pending-payments-report";
import { InvoiceInsights } from "@/components/ai/invoice-insights";
import { PaymentTrends } from "@/components/ai/payment-trends";
import { PaymentPrediction } from "@/components/ai/payment-prediction";
import { Sidebar } from "@/components/dashboard/sidebar";
import { useIsMobile } from "@/hooks/use-mobile";
import { AlertTriangle, BarChart3, FileText, LineChart, TrendingUp } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Client, Invoice } from "@shared/schema";

export default function AdminAnalytics() {
  const isMobile = useIsMobile();
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<number | null>(null);
  const [selectedClientId, setSelectedClientId] = useState<number | null>(null);
  const [selectedTab, setSelectedTab] = useState("overview");

  // Recupera le fatture e i clienti per i selettori
  const { data: invoices, isLoading: invoicesLoading } = useQuery<Invoice[]>({
    queryKey: ["/api/admin/invoices"],
  });

  const { data: clients, isLoading: clientsLoading } = useQuery<Client[]>({
    queryKey: ["/api/admin/clients"],
  });

  // Funzione per navigare a una fattura
  const handleViewInvoice = (invoiceId: number) => {
    setSelectedInvoiceId(invoiceId);
    setSelectedTab("invoice-insights");
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {!isMobile && <Sidebar />}
      <main className={`flex-1 p-4 md:p-6 pb-20 md:pb-6 ${!isMobile ? "md:ml-64" : "ml-0"}`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
          <h1 className="text-2xl font-bold tracking-tight mb-2 md:mb-0">Analisi AI</h1>
          <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-4">
            <Select
              value={selectedInvoiceId?.toString() || ""}
              onValueChange={(value) => setSelectedInvoiceId(parseInt(value))}
              disabled={invoicesLoading}
            >
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="Seleziona fattura" />
              </SelectTrigger>
              <SelectContent>
                {!invoicesLoading && invoices && invoices.map((invoice) => (
                  <SelectItem key={invoice.id} value={invoice.id.toString()}>
                    {invoice.number}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select
              value={selectedClientId?.toString() || ""}
              onValueChange={(value) => setSelectedClientId(parseInt(value))}
              disabled={clientsLoading}
            >
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="Seleziona cliente" />
              </SelectTrigger>
              <SelectContent>
                {!clientsLoading && clients && clients.map((client) => (
                  <SelectItem key={client.id} value={client.id.toString()}>
                    {client.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
          <TabsList className="grid grid-cols-2 md:grid-cols-4 mb-4">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden md:inline">Panoramica</span>
            </TabsTrigger>
            <TabsTrigger 
              value="invoice-insights" 
              disabled={!selectedInvoiceId}
              className="flex items-center gap-2"
            >
              <FileText className="h-4 w-4" />
              <span className="hidden md:inline">Insights Fattura</span>
            </TabsTrigger>
            <TabsTrigger 
              value="payment-trends" 
              disabled={!selectedClientId}
              className="flex items-center gap-2"
            >
              <TrendingUp className="h-4 w-4" />
              <span className="hidden md:inline">Tendenze Pagamenti</span>
            </TabsTrigger>
            <TabsTrigger 
              value="payment-prediction" 
              disabled={!selectedInvoiceId}
              className="flex items-center gap-2"
            >
              <LineChart className="h-4 w-4" />
              <span className="hidden md:inline">Previsione Pagamento</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <Card className="mb-4">
              <CardHeader className="pb-2">
                <CardTitle>Dashboard Analisi AI</CardTitle>
                <CardDescription>
                  Insights e previsioni basati su intelligenza artificiale
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Utilizza gli strumenti di analisi AI per ottenere insights sulle fatture, analizzare tendenze di pagamento 
                  dei clienti e prevedere le probabilità di pagamento future.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="py-3">
                      <CardTitle className="text-base flex items-center gap-2">
                        <FileText className="h-4 w-4 text-primary" />
                        Insights Fattura
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="py-2">
                      <p className="text-xs text-muted-foreground">
                        Analisi dettagliata di una singola fattura con valutazione del rischio e raccomandazioni.
                      </p>
                    </CardContent>
                    <div className="px-4 pb-4">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full"
                        disabled={!selectedInvoiceId}
                        onClick={() => setSelectedTab("invoice-insights")}
                      >
                        {selectedInvoiceId ? "Visualizza Insights" : "Seleziona una fattura"}
                      </Button>
                    </div>
                  </Card>

                  <Card>
                    <CardHeader className="py-3">
                      <CardTitle className="text-base flex items-center gap-2">
                        <TrendingUp className="h-4 w-4 text-primary" />
                        Tendenze Pagamenti
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="py-2">
                      <p className="text-xs text-muted-foreground">
                        Analisi delle abitudini di pagamento di un cliente con profilo di rischio e raccomandazioni.
                      </p>
                    </CardContent>
                    <div className="px-4 pb-4">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full"
                        disabled={!selectedClientId}
                        onClick={() => setSelectedTab("payment-trends")}
                      >
                        {selectedClientId ? "Visualizza Tendenze" : "Seleziona un cliente"}
                      </Button>
                    </div>
                  </Card>

                  <Card>
                    <CardHeader className="py-3">
                      <CardTitle className="text-base flex items-center gap-2">
                        <LineChart className="h-4 w-4 text-primary" />
                        Previsione Pagamento
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="py-2">
                      <p className="text-xs text-muted-foreground">
                        Previsione della probabilità e tempistica di pagamento per una fattura specifica.
                      </p>
                    </CardContent>
                    <div className="px-4 pb-4">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full"
                        disabled={!selectedInvoiceId}
                        onClick={() => setSelectedTab("payment-prediction")}
                      >
                        {selectedInvoiceId ? "Visualizza Previsione" : "Seleziona una fattura"}
                      </Button>
                    </div>
                  </Card>
                </div>
              </CardContent>
            </Card>

            <PendingPaymentsReport onViewInvoice={handleViewInvoice} />
          </TabsContent>

          <TabsContent value="invoice-insights">
            {selectedInvoiceId ? (
              <InvoiceInsights invoiceId={selectedInvoiceId} />
            ) : (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Nessuna fattura selezionata</AlertTitle>
                <AlertDescription>
                  Seleziona una fattura per visualizzare gli insights
                </AlertDescription>
              </Alert>
            )}
          </TabsContent>

          <TabsContent value="payment-trends">
            {selectedClientId ? (
              <PaymentTrends clientId={selectedClientId} />
            ) : (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Nessun cliente selezionato</AlertTitle>
                <AlertDescription>
                  Seleziona un cliente per visualizzare le tendenze di pagamento
                </AlertDescription>
              </Alert>
            )}
          </TabsContent>

          <TabsContent value="payment-prediction">
            {selectedInvoiceId ? (
              <PaymentPrediction invoiceId={selectedInvoiceId} />
            ) : (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Nessuna fattura selezionata</AlertTitle>
                <AlertDescription>
                  Seleziona una fattura per visualizzare la previsione di pagamento
                </AlertDescription>
              </Alert>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}