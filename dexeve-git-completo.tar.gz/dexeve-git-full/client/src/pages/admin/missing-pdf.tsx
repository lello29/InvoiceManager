import React from 'react';
import { Sidebar } from '@/components/dashboard/sidebar';
import { MobileTabBar } from '@/components/dashboard/mobile-tab-bar';
import { MissingPdfsReport } from '@/components/dashboard/missing-pdfs-report';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

export default function MissingPdfPage() {
  const { user, isLoading } = useAuth();

  // Se l'utente non è autenticato, mostra il loader
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Se l'utente non è un amministratore, mostra un messaggio di accesso negato
  if (user?.role !== 'admin') {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <h1 className="text-2xl font-bold mb-4">Accesso Negato</h1>
        <p className="text-gray-600 mb-6">Non hai i permessi per accedere a questa pagina.</p>
        <Button onClick={() => window.location.href = '/'}>Torna alla Home</Button>
      </div>
    );
  }

  return (
    <>
      <div className="flex h-screen overflow-hidden">
        {/* Sidebar visibile solo su desktop */}
        <div className="hidden md:block">
          <Sidebar />
        </div>
        
        {/* Barra di navigazione mobile */}
        <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden">
          <MobileTabBar />
        </div>
        
        <div className="flex-1 overflow-y-auto md:ml-64 pb-20 md:pb-0">
          <main className="p-4 md:p-6">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-semibold text-gray-900">Analisi PDF Mancanti</h1>
              <div className="text-sm text-gray-500">
                {new Date().toLocaleDateString('it-IT', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </div>
            </div>
            
            <div className="mb-6">
              <p className="text-gray-600">
                Questa funzionalità analizza tutte le fatture nel sistema e identifica quelle che non hanno un PDF associato 
                o il cui PDF non è accessibile. Usa l'intelligenza artificiale per analizzare il problema e suggerire azioni.
              </p>
            </div>
            
            <MissingPdfsReport />
          </main>
        </div>
      </div>
    </>
  );
}