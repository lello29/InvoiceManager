import { useEffect, useState } from "react";
import { Sidebar } from "@/components/dashboard/sidebar";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Client, Invoice, InvoiceItem } from "@shared/schema";
import { InvoiceTable } from "@/components/dashboard/invoice-table";
import { ClientCard } from "@/components/dashboard/client-card";
import { InvoiceModal } from "@/components/dashboard/invoice-modal";
import { PdfViewer } from "@/components/pdf-viewer";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Edit, Upload, MessageSquare, User, Building, FileText, LogOut, Download, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useIsMobile } from "@/hooks/use-mobile";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

// Form schemas
const profileSchema = z.object({
  name: z.string().min(1, "Il nome è obbligatorio"),
  email: z.string().email("Email non valida"),
  phone: z.string().optional(),
  address: z.string().optional(),
  taxId: z.string().optional()
});

const messageSchema = z.object({
  subject: z.string().min(1, "L'oggetto è obbligatorio"),
  message: z.string().min(5, "Il messaggio deve contenere almeno 5 caratteri")
});

const paymentProofSchema = z.object({
  invoiceId: z.number(),
  notes: z.string().optional()
});

type ProfileFormValues = z.infer<typeof profileSchema>;
type MessageFormValues = z.infer<typeof messageSchema>;
type PaymentProofFormValues = z.infer<typeof paymentProofSchema>;

export default function ClientDashboard() {
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [invoiceItems, setInvoiceItems] = useState<InvoiceItem[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isMessageModalOpen, setIsMessageModalOpen] = useState(false);
  const [isPaymentProofModalOpen, setIsPaymentProofModalOpen] = useState(false);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);
  const [isCompanyModalOpen, setIsCompanyModalOpen] = useState(false);
  const [selectedInvoiceForPayment, setSelectedInvoiceForPayment] = useState<Invoice | null>(null);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const { user, logoutMutation } = useAuth();
  const [location, setLocation] = useLocation();
  const [pageSize, setPageSize] = useState(10); // Stato per numero di righe per pagina
  
  // Estrai il tab dall'URL se presente, altrimenti usa "fatture"
  const urlParams = new URLSearchParams(typeof window !== 'undefined' ? window.location.search : '');
  const tabFromUrl = urlParams.get('tab');
  const [activeTab, setActiveTab] = useState(tabFromUrl || "fatture");
  
  // Aggiorna l'URL quando cambia il tab
  const handleTabChange = (value: string) => {
    setActiveTab(value);
    setLocation(`/client?tab=${value}`, { replace: true });
  };
  
  // Effetto per aggiornare il tab quando cambia l'URL
  useEffect(() => {
    // Quando cambia l'URL, aggiorna il tab attivo
    const params = new URLSearchParams(location.split('?')[1] || '');
    const tab = params.get('tab');
    if (tab) {
      setActiveTab(tab);
    }
  }, [location]);
  
  // Aggiorna l'URL dalla sidebar
  useEffect(() => {
    if (tabFromUrl) {
      setActiveTab(tabFromUrl);
    }
  }, [tabFromUrl, location]);
  
  // Funzione per visualizzare il PDF
  const handleViewPdf = (invoice: Invoice) => {
    if (invoice.pdfPath) {
      // Assicuriamoci che il percorso inizi con / se non è un URL completo
      let path = invoice.pdfPath;
      if (!path.startsWith('http') && !path.startsWith('/')) {
        path = '/' + path;
      }
      console.log("Tentativo di apertura PDF:", path);
      
      // Usiamo il nuovo endpoint dedicato ai PDF per migliorare la visualizzazione
      if (path.includes('/api/uploads/')) {
        const filename = path.split('/').pop();
        if (filename) {
          path = `/api/view-pdf/${filename}`;
          console.log("Usando endpoint ottimizzato per PDF:", path);
        }
      }
      
      // Salviamo il percorso corretto
      setPdfUrl(path);
      setIsPdfModalOpen(true);
    } else {
      toast({
        title: "PDF non disponibile",
        description: "Il documento PDF per questa fattura non è disponibile",
        variant: "destructive"
      });
    }
  };
  
  // Funzione per scaricare direttamente il PDF senza anteprima
  const handleDownloadPdf = (invoice: Invoice) => {
    if (!invoice.pdfPath) {
      toast({
        title: "PDF non disponibile",
        description: "Il documento PDF per questa fattura non è disponibile",
        variant: "destructive"
      });
      return;
    }
    
    // Assicuriamoci che il percorso inizi con / se non è un URL completo
    let path = invoice.pdfPath;
    if (!path.startsWith('http') && !path.startsWith('/')) {
      path = '/' + path;
    }
    
    // Usiamo l'endpoint dedicato ai PDF se possibile
    if (path.includes('/api/uploads/')) {
      const filename = path.split('/').pop();
      if (filename) {
        path = `/api/view-pdf/${filename}`;
      }
    }
    
    // Creiamo un link temporaneo per il download
    const link = document.createElement('a');
    link.href = path;
    link.download = `Fattura_${invoice.number}.pdf`;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Download avviato",
      description: "Il download del PDF è stato avviato"
    });
  };

  // Fetch client profile
  const { data: client } = useQuery<Client>({
    queryKey: ['/api/client/profile'],
  });

  // Fetch client invoices
  const { data: invoices = [], isLoading } = useQuery<Invoice[]>({
    queryKey: ['/api/client/invoices'],
  });

  // Filter invoices based on search term
  const filteredInvoices = invoices.filter(invoice => 
    searchTerm === "" || 
    invoice.number.toLowerCase().includes(searchTerm.toLowerCase()) || 
    new Date(invoice.issueDate).toLocaleDateString().includes(searchTerm) ||
    new Date(invoice.dueDate).toLocaleDateString().includes(searchTerm) ||
    invoice.status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Pagination
  const paginatedInvoices = filteredInvoices.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const handleViewInvoice = async (invoice: Invoice) => {
    try {
      const response = await fetch(`/api/client/invoices/${invoice.id}`);
      if (!response.ok) {
        throw new Error("Failed to fetch invoice details");
      }
      const data = await response.json();
      
      setSelectedInvoice(invoice);
      setInvoiceItems(data.items || []);
      setIsModalOpen(true);
    } catch (error) {
      console.error("Error fetching invoice details:", error);
    }
  };

  // Form handlers setup
  const profileForm = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: client?.name || "",
      email: client?.email || "",
      phone: client?.phone || "",
      address: client?.address || "",
      taxId: client?.taxId || ""
    }
  });

  const messageForm = useForm<MessageFormValues>({
    resolver: zodResolver(messageSchema),
    defaultValues: {
      subject: "",
      message: ""
    }
  });

  const paymentProofForm = useForm<PaymentProofFormValues>({
    resolver: zodResolver(paymentProofSchema),
    defaultValues: {
      invoiceId: selectedInvoiceForPayment?.id || 0,
      notes: ""
    }
  });

  // Update profile form values when client data is loaded
  useEffect(() => {
    if (client) {
      profileForm.reset({
        name: client.name,
        email: client.email,
        phone: client.phone || "",
        address: client.address || "",
        taxId: client.taxId || ""
      });
    }
  }, [client, profileForm]);

  // Update payment proof form when an invoice is selected
  useEffect(() => {
    if (selectedInvoiceForPayment) {
      paymentProofForm.reset({
        invoiceId: selectedInvoiceForPayment.id,
        notes: ""
      });
    }
  }, [selectedInvoiceForPayment, paymentProofForm]);

  // Define mutations
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormValues) => {
      return await apiRequest("PUT", "/api/client/profile", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/client/profile'] });
      toast({
        title: "Profilo aggiornato",
        description: "Le tue informazioni personali sono state aggiornate con successo",
      });
      setIsProfileModalOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Errore",
        description: `Non è stato possibile aggiornare il profilo: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (data: MessageFormValues) => {
      // Questa è una simulazione - il backend non è ancora implementato
      await new Promise(resolve => setTimeout(resolve, 1000));
      return data;
    },
    onSuccess: () => {
      toast({
        title: "Messaggio inviato",
        description: "Il tuo messaggio è stato inviato con successo all'amministratore",
      });
      messageForm.reset();
      setIsMessageModalOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Errore",
        description: `Non è stato possibile inviare il messaggio: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const uploadPaymentProofMutation = useMutation({
    mutationFn: async (data: PaymentProofFormValues) => {
      // Questa è una simulazione - il backend non è ancora implementato
      await new Promise(resolve => setTimeout(resolve, 1000));
      return data;
    },
    onSuccess: () => {
      toast({
        title: "Prova di pagamento caricata",
        description: "La prova di pagamento è stata caricata con successo",
      });
      paymentProofForm.reset();
      setIsPaymentProofModalOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Errore",
        description: `Non è stato possibile caricare la prova di pagamento: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Form submit handlers
  const onProfileSubmit = (data: ProfileFormValues) => {
    updateProfileMutation.mutate(data);
  };

  const onMessageSubmit = (data: MessageFormValues) => {
    sendMessageMutation.mutate(data);
  };

  const onPaymentProofSubmit = (data: PaymentProofFormValues) => {
    uploadPaymentProofMutation.mutate(data);
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const handleOpenPaymentProofModal = (invoice: Invoice) => {
    setSelectedInvoiceForPayment(invoice);
    setIsPaymentProofModalOpen(true);
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="flex h-screen overflow-hidden">
      {!isMobile && <Sidebar />}
      
      <div className={`flex-1 overflow-y-auto ${!isMobile ? "md:ml-64" : "ml-0"}`}>
        <main className="p-4 md:p-6 pb-20 md:pb-6">
          {/* Header with tabs */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-4">
              <h1 className="text-xl md:text-2xl font-semibold text-gray-900">Area Cliente</h1>
              {isMobile && (
                <Button variant="outline" size="sm" onClick={handleLogout} className="flex items-center gap-1">
                  <LogOut className="h-4 w-4" />
                  Esci
                </Button>
              )}
            </div>
            
            <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
              <TabsList className="grid grid-cols-4 mb-4">
                <TabsTrigger value="fatture" className="flex items-center gap-1">
                  <FileText className="h-4 w-4 md:mr-2" /> 
                  <span className="hidden md:inline">Fatture</span>
                </TabsTrigger>
                <TabsTrigger value="profilo" className="flex items-center gap-1">
                  <User className="h-4 w-4 md:mr-2" /> 
                  <span className="hidden md:inline">Profilo</span>
                </TabsTrigger>
                <TabsTrigger value="azienda" className="flex items-center gap-1">
                  <Building className="h-4 w-4 md:mr-2" /> 
                  <span className="hidden md:inline">Azienda</span>
                </TabsTrigger>
                <TabsTrigger value="messaggi" className="flex items-center gap-1">
                  <MessageSquare className="h-4 w-4 md:mr-2" /> 
                  <span className="hidden md:inline">Messaggi</span>
                </TabsTrigger>
              </TabsList>
              
              {/* Tab contents */}
              <TabsContent value="fatture" className="space-y-4">
                {/* Search and page size*/}
                <div className="flex flex-col md:flex-row md:justify-between gap-3 items-start md:items-center">
                  <div className="relative w-full md:w-auto md:max-w-md flex-grow">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                    <Input 
                      placeholder="Cerca fatture..." 
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  
                  {/* Selettore righe per pagina */}
                  <div className="w-full md:w-auto">
                    <Select 
                      value={String(pageSize)} 
                      onValueChange={(value) => {
                        setPageSize(Number(value));
                        setCurrentPage(1); // Reset alla prima pagina quando cambia il numero di righe
                      }}
                    >
                      <SelectTrigger className="w-full md:w-[180px]">
                        <SelectValue placeholder="Righe per pagina" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="10">10 righe</SelectItem>
                        <SelectItem value="20">20 righe</SelectItem>
                        <SelectItem value="30">30 righe</SelectItem>
                        <SelectItem value="40">40 righe</SelectItem>
                        <SelectItem value="50">50 righe</SelectItem>
                        <SelectItem value="75">75 righe</SelectItem>
                        <SelectItem value="100">100 righe</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Invoices Table */}
                {isLoading ? (
                  <div className="flex justify-center items-center h-64">
                    <p className="text-gray-500">Caricamento fatture...</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <InvoiceTable 
                      invoices={paginatedInvoices}
                      onView={handleViewInvoice}
                      onEdit={(invoice) => handleOpenPaymentProofModal(invoice)}
                      total={filteredInvoices.length}
                      currentPage={currentPage}
                      onPageChange={handlePageChange}
                      pageSize={pageSize}
                    />
                    
                    <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
                      <h3 className="text-sm font-medium mb-2">Visualizzazione documenti</h3>
                      <p className="text-xs text-gray-600 mb-4">
                        Seleziona una fattura dall'elenco e utilizza i pulsanti per visualizzare i dettagli o scaricare il PDF.
                        Puoi anche caricare la prova di pagamento per le fatture in attesa.
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                        {selectedInvoice && (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleViewPdf(selectedInvoice)}
                              className="flex items-center justify-center"
                            >
                              <FileText className="mr-2 h-4 w-4" />
                              Visualizza PDF
                            </Button>
                            
                            {selectedInvoice.pdfPath ? (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleDownloadPdf(selectedInvoice)}
                                className="flex items-center justify-center border-green-500 text-green-700 hover:bg-green-50"
                              >
                                <Download className="mr-2 h-4 w-4" />
                                Scarica PDF
                              </Button>
                            ) : (
                              <Button
                                variant="outline"
                                size="sm"
                                disabled
                                className="flex items-center justify-center border-red-300 text-red-500 opacity-60"
                              >
                                <Download className="mr-2 h-4 w-4" />
                                PDF non disponibile
                              </Button>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="profilo" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <User className="h-5 w-5" />
                      Le Tue Informazioni
                    </CardTitle>
                    <CardDescription>
                      Visualizza e modifica i tuoi dati personali
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {client ? (
                      <dl className="divide-y divide-gray-100">
                        <div className="px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-0">
                          <dt className="text-sm font-medium leading-6 text-gray-900">Nome</dt>
                          <dd className="mt-1 text-sm leading-6 text-gray-700 sm:col-span-2 sm:mt-0">{client.name}</dd>
                        </div>
                        <div className="px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-0">
                          <dt className="text-sm font-medium leading-6 text-gray-900">Email</dt>
                          <dd className="mt-1 text-sm leading-6 text-gray-700 sm:col-span-2 sm:mt-0">{client.email}</dd>
                        </div>
                        <div className="px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-0">
                          <dt className="text-sm font-medium leading-6 text-gray-900">Telefono</dt>
                          <dd className="mt-1 text-sm leading-6 text-gray-700 sm:col-span-2 sm:mt-0">{client.phone || "-"}</dd>
                        </div>
                        <div className="px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-0">
                          <dt className="text-sm font-medium leading-6 text-gray-900">Indirizzo</dt>
                          <dd className="mt-1 text-sm leading-6 text-gray-700 sm:col-span-2 sm:mt-0">{client.address || "-"}</dd>
                        </div>
                        <div className="px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-0">
                          <dt className="text-sm font-medium leading-6 text-gray-900">Partita IVA</dt>
                          <dd className="mt-1 text-sm leading-6 text-gray-700 sm:col-span-2 sm:mt-0">{client.taxId || "-"}</dd>
                        </div>
                      </dl>
                    ) : (
                      <div className="flex justify-center items-center h-32">
                        <p className="text-gray-500">Caricamento informazioni...</p>
                      </div>
                    )}
                  </CardContent>
                  <CardFooter className="flex flex-col sm:flex-row gap-3">
                    <Button 
                      onClick={() => setIsProfileModalOpen(true)}
                      className="w-full md:w-auto"
                    >
                      <Edit className="h-4 w-4 mr-2" />
                      Modifica Informazioni
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => toast({
                        title: "Funzionalità in arrivo",
                        description: "La modifica password sarà disponibile a breve"
                      })}
                      className="w-full md:w-auto"
                    >
                      <User className="h-4 w-4 mr-2" />
                      Modifica Password
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
              
              <TabsContent value="azienda" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Building className="h-5 w-5" />
                      Informazioni Azienda
                    </CardTitle>
                    <CardDescription>
                      Visualizza i dettagli della tua azienda
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-md">
                      <p className="text-yellow-700 text-sm">
                        Questa funzionalità è in fase di sviluppo. Presto potrai visualizzare e modificare i dettagli della tua azienda.
                      </p>
                    </div>
                    
                    {client && (
                      <div className="p-4 border rounded-md bg-gray-50">
                        <h3 className="font-medium text-lg mb-2">{client.name}</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
                          <div>
                            <p className="text-xs font-medium text-gray-500 mb-1">Indirizzo</p>
                            <p className="text-sm text-gray-700">
                              {client.address ? client.address : "Non specificato"}
                            </p>
                          </div>
                          <div>
                            <p className="text-xs font-medium text-gray-500 mb-1">Partita IVA</p>
                            <p className="text-sm text-gray-700">
                              {client.taxId ? client.taxId : "Non specificata"}
                            </p>
                          </div>
                          <div>
                            <p className="text-xs font-medium text-gray-500 mb-1">IBAN</p>
                            <p className="text-sm text-gray-700">
                              {/* Temporaneamente non mostrato, richiede aggiunta al DB */}
                              Non specificato
                            </p>
                          </div>
                          <div>
                            <p className="text-xs font-medium text-gray-500 mb-1">Codice SDI</p>
                            <p className="text-sm text-gray-700">
                              {/* Temporaneamente non mostrato, richiede aggiunta al DB */}
                              Non specificato
                            </p>
                          </div>
                        </div>
                        <div className="mt-4">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => {
                              setIsCompanyModalOpen(true);
                            }}
                            className="w-full"
                          >
                            <Edit className="h-4 w-4 mr-2" />
                            Modifica dati azienda
                          </Button>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="messaggi" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MessageSquare className="h-5 w-5" />
                      Messaggi
                    </CardTitle>
                    <CardDescription>
                      Comunicazioni e avvisi dell'amministratore
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Sezione messaggi amministrativi */}
                    <div className="space-y-3">
                      <div className="bg-amber-50 border border-amber-200 p-4 rounded-md">
                        <h3 className="text-amber-800 font-medium mb-1">Avviso importante</h3>
                        <p className="text-amber-700 text-sm">
                          Si ricorda ai gentili clienti di verificare le fatture in sospeso e procedere con i pagamenti entro le date di scadenza indicate.
                        </p>
                        <div className="flex justify-between items-center mt-2">
                          <span className="text-xs text-amber-600">10/04/2025</span>
                        </div>
                      </div>
                      
                      <div className="bg-blue-50 border border-blue-200 p-4 rounded-md">
                        <h3 className="text-blue-800 font-medium mb-1">Comunicazione di servizio</h3>
                        <p className="text-blue-700 text-sm">
                          I nostri uffici rimarranno chiusi il giorno 25/04/2025 per festività nazionale. Per urgenze contattare il numero di emergenza.
                        </p>
                        <div className="flex justify-between items-center mt-2">
                          <span className="text-xs text-blue-600">08/04/2025</span>
                        </div>
                      </div>
                      
                      <div className="bg-green-50 border border-green-200 p-4 rounded-md">
                        <h3 className="text-green-800 font-medium mb-1">Nuove funzionalità</h3>
                        <p className="text-green-700 text-sm">
                          Abbiamo aggiornato il portale clienti con nuove funzionalità. Ora è possibile visualizzare lo storico fatture e scaricare i documenti direttamente dall'area riservata.
                        </p>
                        <div className="flex justify-between items-center mt-2">
                          <span className="text-xs text-green-600">01/04/2025</span>
                        </div>
                      </div>
                    </div>
                    
                    <Button onClick={() => setIsMessageModalOpen(true)} className="w-full">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Invia Nuovo Messaggio
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Invoice Modal */}
          <InvoiceModal
            open={isModalOpen}
            onOpenChange={setIsModalOpen}
            invoice={selectedInvoice}
            items={invoiceItems}
            client={client || undefined}
            onViewPdf={handleViewPdf}
          />
          
          {/* Profile Edit Modal */}
          <Dialog open={isProfileModalOpen} onOpenChange={setIsProfileModalOpen}>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Modifica Profilo</DialogTitle>
                <DialogDescription>
                  Aggiorna le tue informazioni personali
                </DialogDescription>
              </DialogHeader>
              <Form {...profileForm}>
                <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-4">
                  <FormField
                    control={profileForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nome Completo</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={profileForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={profileForm.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Telefono</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={profileForm.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Indirizzo</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={profileForm.control}
                    name="taxId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Partita IVA</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter>
                    <Button 
                      type="submit" 
                      disabled={updateProfileMutation.isPending}
                      className="w-full"
                    >
                      {updateProfileMutation.isPending ? "Aggiornamento..." : "Salva Modifiche"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
          
          {/* Message Modal */}
          <Dialog open={isMessageModalOpen} onOpenChange={setIsMessageModalOpen}>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Invia Messaggio</DialogTitle>
                <DialogDescription>
                  Invia un messaggio all'amministratore
                </DialogDescription>
              </DialogHeader>
              <Form {...messageForm}>
                <form onSubmit={messageForm.handleSubmit(onMessageSubmit)} className="space-y-4">
                  <FormField
                    control={messageForm.control}
                    name="subject"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Oggetto</FormLabel>
                        <FormControl>
                          <Input placeholder="Inserisci l'oggetto del messaggio" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={messageForm.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Messaggio</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Inserisci il testo del messaggio" 
                            {...field} 
                            className="h-28"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter>
                    <Button 
                      type="submit" 
                      disabled={sendMessageMutation.isPending}
                      className="w-full"
                    >
                      {sendMessageMutation.isPending ? "Invio in corso..." : "Invia Messaggio"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
          
          {/* Payment Proof Modal */}
          <Dialog open={isPaymentProofModalOpen} onOpenChange={setIsPaymentProofModalOpen}>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Carica Prova di Pagamento</DialogTitle>
                <DialogDescription>
                  Carica un documento come prova di pagamento per la fattura
                  {selectedInvoiceForPayment && (
                    <strong> #{selectedInvoiceForPayment.number}</strong>
                  )}
                </DialogDescription>
              </DialogHeader>
              <Form {...paymentProofForm}>
                <form onSubmit={paymentProofForm.handleSubmit(onPaymentProofSubmit)} className="space-y-4">
                  {/* Hidden invoice ID field */}
                  <input 
                    type="hidden" 
                    {...paymentProofForm.register("invoiceId")} 
                  />
                  
                  <div className="grid w-full max-w-sm items-center gap-1.5">
                    <label htmlFor="picture" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                      Documento
                    </label>
                    <div className="flex items-center justify-center border-2 border-dashed border-gray-300 rounded-md p-6 cursor-pointer bg-gray-50 hover:bg-gray-100">
                      <div className="space-y-1 text-center">
                        <Upload className="mx-auto h-12 w-12 text-gray-400" />
                        <div className="flex text-sm text-gray-600">
                          <label
                            htmlFor="file-upload"
                            className="relative cursor-pointer rounded-md font-medium text-primary hover:text-primary/80 focus-within:outline-none"
                          >
                            <span>Carica un file</span>
                            <input id="file-upload" name="file-upload" type="file" className="sr-only" />
                          </label>
                          <p className="pl-1">o trascina e rilascia</p>
                        </div>
                        <p className="text-xs text-gray-500">PNG, JPG, PDF fino a 10MB</p>
                      </div>
                    </div>
                  </div>
                  
                  <FormField
                    control={paymentProofForm.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Note aggiuntive</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Inserisci eventuali note sul pagamento" 
                            {...field} 
                            className="h-20"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter>
                    <Button 
                      type="submit" 
                      disabled={uploadPaymentProofMutation.isPending}
                      className="w-full"
                    >
                      {uploadPaymentProofMutation.isPending ? "Caricamento..." : "Carica Documento"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
          
          {/* Company Edit Modal */}
          <Dialog open={isCompanyModalOpen} onOpenChange={setIsCompanyModalOpen}>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Modifica Dati Azienda</DialogTitle>
                <DialogDescription>
                  Aggiorna le informazioni della tua azienda
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-1 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">Nome Azienda</label>
                    <Input id="name" className="w-full" placeholder="Nome dell'azienda" defaultValue={client?.name || ""} />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="address" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">Indirizzo</label>
                    <Input id="address" className="w-full" placeholder="Indirizzo completo" defaultValue={client?.address || ""} />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="taxId" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">Partita IVA</label>
                    <Input id="taxId" className="w-full" placeholder="Partita IVA" defaultValue={client?.taxId || ""} />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="iban" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">IBAN</label>
                    <Input id="iban" className="w-full" placeholder="IBAN" />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="codiceSDI" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">Codice SDI</label>
                    <Input id="codiceSDI" className="w-full" placeholder="Codice SDI" />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button 
                  variant="outline"
                  onClick={() => setIsCompanyModalOpen(false)}
                  className="mr-2"
                >
                  Annulla
                </Button>
                <Button>
                  Salva Modifiche
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* PDF Viewer Modal */}
          <Dialog open={isPdfModalOpen} onOpenChange={setIsPdfModalOpen}>
            <DialogContent className="max-w-4xl h-[80vh] flex flex-col">
              <DialogHeader>
                <DialogTitle>Visualizzazione documento</DialogTitle>
                <DialogDescription>
                  Puoi visualizzare il documento o scaricarlo facendo clic sul pulsante in basso
                </DialogDescription>
              </DialogHeader>
              
              <div className="flex-1 overflow-hidden rounded border border-gray-200 bg-white">
                {pdfUrl ? (
                  <iframe 
                    src={pdfUrl} 
                    className="w-full h-full min-h-[300px] sm:min-h-[400px]" 
                    title="Visualizzazione documento PDF" 
                  />
                ) : (
                  <div className="flex items-center justify-center h-full min-h-[300px]">
                    <p className="text-gray-500">Nessun documento disponibile</p>
                  </div>
                )}
              </div>
              
              <div className="p-4 bg-gray-50 border-t flex flex-col sm:flex-row gap-2 justify-center sm:justify-end">
                {pdfUrl && (
                  <a 
                    href={pdfUrl} 
                    download={pdfUrl ? pdfUrl.split('/').pop() || "fattura.pdf" : "fattura.pdf"} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-full sm:w-auto"
                  >
                    <Button className="w-full justify-center">
                      <Download className="mr-2 h-4 w-4" />
                      Scarica PDF
                    </Button>
                  </a>
                )}
                
                {pdfUrl && (
                  <a 
                    href={pdfUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-full sm:w-auto"
                  >
                    <Button variant="secondary" className="w-full justify-center">
                      <ExternalLink className="mr-2 h-4 w-4" />
                      Apri in nuova finestra
                    </Button>
                  </a>
                )}
                
                <Button 
                  variant="outline" 
                  onClick={() => setIsPdfModalOpen(false)}
                  className="w-full sm:w-auto justify-center"
                >
                  Chiudi
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  );
}
