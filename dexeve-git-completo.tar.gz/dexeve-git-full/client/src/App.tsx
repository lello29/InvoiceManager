import { useEffect } from "react";
import { Switch, Route, useLocation } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";

// Admin pages
import AdminDashboard from "@/pages/admin/dashboard";
import AdminInvoices from "@/pages/admin/invoices";
import AdminClients from "@/pages/admin/clients";
import AdminUserClients from "@/pages/admin/user-clients";
import AdminSettings from "@/pages/admin/settings";
import AdminAnalytics from "@/pages/admin/analytics";
import AdminMissingPdf from "@/pages/admin/missing-pdf";

// Client pages
import ClientDashboard from "@/pages/client/dashboard";

import { useAuth } from "@/hooks/use-auth";
import { useIsMobile } from "@/hooks/use-mobile";
import { MobileTabBar } from "@/components/dashboard/mobile-tab-bar";
import { DebugPanel } from "@/components/debug-panel";
import { Loader2 } from "lucide-react";

// Layout per pagine autenticate (include barra di navigazione mobile)
function AuthenticatedLayout({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const isMobile = useIsMobile();
  
  // Se non c'è utente, non dovremmo essere qui
  if (!user) return null;
  
  return (
    <div className="flex flex-col min-h-screen">
      {/* Contenuto principale con padding-bottom per la tab bar su mobile */}
      <div className={`flex-1 ${isMobile ? 'pb-20' : ''}`}>
        {children}
      </div>
      
      {/* Tab bar mobile solo su dispositivi piccoli */}
      {isMobile && <MobileTabBar />}
    </div>
  );
}

function App() {
  const { user, isLoading } = useAuth();
  const [location, setLocation] = useLocation();
  
  // Reindirizzamento in base al ruolo
  useEffect(() => {
    if (user && !isLoading) {
      const isPublicRoute = location === '/' || location === '/auth';
      
      if (isPublicRoute) {
        if (user.role === 'admin') {
          setLocation('/admin');
        } else {
          setLocation('/client');
        }
      }
    }
  }, [user, isLoading, location, setLocation]);
  
  // Loader mentre verifichiamo l'autenticazione
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-amber-500" />
      </div>
    );
  }

  return (
    <div className="app-container">
      <Switch>
        {/* Route pubbliche */}
        <Route path="/" component={AuthPage} />
        <Route path="/auth" component={AuthPage} />
        
        {/* Route amministratore */}
        <Route path="/admin">
          {user && user.role === 'admin' ? (
            <AuthenticatedLayout>
              <AdminDashboard />
            </AuthenticatedLayout>
          ) : (
            <AuthPage />
          )}
        </Route>
        
        <Route path="/admin/invoices">
          {user && user.role === 'admin' ? (
            <AuthenticatedLayout>
              <AdminInvoices />
            </AuthenticatedLayout>
          ) : (
            <AuthPage />
          )}
        </Route>
        
        <Route path="/admin/clients">
          {user && user.role === 'admin' ? (
            <AuthenticatedLayout>
              <AdminClients />
            </AuthenticatedLayout>
          ) : (
            <AuthPage />
          )}
        </Route>
        
        <Route path="/admin/user-clients">
          {user && user.role === 'admin' ? (
            <AuthenticatedLayout>
              <AdminUserClients />
            </AuthenticatedLayout>
          ) : (
            <AuthPage />
          )}
        </Route>
        
        <Route path="/admin/settings">
          {user && user.role === 'admin' ? (
            <AuthenticatedLayout>
              <AdminSettings />
            </AuthenticatedLayout>
          ) : (
            <AuthPage />
          )}
        </Route>
        
        <Route path="/admin/analytics">
          {user && user.role === 'admin' ? (
            <AuthenticatedLayout>
              <AdminAnalytics />
            </AuthenticatedLayout>
          ) : (
            <AuthPage />
          )}
        </Route>
        
        <Route path="/admin/missing-pdf">
          {user && user.role === 'admin' ? (
            <AuthenticatedLayout>
              <AdminMissingPdf />
            </AuthenticatedLayout>
          ) : (
            <AuthPage />
          )}
        </Route>
        

        
        {/* Mantengo anche le vecchie rotte per retrocompatibilità */}
        <Route path="/invoices">
          {user && user.role === 'admin' ? (
            <AuthenticatedLayout>
              <AdminInvoices />
            </AuthenticatedLayout>
          ) : (
            <AuthPage />
          )}
        </Route>
        
        <Route path="/clients">
          {user && user.role === 'admin' ? (
            <AuthenticatedLayout>
              <AdminClients />
            </AuthenticatedLayout>
          ) : (
            <AuthPage />
          )}
        </Route>
        
        <Route path="/settings">
          {user && user.role === 'admin' ? (
            <AuthenticatedLayout>
              <AdminSettings />
            </AuthenticatedLayout>
          ) : (
            <AuthPage />
          )}
        </Route>
        
        {/* Route cliente */}
        <Route path="/client">
          {user && user.role === 'client' ? (
            <AuthenticatedLayout>
              <ClientDashboard />
            </AuthenticatedLayout>
          ) : (
            <AuthPage />
          )}
        </Route>
        
        {/* 404 fallback */}
        <Route component={NotFound} />
      </Switch>
      
      <DebugPanel />
      <Toaster />
    </div>
  );
}

export default App;
