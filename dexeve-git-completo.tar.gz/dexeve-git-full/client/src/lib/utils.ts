import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date): string {
  return new Intl.DateTimeFormat('it-IT', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  }).format(date);
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('it-IT', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 2
  }).format(amount);
}

export function getInitials(name: string): string {
  if (!name) return '';
  return name
    .split(' ')
    .map(part => part[0])
    .join('')
    .toUpperCase()
    .substring(0, 2);
}

export function truncateText(text: string, maxLength: number): string {
  if (!text) return '';
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
}

// Converte una data dal formato DD/MM/YYYY a YYYY-MM-DD (per gli input)
export function convertDateForInput(dateStr: string): string {
  if (!dateStr) return '';
  
  // Se è già in formato ISO
  if (dateStr.includes('-') && dateStr.length >= 10) {
    return dateStr.substring(0, 10);
  }
  
  // Se è in formato italiano DD/MM/YYYY
  const parts = dateStr.split('/');
  if (parts.length === 3) {
    return `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
  }
  
  return dateStr;
}

// Converte una data dal formato YYYY-MM-DD a DD/MM/YYYY (per il display)
export function convertDateForDisplay(dateStr: string): string {
  if (!dateStr) return '';
  
  // Se è in formato ISO
  if (dateStr.includes('-') && dateStr.length >= 10) {
    const parts = dateStr.substring(0, 10).split('-');
    if (parts.length === 3) {
      return `${parts[2]}/${parts[1]}/${parts[0]}`;
    }
  }
  
  return dateStr;
}

// Funzione di utilità per ottenere in modo sicuro il valore della data per input HTML
export function getSafeDateValue(dateValue: any): string {
  if (!dateValue) return '';
  
  try {
    // Se è una data
    if (dateValue instanceof Date) {
      return dateValue.toISOString().split('T')[0];
    }
    
    // Se è una stringa
    if (typeof dateValue === 'string') {
      // Se è in formato ISO con ora
      if (dateValue.includes('T')) {
        return dateValue.split('T')[0];
      }
      // Se è già nel formato YYYY-MM-DD
      if (dateValue.match(/^\d{4}-\d{2}-\d{2}$/)) {
        return dateValue;
      }
      // Se è in formato italiano DD/MM/YYYY
      if (dateValue.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
        return convertDateForInput(dateValue);
      }
    }
    
    // In tutti gli altri casi, tentiamo di creare una data
    const date = new Date(dateValue);
    if (!isNaN(date.getTime())) {
      return date.toISOString().split('T')[0];
    }
  } catch (error) {
    console.error("Errore nella conversione della data:", error);
  }
  
  // Fallback: stringa vuota
  return '';
}
