declare module '@/components/ui/heading' {
  export interface HeadingProps {
    title: string;
    description?: string;
    className?: string;
  }
  
  export function Heading(props: HeadingProps): JSX.Element;
}