#!/bin/bash

set -e

# Colori per output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== Avvio dell'applicazione DEXEVE ===${NC}"

# Verifica esistenza directory
echo -e "${YELLOW}Verifica directory uploads e temp...${NC}"
mkdir -p uploads
mkdir -p temp_uploads
mkdir -p attached_assets/pdf_storage
mkdir -p db_export
chmod -R 755 uploads temp_uploads attached_assets db_export
echo -e "${GREEN}Directory verificate e permessi impostati${NC}"

# Attesa per il database
echo -e "${YELLOW}Attendo che il database sia pronto...${NC}"
# Questo è un sostituto per pg_isready che è un comando più specifico
while ! psql "$DATABASE_URL" -c "SELECT 1" > /dev/null 2>&1; do
  echo -e "${YELLOW}Attendo che PostgreSQL sia disponibile...${NC}"
  sleep 2
done
echo -e "${GREEN}Database pronto!${NC}"

echo -e "${GREEN}Avvio dell'applicazione...${NC}"
echo -e "${YELLOW}Ambiente: ${NODE_ENV}${NC}"
echo -e "${YELLOW}Porta: ${PORT}${NC}"
echo -e "${YELLOW}Host: ${HOST:-0.0.0.0}${NC}"

# Avvia l'applicazione
node dist/index.js