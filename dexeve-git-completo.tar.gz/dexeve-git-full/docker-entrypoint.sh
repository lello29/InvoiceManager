#!/bin/bash

set -e

# Colori per output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== Avvio dell'applicazione DEXEVE ===${NC}"

# Verifica esistenza directory
echo -e "${YELLOW}Verifica directory uploads e temp...${NC}"
mkdir -p uploads
mkdir -p temp_uploads
mkdir -p attached_assets/pdf_storage
mkdir -p db_export
chmod -R 755 uploads temp_uploads attached_assets db_export
echo -e "${GREEN}Directory verificate e permessi impostati${NC}"

# Attesa per il database
echo -e "${YELLOW}Attendo che il database sia pronto...${NC}"
until pg_isready -h db -U lello29 -d dexeve; do
  echo -e "${YELLOW}Attendo che PostgreSQL sia disponibile...${NC}"
  sleep 2
done
echo -e "${GREEN}Database pronto!${NC}"

# Verifica se il database è già popolato
echo -e "${YELLOW}Verifico se il database è già inizializzato...${NC}"
TABLES=$(psql -h db -U lello29 -d dexeve -t -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public'" 2>/dev/null || echo "0")

if [ "$TABLES" -eq "0" ] || [ "$TABLES" -lt "5" ]; then
  echo -e "${YELLOW}Database vuoto o incompleto, inizializzazione in corso...${NC}"
  npm run db:push
  echo -e "${GREEN}Database inizializzato con successo!${NC}"
else
  echo -e "${GREEN}Database già inizializzato con $TABLES tabelle.${NC}"
fi

echo -e "${GREEN}Avvio dell'applicazione...${NC}"
echo -e "${YELLOW}Ambiente: ${NODE_ENV}${NC}"
echo -e "${YELLOW}Porta: ${PORT}${NC}"
echo -e "${YELLOW}Host: ${HOST:-0.0.0.0}${NC}"

# Verifica che il file di avvio esista
if [ -f "dist/index.js" ]; then
  echo -e "${GREEN}Utilizzo applicazione compilata in dist/index.js${NC}"
  node dist/index.js
else
  echo -e "${YELLOW}File dist/index.js non trovato, utilizzo modalità sviluppo${NC}"
  npm run dev
fi