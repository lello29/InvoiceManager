import OpenAI from "openai";
import { log } from "./vite";
import { db } from "./db";
import { apiSettings } from "@shared/schema";
import { eq } from "drizzle-orm";
import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';
import { getFromCache, saveToCache } from './utils/pdf-cache';

const execAsync = promisify(exec);

// Ottiene un'istanza di OpenAI con le impostazioni dal database
async function getOpenAIInstance(): Promise<OpenAI> {
  try {
    // Cerca le impostazioni attive nel database
    const [settings] = await db.select().from(apiSettings).where(eq(apiSettings.isActive, true));
    
    if (settings) {
      log(`Utilizzando le impostazioni API '${settings.name}' con modello ${settings.model}`, "openai");
      const options: any = settings.extraOptions || {};
      return new OpenAI({ 
        apiKey: settings.apiKey,
        ...options
      });
    } else {
      // Fallback sull'API key di ambiente
      if (!process.env.OPENAI_API_KEY) {
        log("ATTENZIONE: OPENAI_API_KEY non configurata. Le funzionalità AI non saranno disponibili.", "openai");
      }
      return new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "" });
    }
  } catch (error: any) {
    log(`Errore nel recupero delle impostazioni API: ${error.message}`, "openai");
    // Fallback sull'API key di ambiente
    return new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "" });
  }
}

// Ottiene il modello OpenAI da utilizzare
async function getOpenAIModel(): Promise<string> {
  try {
    const [settings] = await db.select().from(apiSettings).where(eq(apiSettings.isActive, true));
    if (settings) {
      return settings.model;
    }
  } catch (error: any) {
    log(`Errore nel recupero del modello OpenAI: ${error.message}`, "openai");
  }
  
  // Default se nessuna impostazione trovata
  return "gpt-4o";
}

// Funzione per analizzare PDF come immagine usando l'API Vision di OpenAI

// Funzione per convertire un PDF in immagine usando ImageMagick
async function convertPdfToImage(pdfPath: string): Promise<string> {
  try {
    // Prima verifica se esiste già nella cache
    const cachedImage = getFromCache(pdfPath);
    if (cachedImage) {
      log(`Utilizzando immagine dalla cache: ${cachedImage}`, "openai");
      return cachedImage;
    }
    
    log(`Nessuna cache trovata per ${pdfPath}, iniziando conversione`, "openai");
    const imageOutputPath = pdfPath.replace('.pdf', '.png');
    
    // Verifica che il file PDF esista
    if (!fs.existsSync(pdfPath)) {
      throw new Error(`File PDF non trovato: ${pdfPath}`);
    }
    
    // Ottieni informazioni sul file
    const fileStats = fs.statSync(pdfPath);
    log(`Dimensione PDF: ${fileStats.size} bytes`, "openai");
    
    // Usa una densità più alta per i PDF scansionati
    const density = 300; // Aumentiamo la densità per i PDF basati su immagini
    
    try {
      // Prima, tenta di ottenere informazioni sul PDF
      const pdfInfoCmd = `pdfinfo "${pdfPath}" 2>/dev/null || echo "PDF Info not available"`;
      const pdfInfoResult = await execAsync(pdfInfoCmd);
      log(`PDF Info: ${pdfInfoResult}`, "openai");
    } catch (infoError) {
      log(`Non è stato possibile ottenere informazioni sul PDF: ${infoError}`, "openai");
      // Continuiamo comunque, questo è solo per debug
    }
    
    // Prova con la configurazione più robusta per i PDF problematici
    log(`Tentativo di conversione con densità ${density}...`, "openai");
    try {
      // Usiamo una configurazione più robusta per i PDF difficili
      // -density 300: alta risoluzione per catturare più dettagli
      // -colorspace RGB: assicura che i colori siano preservati
      // -background white: sfondo bianco invece di trasparente
      // -alpha remove: rimuove il canale alpha
      // -quality 100: massima qualità per leggibilità migliore
      await execAsync(`convert -density ${density} -colorspace RGB -background white -alpha remove "${pdfPath}[0]" -quality 100 "${imageOutputPath}"`);
      
      // Verifica se l'immagine è stata creata e ha dimensioni ragionevoli
      if (fs.existsSync(imageOutputPath)) {
        const imgStats = fs.statSync(imageOutputPath);
        if (imgStats.size > 1000) { // Immagine non vuota
          log(`PDF convertito con successo in: ${imageOutputPath} (${imgStats.size} bytes)`, "openai");
          // Salva l'immagine nella cache per usi futuri
          const cachedPath = saveToCache(pdfPath, imageOutputPath);
          return imageOutputPath;
        } else {
          log(`L'immagine generata è troppo piccola (${imgStats.size} bytes), provo un altro metodo`, "openai");
          // Continua con altro metodo
        }
      }
    } catch (firstError) {
      log(`Primo metodo di conversione fallito: ${firstError}`, "openai");
      // Continuiamo con il prossimo metodo
    }
    
    // Secondo tentativo con parametri diversi
    log(`Tentativo alternativo di conversione...`, "openai");
    try {
      // Approccio alternativo con parametri diversi
      // -flatten: assicura che tutti i livelli siano uniti
      // -resize 1800x: dimensione ragionevole per l'analisi
      await execAsync(`convert -density 200 -quality 90 -flatten "${pdfPath}[0]" -resize 1800x "${imageOutputPath}"`);
      
      if (fs.existsSync(imageOutputPath)) {
        const imgStats = fs.statSync(imageOutputPath);
        if (imgStats.size > 1000) {
          log(`PDF convertito con successo usando metodo alternativo: ${imageOutputPath}`, "openai");
          const cachedPath = saveToCache(pdfPath, imageOutputPath);
          return imageOutputPath;
        }
      }
    } catch (secondError) {
      log(`Secondo metodo di conversione fallito: ${secondError}`, "openai");
      // Ultimo tentativo
    }
    
    // Ultimo tentativo con Ghostscript (più affidabile per alcuni PDF)
    log(`Tentativo con Ghostscript...`, "openai");
    try {
      // Prima convertiamo in un PDF temporaneo più semplice
      const tempPdf = `${pdfPath}.temp.pdf`;
      await execAsync(`gs -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dPDFSETTINGS=/prepress -dNOPAUSE -dQUIET -dBATCH -sOutputFile="${tempPdf}" "${pdfPath}"`);
      
      // Poi convertiamo in PNG
      await execAsync(`convert -density 300 -quality 100 "${tempPdf}[0]" "${imageOutputPath}"`);
      
      // Pulizia
      if (fs.existsSync(tempPdf)) {
        fs.unlinkSync(tempPdf);
      }
      
      if (fs.existsSync(imageOutputPath)) {
        const imgStats = fs.statSync(imageOutputPath);
        if (imgStats.size > 1000) {
          log(`PDF convertito con successo usando Ghostscript: ${imageOutputPath}`, "openai");
          const cachedPath = saveToCache(pdfPath, imageOutputPath);
          return imageOutputPath;
        }
      }
    } catch (gsError) {
      log(`Metodo Ghostscript fallito: ${gsError}`, "openai");
      // Se siamo arrivati qui, dobbiamo trovare un'alternativa o lanciare un errore
    }
    
    // Se arriviamo qui, tutti i metodi hanno fallito
    throw new Error("Tutti i metodi di conversione del PDF in immagine hanno fallito");
  } catch (error) {
    log(`Errore nella conversione del PDF in immagine: ${error}`, "openai");
    throw error;
  }
}

export async function analyzePdfAsImage(pdfPath: string): Promise<{
  invoiceNumber?: string;
  issueDate?: string;
  total?: string;
  client?: string;
  dueDate?: string;
  paymentMethod?: string;
}> {
  try {
    // Converti path dell'API nella posizione del file sul server
    let localPdfPath = pdfPath;
    
    // Se è un percorso API, convertilo in locale
    if (pdfPath.startsWith('/api/uploads/')) {
      localPdfPath = path.join(process.cwd(), 'uploads', path.basename(pdfPath));
    }
    // Percorso già completo ma potrebbe contenere "uploads"
    else if (pdfPath.includes('/uploads/')) {
      localPdfPath = pdfPath;
    }
    // Potrebbe essere già un percorso locale (dal tester PDF) ma relativo
    else if (!path.isAbsolute(pdfPath)) {
      // Se è un percorso relativo, lo rendiamo assoluto
      localPdfPath = path.join(process.cwd(), pdfPath);
    }
    
    log(`Cercando PDF in: ${localPdfPath}`, "openai");
    
    if (!fs.existsSync(localPdfPath)) {
      log(`File PDF non trovato: ${localPdfPath}`, "openai");
      // Ultimo tentativo con path semplice in cartella uploads
      const fallbackPath = path.join(process.cwd(), 'uploads', path.basename(pdfPath));
      if (fs.existsSync(fallbackPath)) {
        log(`File PDF trovato nel percorso fallback: ${fallbackPath}`, "openai");
        localPdfPath = fallbackPath;
      } else {
        // Non usiamo più il file di test fattura-demo.pdf come fallback
        log(`File PDF non trovato e non utilizziamo più un file di fallback`, "openai");
        return {};
      }
    }
    
    log(`Analisi PDF come immagine: ${localPdfPath}`, "openai");
    
    // Prima convertiamo il PDF in un'immagine PNG
    let imagePath;
    try {
      imagePath = await convertPdfToImage(localPdfPath);
      log(`PDF convertito in immagine: ${imagePath}`, "openai");
    } catch (conversionError) {
      log(`Impossibile convertire il PDF in immagine: ${conversionError}`, "openai");
      return {
        error: "Impossibile convertire il PDF in immagine",
        details: String(conversionError)
      } as any;
    }
    
    // Ottieni un'istanza di OpenAI
    const openai = await getOpenAIInstance();
    const model = await getOpenAIModel();
    
    // Prepara l'immagine in base64
    const imageBase64 = fs.readFileSync(imagePath, { encoding: 'base64' });
    
    // Crea una richiesta per analizzare l'immagine
    const response = await openai.chat.completions.create({
      model,
      messages: [
        {
          role: "system",
          content: `Sei un assistente specializzato nell'estrazione di dati da fatture italiane da immagini.
          
          Presta particolare attenzione a:
          - Elementi con bordi colorati che indicano informazioni specifiche:
            - Bordo NERO: numero fattura
            - Bordo ROSSO: data emissione
            - Bordo BLU: tipo pagamento
            - Bordo GIALLO: totale fattura
          
          Se vedi riquadri colorati, dai loro la massima priorità per estrarre i dati corrispondenti.
          
          Ricorda:
          1. Il numero della fattura è molto importante e deve essere estratto esattamente come appare (es. "5812" o "1160-A", inclusi caratteri speciali)
          2. Il totale documento è l'importo complessivo da pagare, inclusa IVA (solo l'importo numerico, senza simboli di valuta)
          3. Le date devono essere restituite nel formato italiano GG/MM/AAAA (es. 14/01/2025)
          4. Distingui chiaramente tra importi parziali (imponibile, IVA) e l'importo totale finale
          5. Il nome del cliente deve essere estratto per intero, inclusi eventuali suffissi come SRL, SPA, etc.`
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `Analizza questa fattura ed estrai i seguenti dati. Cerca con attenzione elementi con bordi colorati:
              - invoiceNumber: numero completo della fattura, incluso prefissi/suffissi e caratteri speciali (bordo NERO)
              - issueDate: data di emissione in formato italiano GG/MM/AAAA (bordo ROSSO)
              - dueDate: data di scadenza in formato italiano GG/MM/AAAA
              - total: importo totale da pagare, solo cifre con punto come separatore decimale (bordo GIALLO)
              - client: nome completo del cliente, inclusi suffissi come SRL, SPA, etc.
              - paymentMethod: metodo di pagamento (bordo BLU)
              
              Rispondi SOLO con un JSON nel formato:
              {
                "invoiceNumber": "...",
                "issueDate": "DD/MM/YYYY",
                "dueDate": "DD/MM/YYYY",
                "total": "123.45",
                "client": "...",
                "paymentMethod": "..."
              }`
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/png;base64,${imageBase64}`
              }
            }
          ]
        }
      ],
      response_format: { type: "json_object" }
    });
    
    const content = response.choices[0].message.content;
    if (!content) return {};
    
    const result = JSON.parse(content);
    
    // Log più dettagliato dei risultati dell'estrazione
    log(`Estrazione avanzata da immagine completata:
      - Numero fattura: ${result.invoiceNumber || ''}
      - Data emissione: ${result.issueDate || ''}
      - Data scadenza: ${result.dueDate || ''}
      - Totale: ${result.total || ''}
      - Cliente: ${result.client || ''}
      - Metodo pagamento: ${result.paymentMethod || ''}`, "openai");
    
    // Pulizia: elimina il file immagine temporaneo se necessario
    try {
      fs.unlinkSync(imagePath);
      log(`File immagine temporaneo eliminato: ${imagePath}`, "openai");
    } catch (cleanupError) {
      log(`Impossibile eliminare il file immagine temporaneo: ${cleanupError}`, "openai");
      // Non interrompiamo l'esecuzione per errori di pulizia
    }
    
    return result;
  } catch (error: any) {
    log(`Errore durante l'analisi del PDF come immagine: ${error.message}`, "openai");
    return {
      error: "Si è verificato un errore durante l'analisi della fattura come immagine",
      details: (error as any).message
    } as any;
  }
}

// Funzione di analisi del testo estratto da PDF utilizzando OpenAI
export async function analyzePdfText(pdfText: string): Promise<{
  invoiceNumber?: string;
  issueDate?: string;
  total?: string;
  client?: string;
  dueDate?: string;
  paymentMethod?: string;
}> {
  try {
    const openai = await getOpenAIInstance();
    const model = await getOpenAIModel();
    
    // Aggiungi più esempi di strutture di fatture conosciute per migliorare l'accuratezza
    const response = await openai.chat.completions.create({
      model,
      messages: [
        {
          role: "system",
          content: `Sei un assistente specializzato nell'estrazione di dati da fatture italiane.
          
          Le fatture italiane seguono una struttura standard che include:
          - Numero fattura: spesso nel formato "NUMERO/LETTERA" come "1160/A", "2597/A" o "5812"
          - Data di emissione: di solito accanto al numero fattura, preceduta da "del" 
          - Totale documento: il valore finale da pagare, indicato come "Tot. documento" o alla voce "Scadenze"
          - Cliente: indicato dopo "Fattura intestata"
          - Data di scadenza: spesso indicata accanto a "Scadenze:" o "Scadenza:"
          - Metodo di pagamento: indicato accanto a "Pagamento:" (es. "Bonifico vista fattura")
          
          ATTENZIONE SPECIALE: 
          In alcune fatture, ci sono elementi con bordi colorati che indicano informazioni specifiche:
          - Bordo NERO: numero fattura
          - Bordo ROSSO: data emissione
          - Bordo BLU: tipo pagamento
          - Bordo GIALLO: totale fattura
          
          Presta particolare attenzione ai seguenti punti:
          1. Il numero della fattura è molto importante e deve essere estratto esattamente come appare, inclusi tutti i caratteri (es. "5812" o "1160-A")
          2. Il totale documento è l'importo complessivo da pagare, inclusa IVA
          3. Le date devono essere restituite nel formato italiano GG/MM/AAAA (es. 14/01/2025)
          4. Distingui chiaramente tra importi parziali (imponibile, IVA) e l'importo totale finale
          5. Il nome del cliente deve essere estratto per intero, inclusi eventuali suffissi come SRL, SPA, etc.`
        },
        {
          role: "user",
          content: `Estrai con precisione i seguenti dati dal testo della fattura e restituisci un oggetto JSON con questi campi:
          - invoiceNumber: numero completo della fattura inclusi eventuali prefissi/suffissi (es. "1160-A" o "2597-A" o "5812"). Cerca anche in riquadri con bordo NERO.
          - issueDate: data di emissione in formato italiano GG/MM/AAAA (es. 10/02/2025). Cerca anche in riquadri con bordo ROSSO.
          - dueDate: data di scadenza in formato italiano GG/MM/AAAA
          - total: importo totale da pagare (solo cifre con punto come separatore decimale, senza simboli, es. "870.35"). Cerca anche in riquadri con bordo GIALLO.
          - client: nome completo del cliente, inclusi eventuali suffissi come SRL, SPA, etc.
          - paymentMethod: metodo di pagamento indicato. Cerca anche in riquadri con bordo BLU.
          
          Esempi di fatture conosciute:
          1. Fatture in formato "Fattura NR- XXXX/A del DD/MM/YYYY" con totale documento alla fine
          2. Fatture che indicano "Scadenze: DD/MM/YYYY" seguito dall'importo totale
          3. Fatture con riquadri colorati (NERO, ROSSO, BLU, GIALLO) per indicare rispettivamente numero fattura, data emissione, tipo pagamento e totale
          
          Testo della fattura:
          ${pdfText}`
        }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    if (!content) return {};
    
    const result = JSON.parse(content);
    
    // Log più dettagliato dei risultati dell'estrazione
    log(`Estrazione avanzata completata:
      - Numero fattura: ${result.invoiceNumber}
      - Data emissione: ${result.issueDate}
      - Data scadenza: ${result.dueDate}
      - Totale: ${result.total}
      - Cliente: ${result.client}
      - Metodo pagamento: ${result.paymentMethod}`, "openai");
    
    return result;
  } catch (error: any) {
    log(`Errore durante l'analisi del testo del PDF: ${error.message}`, "openai");
    return {
      error: "Si è verificato un errore durante l'analisi della fattura",
      details: (error as any).message
    } as any;
  }
}

// Analisi base delle fatture
export async function analyzeInvoice(invoiceData: any): Promise<any> {
  try {
    const openai = await getOpenAIInstance();
    const model = await getOpenAIModel();
    
    const response = await openai.chat.completions.create({
      model,
      messages: [
        {
          role: "system",
          content: `Sei un assistente finanziario esperto che analizza i dati delle fatture aziendali. 
          Fornisci analisi concise e perspicaci sui dati delle fatture per aiutare le aziende a prendere decisioni 
          migliori sulla gestione delle fatture e delle relazioni con i clienti.`
        },
        {
          role: "user",
          content: `Analizza i seguenti dati della fattura e fornisci informazioni utili sul pagamento, 
          sulla gestione dei clienti e su potenziali problemi o opportunità. Rispondi con un oggetto JSON con i seguenti campi:
          1. "summary": Riepilogo breve delle informazioni chiave
          2. "paymentInsight": Informazioni sul pagamento e sulla puntualità
          3. "clientInsight": Analisi della relazione con il cliente
          4. "riskAssessment": Valutazione del rischio 
          5. "recommendations": Suggerimenti concreti di azioni da intraprendere
          
          Ecco i dati della fattura: ${JSON.stringify(invoiceData)}`
        }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    return content ? JSON.parse(content) : {};
  } catch (error: any) {
    log(`Errore durante l'analisi della fattura: ${error.message}`, "openai");
    return {
      error: "Si è verificato un errore durante l'analisi della fattura",
      details: (error as Error).message
    };
  }
}

// Analisi delle tendenze dei pagamenti per un cliente
export async function analyzePaymentTrends(invoicesData: any[]): Promise<any> {
  try {
    const openai = await getOpenAIInstance();
    const model = await getOpenAIModel();
    
    const response = await openai.chat.completions.create({
      model,
      messages: [
        {
          role: "system",
          content: `Sei un analista finanziario esperto che esamina i modelli di pagamento per identificare tendenze e 
          fornire consigli sulla gestione dei clienti.`
        },
        {
          role: "user",
          content: `Analizza le seguenti fatture per questo cliente e identifica eventuali tendenze nei suoi pagamenti,
          inclusi giorni in media per il pagamento, eventuali ritardi ricorrenti e suggerimenti per migliorare la gestione
          di questo cliente. Rispondi con un oggetto JSON con i seguenti campi:
          1. "trendSummary": Riepilogo delle tendenze principali 
          2. "averagePaymentTime": Tempo medio di pagamento in giorni
          3. "paymentPatterns": Eventuali schemi ricorrenti nel comportamento di pagamento
          4. "riskProfile": Profilo di rischio del cliente
          5. "recommendations": Suggerimenti per migliorare la gestione di questo cliente
          
          Ecco i dati delle fatture: ${JSON.stringify(invoicesData)}`
        }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    return content ? JSON.parse(content) : {};
  } catch (error: any) {
    log(`Errore durante l'analisi delle tendenze di pagamento: ${error.message}`, "openai");
    return {
      error: "Si è verificato un errore durante l'analisi delle tendenze di pagamento",
      details: (error as Error).message
    };
  }
}

// Generazione di report sui pagamenti in sospeso
export async function generatePendingPaymentsReport(pendingInvoices: any[]): Promise<any> {
  try {
    const openai = await getOpenAIInstance();
    const model = await getOpenAIModel();
    
    const response = await openai.chat.completions.create({
      model,
      messages: [
        {
          role: "system",
          content: `Sei un analista finanziario specializzato in gestione dei crediti che aiuta a identificare 
          e gestire pagamenti in sospeso.`
        },
        {
          role: "user",
          content: `Genera un report sui seguenti pagamenti in sospeso, evidenziando quelli ad alto rischio,
          suggerendo priorità di follow-up e consigli per il recupero. Rispondi con un oggetto JSON con i seguenti campi:
          1. "reportSummary": Sintesi generale dei pagamenti in sospeso
          2. "totalValue": Valore totale dei pagamenti in sospeso
          3. "highRiskInvoices": Fatture ad alto rischio di non essere pagate
          4. "followUpPriorities": Ordine suggerito per il follow-up
          5. "recoveryStrategies": Strategie consigliate per il recupero dei pagamenti
          
          Ecco i dati delle fatture in sospeso: ${JSON.stringify(pendingInvoices)}`
        }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    return content ? JSON.parse(content) : {};
  } catch (error: any) {
    log(`Errore durante la generazione del report sui pagamenti in sospeso: ${error.message}`, "openai");
    return {
      error: "Si è verificato un errore durante la generazione del report",
      details: (error as Error).message
    };
  }
}

// Previsione della probabilità di pagamento di un'invvoice
/**
 * Verifica le fatture che non hanno PDF associati o che hanno PDF non accessibili
 * @param invoices Lista di fatture da verificare
 * @returns Analisi delle fatture con PDF mancanti e suggerimenti
 */
export async function detectMissingPdfs(invoices: any[]): Promise<any> {
  try {
    const openai = await getOpenAIInstance();
    const model = await getOpenAIModel();
    
    // Filtra le fatture per trovare quelle senza PDF o con problemi di accesso
    const missingPdfInvoices = invoices.filter(invoice => !invoice.pdfPath || !isPdfAccessible(invoice.pdfPath));
    
    // Prepara le informazioni sulle fatture con problemi
    const missingPdfData = missingPdfInvoices.map(invoice => ({
      id: invoice.id,
      number: invoice.number,
      issueDate: invoice.issueDate,
      clientId: invoice.clientId,
      clientName: invoice.client?.name || "Cliente sconosciuto",
      pdfPath: invoice.pdfPath || "Nessun PDF"
    }));
    
    // Se non ci sono problemi, restituisci un messaggio positivo
    if (missingPdfData.length === 0) {
      return {
        hasMissingPdfs: false,
        missingCount: 0,
        analysis: "Tutte le fatture hanno un PDF correttamente associato.",
        invoicesWithMissingPdf: []
      };
    }
    
    const prompt = `
    Analizza queste fatture che non hanno file PDF associati o hanno problemi di accesso ai PDF.
    
    FATTURE CON PDF MANCANTI:
    ${JSON.stringify(missingPdfData, null, 2)}
    
    Considera le seguenti informazioni:
    - Il numero totale di fatture con PDF mancanti
    - Quali clienti sono maggiormente interessati dal problema
    - Da quanto tempo potrebbero mancare i PDF (basandoti sulle date di emissione)
    - Pattern o tendenze nei problemi
    
    Rispondi con un JSON nel seguente formato:
    {
      "missingPdfsCount": numero di fatture con PDF mancanti,
      "affectedClients": [elenco dei clienti più colpiti],
      "analysis": "breve analisi del problema",
      "recommendedActions": [lista di azioni consigliate],
      "urgencyLevel": "Bassa"|"Media"|"Alta"
    }
    `;
    
    const response = await openai.chat.completions.create({
      model,
      messages: [
        { role: "system", content: "Sei un assistente esperto nella gestione documentale e fatturazione." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
    });
    
    const content = response.choices[0].message.content;
    const aiAnalysis = content ? JSON.parse(content) : null;
    
    return {
      hasMissingPdfs: true,
      missingCount: missingPdfData.length,
      analysis: aiAnalysis ? aiAnalysis.analysis : "Alcune fatture non hanno PDF associati.",
      recommendedActions: aiAnalysis ? aiAnalysis.recommendedActions : ["Verifica le fatture e carica i PDF mancanti"],
      invoicesWithMissingPdf: missingPdfData,
      urgencyLevel: aiAnalysis ? aiAnalysis.urgencyLevel : "Media"
    };
  } catch (error: any) {
    log(`Errore nell'analisi delle fatture con PDF mancanti: ${error.message}`, "openai");
    return {
      hasMissingPdfs: true,
      missingCount: -1, // Indica errore nell'analisi
      analysis: "Non è stato possibile analizzare le fatture con l'AI",
      recommendedActions: ["Verifica manualmente le fatture per identificare PDF mancanti"],
      invoicesWithMissingPdf: [],
      urgencyLevel: "Media"
    };
  }
}

/**
 * Verifica se un PDF è accessibile
 * @param pdfPath Percorso del PDF
 * @returns true se il PDF è accessibile, false altrimenti
 */
function isPdfAccessible(pdfPath: string): boolean {
  const fs = require('fs');
  const path = require('path');
  if (!pdfPath) return false;
  
  try {
    // Estrai il nome del file dal percorso
    const fileName = pdfPath.split('/').pop() || '';
    const uploadDir = path.join(process.cwd(), "uploads");
    
    // Controlla se il file esiste in una delle possibili posizioni
    // 1. Nella cartella uploads
    const directPath = path.join(uploadDir, fileName);
    if (fs.existsSync(directPath)) return true;
    
    // 2. In una sottocartella di uploads
    const clientDirs = fs.readdirSync(uploadDir, { withFileTypes: true })
      .filter((dirent: { isDirectory: () => boolean }) => dirent.isDirectory())
      .map((dirent: { name: string }) => dirent.name);
    
    for (const clientDir of clientDirs) {
      const clientPath = path.join(uploadDir, clientDir, fileName);
      if (fs.existsSync(clientPath)) return true;
    }
    
    // 3. In attached_assets
    const attachedAssetsDir = path.join(process.cwd(), "attached_assets");
    if (fs.existsSync(attachedAssetsDir)) {
      const attachedPath = path.join(attachedAssetsDir, fileName);
      if (fs.existsSync(attachedPath)) return true;
    }
    
    return false;
  } catch (error) {
    console.error("Errore nel controllo di accessibilità del PDF:", error);
    return false;
  }
}

export async function predictPaymentProbability(invoiceData: any, clientHistory: any): Promise<any> {
  try {
    const openai = await getOpenAIInstance();
    const model = await getOpenAIModel();
    
    const response = await openai.chat.completions.create({
      model,
      messages: [
        {
          role: "system",
          content: `Sei un analista del rischio finanziario specializzato nella previsione della probabilità 
          di pagamento delle fatture in base ai dati storici.`
        },
        {
          role: "user",
          content: `Prevedi la probabilità che questa fattura venga pagata in tempo, in ritardo o non venga pagata 
          affatto in base ai dati della fattura e alla storia del cliente. Rispondi con un oggetto JSON con i seguenti campi:
          1. "paymentProbability": Probabilità di pagamento (0-1)
          2. "expectedPaymentDate": Data prevista di pagamento
          3. "riskFactors": Fattori che influenzano il rischio
          4. "confidenceScore": Livello di confidenza nella previsione (0-1)
          5. "recommendedActions": Azioni consigliate per massimizzare la probabilità di pagamento
          
          Ecco i dati della fattura: ${JSON.stringify(invoiceData)}
          Ecco la storia del cliente: ${JSON.stringify(clientHistory)}`
        }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    return content ? JSON.parse(content) : {};
  } catch (error: any) {
    log(`Errore durante la previsione della probabilità di pagamento: ${error.message}`, "openai");
    return {
      error: "Si è verificato un errore durante la previsione della probabilità di pagamento",
      details: (error as Error).message
    };
  }
}