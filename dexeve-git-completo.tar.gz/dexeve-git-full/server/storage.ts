import { 
  users, type User, type InsertUser, 
  clients, type Client, type InsertClient,
  invoices, type Invoice, type InsertInvoice,
  invoiceItems, type InvoiceItem, type InsertInvoiceItem,
  apiSettings, type ApiSettings, type InsertApiSettings,
  userClients, type InsertUserClient,
  type InvoiceWithClient, type InvoiceWithItems, type ClientWithInvoices
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import connectPg from "connect-pg-simple";
import { db } from "./db";
import { eq, and, count } from "drizzle-orm";
import { pool } from "./db";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

// Storage interface
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  updateUserRole(id: number, role: string): Promise<User | undefined>;
  
  // Client operations
  getClient(id: number): Promise<Client | undefined>;
  getClientByName(name: string): Promise<Client | undefined>;
  getClients(): Promise<Client[]>;
  getClientsByUserId(userId: number): Promise<Client[]>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: number, client: Partial<InsertClient>): Promise<Client | undefined>;
  deleteClient(id: number): Promise<boolean>;
  
  // User-Client association operations
  getUserClientAssociations(userId: number): Promise<any[]>;
  getClientUserAssociations(clientId: number): Promise<any[]>;
  createUserClientAssociation(association: InsertUserClient): Promise<any>;
  updateUserClientAssociation(id: number, association: Partial<InsertUserClient>): Promise<any>;
  deleteUserClientAssociation(id: number): Promise<boolean>;
  
  // Invoice operations
  getInvoice(id: number): Promise<Invoice | undefined>;
  getInvoices(): Promise<InvoiceWithClient[]>;
  getInvoicesByClientId(clientId: number): Promise<Invoice[]>;
  getInvoiceWithItems(id: number): Promise<InvoiceWithItems | undefined>;
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  updateInvoice(id: number, invoice: Partial<InsertInvoice>): Promise<Invoice | undefined>;
  deleteInvoice(id: number): Promise<boolean>;
  
  // Invoice items operations
  getInvoiceItems(invoiceId: number): Promise<InvoiceItem[]>;
  createInvoiceItem(item: InsertInvoiceItem): Promise<InvoiceItem>;
  updateInvoiceItem(id: number, item: Partial<InsertInvoiceItem>): Promise<InvoiceItem | undefined>;
  deleteInvoiceItem(id: number): Promise<boolean>;
  
  // API settings operations
  getApiSettings(): Promise<ApiSettings[]>;
  getActiveApiSettings(): Promise<ApiSettings | undefined>;
  createApiSettings(settings: InsertApiSettings): Promise<ApiSettings>;
  updateApiSettings(id: number, settings: Partial<InsertApiSettings>): Promise<ApiSettings | undefined>;
  deleteApiSettings(id: number): Promise<boolean>;
  setActiveApiSettings(id: number): Promise<boolean>;
  
  // Session store
  sessionStore: any;
  
  // Database initialization (optional)
  seedDatabase?(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
  }
  
  // API settings methods
  async getApiSettings(): Promise<ApiSettings[]> {
    return await db.select().from(apiSettings);
  }
  
  async getActiveApiSettings(): Promise<ApiSettings | undefined> {
    const [settings] = await db.select().from(apiSettings).where(eq(apiSettings.isActive, true));
    return settings;
  }
  
  async createApiSettings(insertSettings: InsertApiSettings): Promise<ApiSettings> {
    // Se è attivo, disattiva tutti gli altri prima di inserire
    if (insertSettings.isActive) {
      await db.update(apiSettings).set({ isActive: false });
    }
    
    const [settings] = await db.insert(apiSettings).values(insertSettings).returning();
    return settings;
  }
  
  async updateApiSettings(id: number, settingsUpdate: Partial<InsertApiSettings>): Promise<ApiSettings | undefined> {
    // Se stiamo impostando questo come attivo, disattiva tutti gli altri
    if (settingsUpdate.isActive) {
      await db.update(apiSettings).set({ isActive: false });
    }
    
    const [settings] = await db.update(apiSettings)
      .set(settingsUpdate)
      .where(eq(apiSettings.id, id))
      .returning();
    return settings;
  }
  
  async deleteApiSettings(id: number): Promise<boolean> {
    const result = await db.delete(apiSettings).where(eq(apiSettings.id, id));
    return !!result;
  }
  
  async setActiveApiSettings(id: number): Promise<boolean> {
    // Disattiva tutti
    await db.update(apiSettings).set({ isActive: false });
    
    // Attiva quello specifico
    const [settings] = await db.update(apiSettings)
      .set({ isActive: true })
      .where(eq(apiSettings.id, id))
      .returning();
      
    return !!settings;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }
  
  async updateUserRole(id: number, role: string): Promise<User | undefined> {
    try {
      const [updatedUser] = await db.update(users)
        .set({ role })
        .where(eq(users.id, id))
        .returning();
      return updatedUser;
    } catch (error) {
      console.error("Errore nell'aggiornamento del ruolo utente:", error);
      throw error;
    }
  }

  // User-Client association methods
  async getUserClientAssociations(userId: number): Promise<any[]> {
    const result = await db.select({
      association: userClients,
      clientName: clients.name,
      clientEmail: clients.email
    })
    .from(userClients)
    .leftJoin(clients, eq(userClients.clientId, clients.id))
    .where(eq(userClients.userId, userId));
    
    return result.map(row => ({
      ...row.association,
      client: {
        name: row.clientName || "",
        email: row.clientEmail || ""
      }
    }));
  }
  
  async getClientUserAssociations(clientId: number): Promise<any[]> {
    const result = await db.select({
      association: userClients,
      userName: users.name,
      userEmail: users.email,
      userRole: users.role
    })
    .from(userClients)
    .leftJoin(users, eq(userClients.userId, users.id))
    .where(eq(userClients.clientId, clientId));
    
    return result.map(row => ({
      ...row.association,
      user: {
        name: row.userName || "",
        email: row.userEmail || "",
        role: row.userRole || ""
      }
    }));
  }
  
  async createUserClientAssociation(association: InsertUserClient): Promise<any> {
    console.log("Creating user-client association with data:", JSON.stringify(association, null, 2));
    try {
      const [result] = await db.insert(userClients).values(association).returning();
      console.log("Association created successfully:", JSON.stringify(result, null, 2));
      return result;
    } catch (error) {
      console.error("Error creating user-client association:", error);
      throw error;
    }
  }
  
  async updateUserClientAssociation(id: number, association: Partial<InsertUserClient>): Promise<any> {
    const [result] = await db.update(userClients)
      .set(association)
      .where(eq(userClients.id, id))
      .returning();
    return result;
  }
  
  async deleteUserClientAssociation(id: number): Promise<boolean> {
    const result = await db.delete(userClients).where(eq(userClients.id, id));
    return !!result;
  }

  // Client methods
  async getClient(id: number): Promise<Client | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.id, id));
    return client;
  }
  
  async getClientByName(name: string): Promise<Client | undefined> {
    const [client] = await db.select().from(clients)
      .where(eq(clients.name, name));
    return client;
  }

  async getClients(): Promise<Client[]> {
    return await db.select().from(clients);
  }

  async getClientsByUserId(userId: number): Promise<Client[]> {
    const result = await db.select({
      client: clients
    })
    .from(userClients)
    .innerJoin(clients, eq(userClients.clientId, clients.id))
    .where(eq(userClients.userId, userId));
    
    return result.map(row => row.client);
  }

  async createClient(insertClient: InsertClient): Promise<Client> {
    const [client] = await db.insert(clients).values(insertClient).returning();
    return client;
  }

  async updateClient(id: number, clientUpdate: Partial<InsertClient>): Promise<Client | undefined> {
    const [client] = await db.update(clients)
      .set(clientUpdate)
      .where(eq(clients.id, id))
      .returning();
    return client;
  }

  async deleteClient(id: number): Promise<boolean> {
    const result = await db.delete(clients).where(eq(clients.id, id));
    return !!result;
  }

  // Invoice methods
  async getInvoice(id: number): Promise<Invoice | undefined> {
    try {
      const [invoice] = await db.select().from(invoices).where(eq(invoices.id, id));
      
      if (invoice) {
        // Gestione compatibilità: se non ci sono attachments ma c'è pdfPath, creiamo gli attachments
        if ((!invoice.attachments || invoice.attachments.length === 0) && invoice.pdfPath) {
          const fileName = invoice.pdfPath.split('/').pop() || 'documento.pdf';
          invoice.attachments = [{ path: invoice.pdfPath, name: fileName }];
        }
        
        // Se attachments è null, lo inizializziamo come array vuoto
        if (!invoice.attachments) {
          invoice.attachments = [];
        }
      }
      
      return invoice;
    } catch (error) {
      console.error(`Errore nel recupero della fattura con ID ${id}:`, error);
      return undefined;
    }
  }

  async getInvoices(): Promise<InvoiceWithClient[]> {
    try {
      console.log("Recuperando le fatture dal database...");
      const result = await db.select({
        invoice: invoices,
        clientName: clients.name,
        clientEmail: clients.email
      })
      .from(invoices)
      .leftJoin(clients, eq(invoices.clientId, clients.id));
      
      console.log(`Recuperate ${result.length} fatture dal database`);
      
      // Gestione compatibilità: se non ci sono attachments ma c'è pdfPath, creiamo gli attachments
      return result.map(row => {
        const invoiceData = { ...row.invoice };
        
        // Se non ci sono attachments ma c'è un pdfPath, lo migriamo
        if ((!invoiceData.attachments || invoiceData.attachments.length === 0) && invoiceData.pdfPath) {
          const fileName = invoiceData.pdfPath.split('/').pop() || 'documento.pdf';
          invoiceData.attachments = [{ path: invoiceData.pdfPath, name: fileName }];
        }
        
        // Se attachments è null, lo inizializziamo come array vuoto
        if (!invoiceData.attachments) {
          invoiceData.attachments = [];
        }
        
        return {
          ...invoiceData,
          client: {
            name: row.clientName || "",
            email: row.clientEmail || ""
          }
        };
      });
    } catch (error) {
      console.error("Errore nel recupero delle fatture:", error);
      return [];
    }
  }

  async getInvoicesByClientId(clientId: number): Promise<Invoice[]> {
    return await db.select().from(invoices).where(eq(invoices.clientId, clientId));
  }

  async getInvoiceWithItems(id: number): Promise<InvoiceWithItems | undefined> {
    try {
      const invoice = await this.getInvoice(id);
      if (!invoice) return undefined;
      
      const items = await this.getInvoiceItems(id);
      return {
        ...invoice,
        items
      };
    } catch (error) {
      console.error(`Errore nel recupero della fattura con elementi per l'ID ${id}:`, error);
      return undefined;
    }
  }

  async createInvoice(insertInvoice: InsertInvoice): Promise<Invoice> {
    const [invoice] = await db.insert(invoices).values(insertInvoice).returning();
    return invoice;
  }

  async updateInvoice(id: number, invoiceUpdate: Partial<InsertInvoice>): Promise<Invoice | undefined> {
    const [invoice] = await db.update(invoices)
      .set(invoiceUpdate)
      .where(eq(invoices.id, id))
      .returning();
    return invoice;
  }

  async deleteInvoice(id: number): Promise<boolean> {
    const result = await db.delete(invoices).where(eq(invoices.id, id));
    return !!result;
  }

  // Invoice items methods
  async getInvoiceItems(invoiceId: number): Promise<InvoiceItem[]> {
    return await db.select().from(invoiceItems).where(eq(invoiceItems.invoiceId, invoiceId));
  }

  async createInvoiceItem(insertItem: InsertInvoiceItem): Promise<InvoiceItem> {
    const [item] = await db.insert(invoiceItems).values(insertItem).returning();
    return item;
  }

  async updateInvoiceItem(id: number, itemUpdate: Partial<InsertInvoiceItem>): Promise<InvoiceItem | undefined> {
    const [item] = await db.update(invoiceItems)
      .set(itemUpdate)
      .where(eq(invoiceItems.id, id))
      .returning();
    return item;
  }

  async deleteInvoiceItem(id: number): Promise<boolean> {
    const result = await db.delete(invoiceItems).where(eq(invoiceItems.id, id));
    return !!result;
  }
  
  // Seed database with initial data
  async seedDatabase(): Promise<void> {
    console.log("Iniziando seeding del database...");
    
    // Aggiungi impostazioni API predefinite
    const apiSettingsList = await this.getApiSettings();
    if (apiSettingsList.length === 0) {
      await this.createApiSettings({
        name: "OpenAI GPT-4o",
        apiKey: process.env.OPENAI_API_KEY || "your-api-key-here",
        model: "gpt-4o",
        isActive: true
      });
      console.log("Impostazioni API create");
    } else {
      console.log("Impostazioni API già esistenti");
    }
    
    // Add default admin user
    let admin;
    const adminExists = await this.getUserByUsername("admin");
    if (!adminExists) {
      admin = await this.createUser({
        username: "admin",
        password: "$2b$10$rIxGfPqz5aKrA.c7vJ6FSOl8i9dUSjLKdX.rxmynFr0Bx1H6hBINi", // "password"
        email: "admin@example.com",
        name: "Admin User",
        role: "admin"
      });
      console.log("Utente admin creato");
    } else {
      admin = adminExists;
      console.log("Utente admin già esistente");
    }

    // Add demo client user
    let mario;
    const marioExists = await this.getUserByUsername("mario");
    if (!marioExists) {
      mario = await this.createUser({
        username: "mario",
        password: "$2b$10$rIxGfPqz5aKrA.c7vJ6FSOl8i9dUSjLKdX.rxmynFr0Bx1H6hBINi", // "password"
        email: "mario.rossi@example.com",
        name: "Mario Rossi",
        role: "client"
      });
      console.log("Utente client creato");
    } else {
      mario = marioExists;
      console.log("Utente client già esistente");
    }
    
    // Add demo clients
    const clientsCount = await db.select({ count: count() }).from(clients);
    console.log(`Conteggio client nel database: ${clientsCount[0].count}`);
    
    // Add demo invoices
    const invoicesCount = await db.select({ count: count() }).from(invoices);
    console.log(`Conteggio fatture nel database: ${invoicesCount[0].count}`);
    
    // Se ci sono già fatture nel database, evitiamo di crearne altre
    if (invoicesCount[0].count > 0) {
      console.log("Ci sono già fatture nel database, saltando la creazione di dati demo");
      return;
    }
    
    if (clientsCount[0].count === 0) {
      // Add Mario's client profile
      const marioClient = await this.createClient({
        name: "DEXEVE S.R.L.",
        email: "info@dexeve.com",
        phone: "+39 123 456 7890",
        address: "Via Vigonovese 40, 35127 Padova (PD)",
        taxId: "IT12345678901",
        totalPaid: "4250.00",
        totalPending: "3450.00",
        totalOverdue: "850.00",
        totalInvoices: 20,
        paidInvoices: 15,
        pendingInvoices: 3,
        overdueInvoices: 2
      });
      console.log("Client DEXEVE creato");
      
      // Associate Mario's user with his client profile
      await this.createUserClientAssociation({
        userId: mario.id,
        clientId: marioClient.id,
        isDefault: true,
        accessLevel: "owner"
      });
      console.log("Associazione utente-client creata");
      
      // Add demo invoices for the client
      const invoice1 = await this.createInvoice({
        number: "FTTR-2025/001",
        clientId: marioClient.id,
        issueDate: new Date("2025-01-15"),
        dueDate: new Date("2025-02-15"),
        amount: "1250.00",
        status: "paid",
        paymentType: "bank_transfer",
        paymentDate: new Date("2025-02-10"),
        notes: "Pagamento ricevuto tramite bonifico bancario in data 10/02/2025."
      });

      await this.createInvoiceItem({
        invoiceId: invoice1.id,
        description: "Servizio di consulenza",
        quantity: "10",
        price: "100.00",
        total: "1000.00"
      });

      await this.createInvoiceItem({
        invoiceId: invoice1.id,
        description: "Materiali",
        quantity: "1",
        price: "250.00",
        total: "250.00"
      });

      await this.createInvoice({
        number: "FTTR-2023/004",
        clientId: marioClient.id,
        issueDate: new Date("2023-07-18"),
        dueDate: new Date("2023-08-18"),
        amount: "750.00",
        status: "paid",
        paymentType: "bank_transfer",
        paymentDate: new Date("2023-08-15")
      });
      
      // Add other demo clients for admin
      const techSolutions = await this.createClient({
        name: "Tech Solutions SRL",
        email: "info@techsolutions.it",
        phone: "+39 02 1234567",
        address: "Via Milano 45, 20100 Milano (MI)",
        taxId: "IT87654321098",
        totalPaid: "5700.00",
        totalPending: "3450.00",
        totalOverdue: "0.00",
        totalInvoices: 3,
        paidInvoices: 2,
        pendingInvoices: 1,
        overdueInvoices: 0
      });
      
      // Associate admin with Tech Solutions
      await this.createUserClientAssociation({
        userId: admin.id,
        clientId: techSolutions.id,
        isDefault: true,
        accessLevel: "admin"
      });

      await this.createInvoice({
        number: "FTTR-2023/002",
        clientId: techSolutions.id,
        issueDate: new Date("2023-06-22"),
        dueDate: new Date("2023-07-22"),
        amount: "3450.00",
        status: "pending"
      });

      await this.createInvoice({
        number: "FTTR-2023/005",
        clientId: techSolutions.id,
        issueDate: new Date("2023-07-28"),
        dueDate: new Date("2023-08-28"),
        amount: "2250.00",
        status: "paid",
        paymentType: "bank_transfer",
        paymentDate: new Date("2023-08-20")
      });

      const negozioAbc = await this.createClient({
        name: "Negozio ABC",
        email: "ordini@negozioabc.it",
        phone: "+39 06 9876543",
        address: "Via Napoli 22, 00192 Roma (RM)",
        taxId: "IT45678912345",
        totalPaid: "0.00",
        totalPending: "0.00",
        totalOverdue: "850.00",
        totalInvoices: 1,
        paidInvoices: 0,
        pendingInvoices: 0,
        overdueInvoices: 1
      });
      
      // Associate admin with Negozio ABC
      await this.createUserClientAssociation({
        userId: admin.id,
        clientId: negozioAbc.id,
        isDefault: false,
        accessLevel: "admin"
      });

      await this.createInvoice({
        number: "FTTR-2023/003",
        clientId: negozioAbc.id,
        issueDate: new Date("2023-07-05"),
        dueDate: new Date("2023-08-05"),
        amount: "850.00",
        status: "overdue"
      });
    }
  }
}

// Creazione dello storage database
export const storage = new DatabaseStorage();
