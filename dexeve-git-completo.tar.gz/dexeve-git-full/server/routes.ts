import { Express, Request, Response, static as expressStatic } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import multer from "multer";
import fs from "fs";
import path from "path";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { userClients } from "@shared/schema";
import { insertInvoiceSchema, insertClientSchema, insertInvoiceItemSchema, insertUserClientSchema } from "@shared/schema";
import { extractTextFromPdf, extractInvoiceDataFromText } from "./utils/pdf-extractor";
import { matchOrSuggestClient } from "./utils/client-matcher";
import { analyzePdfAsImage, analyzePdfText } from "./openai";

// Costanti per il progetto
const IN_REPLIT = process.env.REPL_ID !== undefined;
console.log(`Ambiente rilevato: ${IN_REPLIT ? 'Replit' : 'Produzione'}`);
console.log(`Directory di lavoro: ${process.cwd()}`);

// Directory per tutti i tipi di persistenza (garantite in Replit)
const PERSISTENCE_DIR = path.join(process.cwd(), 'attached_assets');
const PDF_STORAGE_DIR = path.join(PERSISTENCE_DIR, 'pdf_storage');
const BACKUP_DIR = path.join(PERSISTENCE_DIR, 'pdf_backup');

// Crea directory se non esistono
function ensureDirectoryExists(dirPath: string) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
    console.log(`Directory creata: ${dirPath}`);
    // Imposta permessi massimi per debug
    try {
      fs.chmodSync(dirPath, 0o777);
    } catch (err) {
      console.error(`Errore nell'impostazione dei permessi per ${dirPath}:`, err);
    }
  }
  return dirPath;
}

// Funzione di utilità per trovare un file PDF in tutte le possibili locazioni
// Ritorna il percorso completo del file se trovato, null altrimenti
function findPdfFile(relativeFilePath: string): string | null {
  console.log(`FINDER - Cercando PDF: ${relativeFilePath}`);
  
  // Primo controllo: se siamo in Replit, verifica prima nelle directory persistenti
  if (IN_REPLIT) {
    const baseFileName = path.basename(relativeFilePath);
    
    // Controlla in PDF_STORAGE_DIR (directory persistente principale)
    const persistentPath = path.join(PDF_STORAGE_DIR, baseFileName);
    if (fs.existsSync(persistentPath) && fs.statSync(persistentPath).isFile()) {
      console.log(`FINDER - Trovato in storage persistente Replit: ${persistentPath}`);
      
      // Crea una copia nella directory standard per future richieste
      try {
        const recoveryPath = path.join(UPLOAD_DIR, `recovered_${Date.now()}_${baseFileName}`);
        fs.copyFileSync(persistentPath, recoveryPath);
        console.log(`FINDER - Creata copia in: ${recoveryPath}`);
        return recoveryPath; // Restituisci il percorso della copia
      } catch (copyError) {
        console.error(`FINDER - Errore nella copia: ${copyError}`);
        return persistentPath; // Restituisci il percorso originale se la copia fallisce
      }
    }
    
    // Controlla nella directory di backup
    const backupPath = path.join(BACKUP_DIR, baseFileName);
    if (fs.existsSync(backupPath) && fs.statSync(backupPath).isFile()) {
      console.log(`FINDER - Trovato in directory backup Replit: ${backupPath}`);
      
      // Crea una copia nella directory standard
      try {
        const recoveryPath = path.join(UPLOAD_DIR, `backup_${Date.now()}_${baseFileName}`);
        fs.copyFileSync(backupPath, recoveryPath);
        console.log(`FINDER - Creata copia in: ${recoveryPath}`);
        return recoveryPath;
      } catch (copyError) {
        console.error(`FINDER - Errore nella copia: ${copyError}`);
        return backupPath;
      }
    }
  }
  
  // Caso 1: path diretto (percorso standard)
  let fullPath = path.join(UPLOAD_DIR, relativeFilePath);
  if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
    console.log(`FINDER - Trovato in percorso diretto: ${fullPath}`);
    return fullPath;
  }
  
  // Caso 2: se contiene slashes, potrebbe essere in formato client_X/file.pdf
  const pathParts = relativeFilePath.split('/');
  if (pathParts.length > 1) {
    const directoryPart = pathParts.slice(0, -1).join('/');
    const fileName = pathParts[pathParts.length - 1];
    
    // Cerca nella struttura esatta delle cartelle
    const nestedPath = path.join(UPLOAD_DIR, directoryPart, fileName);
    if (fs.existsSync(nestedPath) && fs.statSync(nestedPath).isFile()) {
      console.log(`FINDER - Trovato in struttura nidificata: ${nestedPath}`);
      return nestedPath;
    }
  }
  
  // Caso 3: cerca il file in tutte le sottocartelle
  try {
    // Estrai il nome del file finale (ignorando il percorso)
    const fileName = path.basename(relativeFilePath);
    
    // Leggi tutte le sottocartelle
    const clientDirs = fs.readdirSync(UPLOAD_DIR, { withFileTypes: true })
      .filter(dirent => dirent.isDirectory())
      .map(dirent => dirent.name);
    
    // Cerca in ogni sottocartella
    for (const clientDir of clientDirs) {
      const searchPath = path.join(UPLOAD_DIR, clientDir, fileName);
      if (fs.existsSync(searchPath) && fs.statSync(searchPath).isFile()) {
        console.log(`FINDER - Trovato in sottocartella ${clientDir}: ${searchPath}`);
        return searchPath;
      }
    }
    
    // Caso 4: cerca nella cartella root per ultimo
    const rootPath = path.join(UPLOAD_DIR, fileName);
    if (fs.existsSync(rootPath) && fs.statSync(rootPath).isFile()) {
      console.log(`FINDER - Trovato nella cartella root: ${rootPath}`);
      return rootPath;
    }
  } catch (error) {
    console.error("FINDER - Errore nella ricerca del file:", error);
  }
  
  // Caso 5: cerca in attached_assets come ultima risorsa
  try {
    const fileName = path.basename(relativeFilePath);
    const attachedAssetsDir = path.join(process.cwd(), "attached_assets");
    
    if (fs.existsSync(attachedAssetsDir)) {
      const attachedPath = path.join(attachedAssetsDir, fileName);
      if (fs.existsSync(attachedPath) && fs.statSync(attachedPath).isFile()) {
        console.log(`FINDER - Trovato in attached_assets: ${attachedPath}`);
        
        // Copia il file nella cartella uploads
        const targetPath = path.join(UPLOAD_DIR, fileName);
        fs.copyFileSync(attachedPath, targetPath);
        console.log(`FINDER - File copiato in uploads: ${targetPath}`);
        
        return targetPath;
      }
    }
  } catch (error) {
    console.error("FINDER - Errore nella ricerca in attached_assets:", error);
  }
  
  console.log(`FINDER - File non trovato: ${relativeFilePath}`);
  return null;
}

// Cartelle per i file
const UPLOAD_DIR = path.join(process.cwd(), "uploads"); // Cartella definitiva
const TEMP_DIR = path.join(process.cwd(), "temp_uploads"); // Cartella temporanea

// Assicurati che entrambe le directory esistano
ensureDirectoryExists(UPLOAD_DIR);
ensureDirectoryExists(TEMP_DIR);

// Funzione per ottenere il nome della cartella cliente in base all'ID
async function getClientFolderName(clientId: number): Promise<string> {
  try {
    const client = await storage.getClient(clientId);
    if (!client) {
      console.error(`Cliente con ID ${clientId} non trovato`);
      return `client_${clientId}`;
    }
    
    // Sanitizza il nome cliente per usarlo come nome cartella
    let folderName = client.name.trim()
      .replace(/[\/\\:*?"<>|]/g, '_')  // Rimuovi caratteri non validi per i nomi file
      .replace(/\s+/g, '_');           // Sostituisci spazi con underscore
    
    // Rimuovi caratteri accentati per maggiore compatibilità
    folderName = folderName.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    
    // Aggiungi il prefisso con l'ID cliente per garantire l'unicità
    return `${folderName}_${clientId}`;
    
  } catch (error) {
    console.error(`Errore nel recupero del nome cliente: ${error}`);
    return `client_${clientId}`;
  }
}

// Funzione per spostare un file dalla cartella temporanea a quella definitiva
async function moveFileFromTempToUploads(tempFilePath: string, keepOriginal: boolean = false, clientId?: number): Promise<string> {
  console.log("Moving file from temp to uploads:", tempFilePath);
  
  try {
    // Verifica se il file esiste
    if (!fs.existsSync(tempFilePath)) {
      console.error(`File non trovato: ${tempFilePath}`);
      throw new Error(`File non trovato: ${tempFilePath}`);
    }
    
    // Verifica che il file non sia vuoto
    const tempFileStats = await fs.promises.stat(tempFilePath);
    if (tempFileStats.size === 0) {
      console.error(`File temporaneo con dimensione zero: ${tempFilePath}`);
      throw new Error(`File temporaneo vuoto: ${tempFilePath}`);
    }
    
    // Ottieni il nome del file originale
    const originalFileName = path.basename(tempFilePath);
    
    // NUOVA LOGICA: Crea un nome file stabilmente identificabile
    // 1. Estrai il nome base senza estensione
    const fileExt = path.extname(originalFileName);
    const fileNameWithoutExt = path.basename(originalFileName, fileExt);
    
    // 2. Sanitizza il nome file (rimuovi spazi e caratteri speciali)
    let sanitizedFileName = fileNameWithoutExt
      .replace(/\s+/g, '_')          // Sostituisci spazi con underscore
      .replace(/[^a-zA-Z0-9_-]/g, '') // Rimuovi caratteri speciali
      .toLowerCase();                 // Converti in minuscolo per consistenza
    
    // Assicurati che la cartella di uploads principale esista
    ensureDirectoryExists(UPLOAD_DIR);
    
    // Determina la cartella di destinazione in base al cliente
    let targetDir = UPLOAD_DIR;
    let clientFolderName = "";
    let clientPrefix = "";
    
    try {
      // Se c'è un ID cliente, ottieni informazioni sul cliente
      if (clientId) {
        // Ottieni il nome della cartella cliente basato sul nome azienda
        clientFolderName = await getClientFolderName(clientId);
        
        // Estrai il prefisso del cliente dal nome (primi 3 caratteri)
        const client = await storage.getClient(clientId);
        if (client && client.name) {
          clientPrefix = client.name.substring(0, 3).toUpperCase();
        } else {
          clientPrefix = `CL${clientId}`;
        }
        
        // Crea una sottocartella per il cliente
        targetDir = path.join(UPLOAD_DIR, clientFolderName);
        ensureDirectoryExists(targetDir);
        console.log(`Cartella cliente creata/verificata: ${targetDir}`);
      }
    } catch (clientError) {
      console.error(`Errore nel recupero/creazione della cartella cliente per ID ${clientId}:`, clientError);
      clientPrefix = "UNK";
      targetDir = UPLOAD_DIR;
      clientFolderName = "";
    }
    
    // 3. Crea un nome file con ID stabile
    // Formato: CLIENT_PREFIX_INVOICE-NUMBER_YYYYMMDD.pdf
    // Prova a estrarre un numero di fattura dal nome file (pattern comune: numero seguito da -A o /A)
    let invoiceNumber = "";
    const invoiceMatch = originalFileName.match(/([0-9]{1,4})[\s\-\/]?[A-Za-z]/);
    if (invoiceMatch && invoiceMatch[1]) {
      invoiceNumber = invoiceMatch[1];
    } else {
      // Se non troviamo un numero di fattura, usa un timestamp troncato
      invoiceNumber = Date.now().toString().slice(-5);
    }
    
    // Estrai data dal nome file se disponibile (formato comune: DD-MM-YYYY o DD/MM/YYYY)
    let dateStr = "";
    const currentDate = new Date();
    const dateMatch = originalFileName.match(/(\d{1,2})[\s\-\/](\d{1,2})[\s\-\/](\d{2,4})/);
    if (dateMatch) {
      // Normalizza la data nel formato YYYYMMDD
      const day = dateMatch[1].padStart(2, '0');
      const month = dateMatch[2].padStart(2, '0');
      let year = dateMatch[3];
      if (year.length === 2) year = currentDate.getFullYear().toString().slice(0, 2) + year;
      dateStr = `${year}${month}${day}`;
    } else {
      // Se non troviamo una data, usa la data corrente
      dateStr = `${currentDate.getFullYear()}${(currentDate.getMonth() + 1).toString().padStart(2, '0')}${currentDate.getDate().toString().padStart(2, '0')}`;
    }
    
    // Crea il nome file finale con identificativo stabile
    const stableFileName = `${clientPrefix}_INV${invoiceNumber}_${dateStr}.pdf`;
    console.log("Nome file stabile generato:", stableFileName);
    
    // Percorso completo di destinazione
    const targetPath = path.join(targetDir, stableFileName);
    
    // Definizione del percorso relativo per il database
    let relativePath = "";
    if (clientFolderName) {
      relativePath = `/api/uploads/${clientFolderName}/${stableFileName}`;
    } else {
      relativePath = `/api/uploads/${stableFileName}`;
    }
    
    console.log("IMPORTANTE - Percorso completo:", targetPath);
    console.log("IMPORTANTE - Percorso relativo per il database:", relativePath);
    
    // Implementa un meccanismo di retry per la copia del file
    let copySuccess = false;
    let attempts = 0;
    const maxAttempts = 3;
    
    while (!copySuccess && attempts < maxAttempts) {
      attempts++;
      
      try {
        // Prima assicurati che la directory esista
        ensureDirectoryExists(path.dirname(targetPath));
        
        // Utilizzo di fs.copyFileSync per operazioni sincrone più affidabili in questo contesto
        fs.copyFileSync(tempFilePath, targetPath);
        
        // Verifica immediatamente che il file sia stato copiato con successo
        if (fs.existsSync(targetPath)) {
          const fileStats = fs.statSync(targetPath);
          
          if (fileStats.size > 0) {
            copySuccess = true;
            console.log(`File copiato con successo al tentativo ${attempts}: ${targetPath} (${fileStats.size} bytes)`);
            
            // Imposta i permessi del file a leggibili e scrivibili per tutti
            try {
              fs.chmodSync(targetPath, 0o666);
              console.log(`Permessi impostati a 666 per ${targetPath}`);
            } catch (chmodError) {
              console.error(`Non è stato possibile modificare i permessi per ${targetPath}:`, chmodError);
            }
          } else {
            console.error(`Il file è stato copiato ma ha dimensione 0 bytes: ${targetPath}`);
            throw new Error("File copiato ma con dimensione zero");
          }
        } else {
          console.error(`File non trovato dopo la copia: ${targetPath}`);
          throw new Error("File non trovato dopo la copia");
        }
      } catch (copyError) {
        console.error(`Errore nella copia al tentativo ${attempts}:`, copyError);
        
        if (attempts >= maxAttempts) {
          throw new Error(`Errore persistente nella copia del file dopo ${maxAttempts} tentativi`);
        }
        
        // Piccola pausa prima del prossimo tentativo
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }
    
    // MODIFICA: Manteniamo sempre il file temporaneo come backup
    // Per risolvere il problema dei PDF che non sono più disponibili, manteniamo una copia
    // NOTA: Non eliminiamo più il file temporaneo in nessun caso
    // Verifica se il file è stato copiato correttamente
    if (fs.existsSync(targetPath) && fs.statSync(targetPath).size > 0) {
      console.log(`File copiato con successo da ${tempFilePath} a ${targetPath}`);
      // Creiamo una copia di backup in attached_assets
      const backupDir = path.join(process.cwd(), "attached_assets");
      if (fs.existsSync(backupDir)) {
        const backupPath = path.join(backupDir, path.basename(tempFilePath));
        try {
          fs.copyFileSync(tempFilePath, backupPath);
          console.log(`Backup creato in: ${backupPath}`);
        } catch (backupError) {
          console.error("Errore nella creazione del backup:", backupError);
        }
      }
    } else {
      console.log(`File temporaneo mantenuto: ${tempFilePath}`);
    }
    
    // Verifica finale che il file esista nella destinazione
    try {
      if (fs.existsSync(targetPath)) {
        const fileStats = fs.statSync(targetPath);
        console.log(`Verifica finale: file esistente in ${targetPath}, dimensione: ${fileStats.size} bytes`);
        
        // Copia di backup nella cartella principale per massima sicurezza
        try {
          const backupPath = path.join(UPLOAD_DIR, stableFileName);
          if (targetPath !== backupPath) {
            fs.copyFileSync(targetPath, backupPath);
            console.log(`Backup creato in ${backupPath}`);
          }
        } catch (backupError) {
          console.warn("Non è stato possibile creare il backup nella cartella principale:", backupError);
        }
      } else {
        throw new Error(`File non trovato nel percorso di destinazione: ${targetPath}`);
      }
    } catch (statError) {
      console.error("Errore nella verifica finale dell'esistenza del file:", statError);
      // Se non esiste, lancia un errore
      throw new Error(`Verifica finale fallita: il file non esiste nella destinazione ${targetPath}`);
    }
    
    // REPLIT PERSISTENT STORAGE
    // In Replit, facciamo una copia extra nella cartella attached_assets che mantiene i file anche dopo il riavvio
    if (IN_REPLIT) {
      try {
        // Crea le directory se non esistono
        ensureDirectoryExists(PDF_STORAGE_DIR);
        ensureDirectoryExists(BACKUP_DIR);
        
        // Crea un nome file basato sul percorso relativo ma senza la struttura delle cartelle
        const pdfFileName = path.basename(relativePath);
        const persistentPath = path.join(PDF_STORAGE_DIR, pdfFileName);
        const backupPath = path.join(BACKUP_DIR, pdfFileName);
        
        // Copia il file in PDF_STORAGE_DIR
        fs.copyFileSync(targetPath, persistentPath);
        console.log(`File copiato nella persistenza Replit: ${persistentPath}`);
        
        // Copia di backup
        fs.copyFileSync(targetPath, backupPath);
        console.log(`Backup creato in: ${backupPath}`);
        
        // Memorizza la mappatura relativePath -> persistentPath per future reference
        // Nota: questa mappatura sarà persa al riavvio, ma è utile per la sessione corrente
        console.log(`Mappatura: ${relativePath} -> ${persistentPath}`);
      } catch (persistError) {
        console.error("Errore nella creazione della copia persistente in Replit:", persistError);
      }
    }
    
    // Restituisci il percorso relativo per l'API
    return relativePath;
  } catch (error) {
    console.error("Errore durante lo spostamento del file:", error);
    
    // PRIMO FALLBACK: Verifica se il file esiste nella persistenza Replit
    if (IN_REPLIT) {
      try {
        // Crea un nome file basato sul file originale se possibile
        let originalFileName = path.basename(tempFilePath);
        
        // Cerca il file in PDF_STORAGE_DIR
        const pdfStorageFiles = fs.readdirSync(PDF_STORAGE_DIR);
        console.log(`Cercando una corrispondenza per ${originalFileName} tra ${pdfStorageFiles.length} file in PDF_STORAGE_DIR`);
        
        // Prima cerca una corrispondenza esatta
        let persistentFile = pdfStorageFiles.find(f => f === originalFileName);
        
        // Se non troviamo una corrispondenza esatta, cerca una corrispondenza parziale
        if (!persistentFile) {
          const fileNameWithoutPath = path.basename(originalFileName);
          persistentFile = pdfStorageFiles.find(f => f.includes(fileNameWithoutPath));
        }
        
        if (persistentFile) {
          const persistentFilePath = path.join(PDF_STORAGE_DIR, persistentFile);
          console.log(`Trovato file persistente: ${persistentFilePath}`);
          
          // Copia il file dalla persistenza a uploads
          const recoveryFileName = `RECOVERED_${Date.now()}_${persistentFile}`;
          const recoveryPath = path.join(UPLOAD_DIR, recoveryFileName);
          
          // Assicurati che la directory di upload esista
          ensureDirectoryExists(UPLOAD_DIR);
          
          // Copia il file
          fs.copyFileSync(persistentFilePath, recoveryPath);
          console.log(`File recuperato dalla persistenza Replit: ${recoveryPath}`);
          
          return `/api/uploads/${recoveryFileName}`;
        } else {
          console.log("Nessun file persistente trovato in PDF_STORAGE_DIR");
        }
      } catch (persistError) {
        console.error("Errore nel recupero dalla persistenza Replit:", persistError);
      }
    }
    
    // SECONDO FALLBACK: Standard
    try {
      // Se c'è stato un errore, tenta un approccio di emergenza copiando direttamente nella root uploads
      console.log("Tentativo di recupero di emergenza...");
      
      // Verifica nuovamente che il file temporaneo esista
      if (!fs.existsSync(tempFilePath)) {
        throw new Error(`File temporaneo non trovato: ${tempFilePath}`);
      }
      
      // Assicurati che la directory di upload esista
      ensureDirectoryExists(UPLOAD_DIR);
      
      // Crea un nome file di emergenza più descrittivo
      const emergencyFileName = `EMERGENCY_${clientId || "NOCLIENT"}_${Date.now()}.pdf`;
      const emergencyPath = path.join(UPLOAD_DIR, emergencyFileName);
      
      // Tentativo diretto di copia nella cartella principale
      fs.copyFileSync(tempFilePath, emergencyPath);
      
      // Verifica dimensione del file di origine
      const tempStats = fs.statSync(tempFilePath);
      console.log(`File temporaneo: ${tempFilePath}, dimensione: ${tempStats.size} bytes`);
      
      // Verifica che il file di emergenza sia stato creato correttamente
      if (fs.existsSync(emergencyPath)) {
        const emergencyStats = fs.statSync(emergencyPath);
        console.log(`Recupero di emergenza riuscito: ${emergencyPath} (${emergencyStats.size} bytes)`);
        
        // Imposta i permessi del file di emergenza
        try {
          fs.chmodSync(emergencyPath, 0o666);
        } catch (chmodError) {
          console.error(`Non è stato possibile modificare i permessi per ${emergencyPath}:`, chmodError);
        }
        
        // Se siamo in Replit, salva una copia nella persistenza
        if (IN_REPLIT) {
          try {
            ensureDirectoryExists(PDF_STORAGE_DIR);
            const persistentPath = path.join(PDF_STORAGE_DIR, emergencyFileName);
            fs.copyFileSync(emergencyPath, persistentPath);
            console.log(`File di emergenza copiato nella persistenza Replit: ${persistentPath}`);
          } catch (persistError) {
            console.error("Errore nel salvataggio del file di emergenza nella persistenza:", persistError);
          }
        }
        
        return `/api/uploads/${emergencyFileName}`;
      } else {
        throw new Error("Il file di emergenza non è stato creato correttamente");
      }
    } catch (emergencyError) {
      console.error("Anche il recupero di emergenza è fallito:", emergencyError);
      
      // TERZO FALLBACK: cerca in attached_assets
      try {
        const attachedAssetsDir = path.join(process.cwd(), "attached_assets");
        const attachedFiles = fs.readdirSync(attachedAssetsDir).filter(f => f.endsWith('.pdf'));
        
        if (attachedFiles.length > 0) {
          // Usa il primo PDF disponibile
          const backupFile = attachedFiles[0];
          const sourcePath = path.join(attachedAssetsDir, backupFile);
          const destFileName = `BACKUP_${Date.now()}.pdf`;
          const destPath = path.join(UPLOAD_DIR, destFileName);
          
          fs.copyFileSync(sourcePath, destPath);
          console.log(`File di backup copiato da ${sourcePath} a ${destPath}`);
          
          return `/api/uploads/${destFileName}`;
        }
      } catch (backupError) {
        console.error("Anche il tentativo di backup è fallito:", backupError);
      }
      
      throw new Error(`Tutti i tentativi di salvataggio del PDF sono falliti: ${emergencyError instanceof Error ? emergencyError.message : String(emergencyError)}`);
    }
  }
}

// Configure multer for file uploads - using temporary directory
const upload = multer({
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, TEMP_DIR); // Usa la cartella temporanea per tutti i caricamenti iniziali
    },
    filename: function (req, file, cb) {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      
      // Usa il nome file originale se fornito nel form come originalName (per evitare "invoice.pdf" generico)
      const originalName = req.body.originalName || file.originalname;
      
      // Sostituisci spazi con trattini bassi nel nome del file per evitare problemi di URL
      const sanitizedName = originalName.replace(/\s+/g, '_');
      
      // Assicurati che il file abbia estensione .pdf
      let finalName = uniqueSuffix + "-" + sanitizedName;
      if (!finalName.toLowerCase().endsWith('.pdf')) {
        finalName += '.pdf';
      }
      
      console.log("File caricato con nome:", finalName);
      cb(null, finalName);
    }
  })
});

// Helper to check if user is authenticated
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

// Helper to check if user is admin
const isAdmin = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated() && req.user && req.user.role === "admin") {
    return next();
  }
  res.status(403).json({ message: "Forbidden - Admin access required" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Assicurati di nuovo che le directory esistano e siano accessibili
  try {
    console.log("Verifica e creazione directory uploads e temp...");
    ensureDirectoryExists(UPLOAD_DIR);
    ensureDirectoryExists(TEMP_DIR);
    
    // Imposta permessi per garantire accesso in scrittura alle cartelle
    fs.chmodSync(UPLOAD_DIR, 0o777);
    fs.chmodSync(TEMP_DIR, 0o777);
    
    console.log("Directory uploads e temp verificate e permessi impostati");
    
    // Verifica che le cartelle esistano dopo aver impostato i permessi
    if (!fs.existsSync(UPLOAD_DIR)) {
      console.error("ERRORE CRITICO: Directory uploads non esiste dopo la verifica");
    } else {
      console.log("Directory uploads confermata: ", UPLOAD_DIR);
    }
    
    if (!fs.existsSync(TEMP_DIR)) {
      console.error("ERRORE CRITICO: Directory temp non esiste dopo la verifica");
    } else {
      console.log("Directory temp confermata: ", TEMP_DIR);
    }
  } catch (dirError) {
    console.error("Errore durante la verifica delle directory:", dirError);
  }
  
  // API per la gestione utenti (solo admin)
  app.get("/api/users", isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Errore nel recupero degli utenti:", error);
      res.status(500).json({ message: "Errore del server" });
    }
  });
  
  // API per promuovere un utente ad amministratore (solo admin)
  app.patch("/api/users/:id/role", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const { role } = req.body;
      
      if (!role || (role !== "admin" && role !== "client")) {
        return res.status(400).json({ message: "Ruolo non valido. Deve essere 'admin' o 'client'" });
      }
      
      const user = await storage.updateUserRole(parseInt(id), role);
      
      if (!user) {
        return res.status(404).json({ message: "Utente non trovato" });
      }
      
      res.json(user);
    } catch (error) {
      console.error("Errore nell'aggiornamento del ruolo utente:", error);
      res.status(500).json({ message: "Errore del server" });
    }
  });
  
  // API per verificare e creare le cartelle cliente per tutti i client esistenti
  app.post("/api/admin/verify-client-folders", isAdmin, async (req, res) => {
    try {
      const clients = await storage.getClients();
      const results = [];
      
      for (const client of clients) {
        try {
          // Ottieni il nome della cartella per questo cliente
          const folderName = await getClientFolderName(client.id);
          const clientDir = path.join(UPLOAD_DIR, folderName);
          
          // Crea la cartella se non esiste
          if (!fs.existsSync(clientDir)) {
            ensureDirectoryExists(clientDir);
            // Definisco la struttura con il tipo corretto per oldFolder
            results.push({
              clientId: client.id,
              clientName: client.name,
              folderName: folderName,
              status: "created",
              message: `Cartella ${folderName} creata con successo`,
              oldFolder: null as string | null,
              filesCount: 0
            });
          } else {
            results.push({
              clientId: client.id,
              clientName: client.name,
              folderName: folderName,
              status: "exists",
              message: `Cartella ${folderName} esiste già`,
              oldFolder: null as string | null,
              filesCount: 0
            });
          }
          
          // Controlla se esiste anche la vecchia cartella client_X
          const oldFolderName = `client_${client.id}`;
          const oldClientDir = path.join(UPLOAD_DIR, oldFolderName);
          
          if (fs.existsSync(oldClientDir) && oldFolderName !== folderName) {
            // Se esiste una vecchia cartella con client_X, sposta tutti i file nella nuova cartella
            const files = fs.readdirSync(oldClientDir);
            
            for (const file of files) {
              const oldFilePath = path.join(oldClientDir, file);
              const newFilePath = path.join(clientDir, file);
              
              if (!fs.existsSync(newFilePath)) {
                fs.copyFileSync(oldFilePath, newFilePath);
                console.log(`File ${file} spostato da ${oldClientDir} a ${clientDir}`);
              }
            }
            
            // Cast a string | null per risolve il problema di tipi
            (results[results.length - 1] as any).oldFolder = oldFolderName;
            (results[results.length - 1] as any).filesCount = files.length;
            (results[results.length - 1] as any).message += `. Migrati ${files.length} file dalla vecchia cartella ${oldFolderName}`;
          }
        } catch (clientError) {
          console.error(`Errore per cliente ${client.id}:`, clientError);
          results.push({
            clientId: client.id,
            clientName: client.name,
            status: "error",
            message: String(clientError),
            oldFolder: null,
            filesCount: 0
          });
        }
      }
      
      res.json({
        total: clients.length,
        results: results
      });
    } catch (error) {
      console.error("Errore durante la verifica delle cartelle cliente:", error);
      res.status(500).json({ message: "Errore del server", error: String(error) });
    }
  });

  // Per i file statici in generale (non PDF)
  // Middleware per servire file dalle cartelle cliente con formati diversi
  app.get("/api/uploads/*", (req, res) => {
    // Estrai il percorso richiesto
    let filePath = req.path.replace('/api/uploads/', '');
    console.log("Richiesta file statico:", filePath);
    
    // Per evitare problemi di cache, aggiungiamo un parametro anti-cache alla richiesta
    // Costruisci il percorso completo
    const fullPath = path.join(UPLOAD_DIR, filePath);
    console.log("Percorso completo:", fullPath);
    
    // REPLIT SPECIFIC: Se siamo in Replit, controlliamo anche nelle directory persistenti
    if (IN_REPLIT) {
      // Cerca prima nella cartella uploads standard
      if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
        // File trovato in uploads, lo inviamo
        console.log(`File trovato in percorso standard: ${fullPath}`);
        
        // Impostiamo gli header anti-cache
        res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
        res.setHeader('Surrogate-Control', 'no-store');
        return res.sendFile(fullPath);
      }
      
      // Se non lo troviamo, controlla in PDF_STORAGE_DIR
      const fileName = path.basename(filePath);
      const persistentPath = path.join(PDF_STORAGE_DIR, fileName);
      
      if (fs.existsSync(persistentPath) && fs.statSync(persistentPath).isFile()) {
        console.log(`File trovato in Replit persistent storage: ${persistentPath}`);
        
        // Facciamo una copia in uploads per future richieste
        try {
          const recoveryPath = path.join(UPLOAD_DIR, `recovered_${Date.now()}_${fileName}`);
          fs.copyFileSync(persistentPath, recoveryPath);
          console.log(`File copiato da ${persistentPath} a ${recoveryPath}`);
          
          // Impostiamo gli header anti-cache
          res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
          res.setHeader('Pragma', 'no-cache');
          res.setHeader('Expires', '0');
          res.setHeader('Surrogate-Control', 'no-store');
          return res.sendFile(persistentPath);
        } catch (copyError) {
          console.error(`Errore nella copia del file persistente: ${copyError}`);
          
          // Invia direttamente il file persistente
          res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
          res.setHeader('Pragma', 'no-cache');
          res.setHeader('Expires', '0');
          res.setHeader('Surrogate-Control', 'no-store');
          return res.sendFile(persistentPath);
        }
      }
      
      // Controlla anche nella directory di backup
      const backupPath = path.join(BACKUP_DIR, fileName);
      if (fs.existsSync(backupPath) && fs.statSync(backupPath).isFile()) {
        console.log(`File trovato in Replit backup storage: ${backupPath}`);
        
        // Facciamo una copia in uploads per future richieste
        try {
          const recoveryPath = path.join(UPLOAD_DIR, `backup_${Date.now()}_${fileName}`);
          fs.copyFileSync(backupPath, recoveryPath);
          console.log(`File copiato da ${backupPath} a ${recoveryPath}`);
          
          // Impostiamo gli header anti-cache
          res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
          res.setHeader('Pragma', 'no-cache');
          res.setHeader('Expires', '0');
          res.setHeader('Surrogate-Control', 'no-store');
          return res.sendFile(backupPath);
        } catch (copyError) {
          console.error(`Errore nella copia del file di backup: ${copyError}`);
          
          // Invia direttamente il file di backup
          res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
          res.setHeader('Pragma', 'no-cache');
          res.setHeader('Expires', '0');
          res.setHeader('Surrogate-Control', 'no-store');
          return res.sendFile(backupPath);
        }
      }
      
      // Se non troviamo il file nelle cartelle persistenti, continua con la logica normale
    }
    
    // Verifica se il file esiste nell'uploads normale
    if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      res.setHeader('Surrogate-Control', 'no-store');
      return res.sendFile(fullPath);
    }
    
    // Supporto per sottodirectory dei client nel vecchio e nuovo formato
    const pathParts = filePath.split('/');
    
    if (pathParts.length > 1) {
      const clientFolder = pathParts[0];
      const fileName = pathParts.slice(1).join('/');
      
      // Controlla se è nel formato client_X
      const clientIdMatch = clientFolder.match(/^client_(\d+)$/);
      if (clientIdMatch) {
        // Prova a recuperare il nuovo nome cartella
        try {
          const clientId = parseInt(clientIdMatch[1]);
          storage.getClient(clientId).then(client => {
            if (client) {
              // Costruisci il percorso con il nome dell'azienda
              const newFolderName = `${client.name.replace(/\s+/g, '_')}_${client.id}`;
              const newPath = path.join(UPLOAD_DIR, newFolderName, fileName);
              
              if (fs.existsSync(newPath)) {
                return res.sendFile(newPath);
              }
            }
            // Se non troviamo il file con il nuovo percorso, ritorniamo 404
            return res.status(404).send("File non trovato");
          }).catch(err => {
            console.error("Errore nel recupero cliente:", err);
            return res.status(500).send("Errore server");
          });
          return; // Importante per evitare di continuare l'esecuzione
        } catch (error) {
          console.error("Errore nel recupero della cartella cliente:", error);
        }
      }
    }
    
    // Se non troviamo nulla, ritorna 404
    return res.status(404).send("File non trovato");
  });
  
  // Serviamo anche la directory principale per retrocompatibilità
  app.use("/api/uploads", express.static(UPLOAD_DIR));
  
  // Aggiungiamo un endpoint HEAD esplicito per verificare l'esistenza dei file
  app.head("/api/uploads/*", (req, res) => {
    // Estrai il percorso richiesto
    let filePath = req.path.replace('/api/uploads/', '');
    console.log("HEAD - Verifica esistenza file:", filePath);
    
    // Imposta header per evitare problemi di cache
    res.set({
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    });
    
    // Costruisci il percorso completo
    const fullPath = path.join(UPLOAD_DIR, filePath);
    
    // Verifica se il file esiste
    try {
      if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
        console.log("HEAD - File trovato:", fullPath);
        return res.sendStatus(200);
      }
      
      // Supporto per sottodirectory dei client
      const pathParts = filePath.split('/');
      
      if (pathParts.length > 1) {
        const clientFolder = pathParts[0];
        const fileName = pathParts.slice(1).join('/');
        
        // Controlla nelle cartelle dei client
        const clientDirs = fs.readdirSync(UPLOAD_DIR, { withFileTypes: true })
          .filter(dirent => dirent.isDirectory())
          .map(dirent => dirent.name);
        
        for (const clientDir of clientDirs) {
          const clientPath = path.join(UPLOAD_DIR, clientDir, fileName);
          if (fs.existsSync(clientPath) && fs.statSync(clientPath).isFile()) {
            console.log("HEAD - File trovato in cartella client:", clientPath);
            return res.sendStatus(200);
          }
        }
      }
      
      console.log("HEAD - File non trovato:", fullPath);
      return res.sendStatus(404);
    } catch (error) {
      console.error("HEAD - Errore nella verifica del file:", error);
      return res.sendStatus(500);
    }
  });
  
  // Aggiungiamo anche l'endpoint HEAD per il download-pdf
  app.head("/api/download-pdf/:filename", (req, res) => {
    let filename = req.params.filename;
    try {
      filename = decodeURIComponent(filename);
    } catch (e) {
      console.error("HEAD - Errore nella decodifica del nome file:", e);
    }
    
    console.log("HEAD - Verifica download PDF:", filename);
    
    // Imposta header per evitare problemi di cache
    res.set({
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    });
    
    // Supporta percorsi nidificati come "client_X/filename.pdf"
    let filePath = path.join(UPLOAD_DIR, filename);
    
    // Prima verifica il percorso esplicito
    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
      console.log("HEAD - File trovato al percorso esplicito:", filePath);
      return res.sendStatus(200);
    }
    
    // Se contiene slash, gestisci come percorso nidificato
    const pathParts = filename.split('/');
    if (pathParts.length > 1) {
      const clientFolder = pathParts[0];
      const fileNamePart = pathParts.slice(1).join('/');
      
      // Cerca nelle cartelle client
      const clientDirs = fs.readdirSync(UPLOAD_DIR, { withFileTypes: true })
        .filter(dirent => dirent.isDirectory())
        .map(dirent => dirent.name);
      
      for (const clientDir of clientDirs) {
        const clientPath = path.join(UPLOAD_DIR, clientDir, fileNamePart);
        if (fs.existsSync(clientPath) && fs.statSync(clientPath).isFile()) {
          console.log("HEAD - File trovato in cartella client:", clientPath);
          return res.sendStatus(200);
        }
      }
    } else {
      // Se è un nome file semplice, cerca in tutte le sottocartelle
      const clientDirs = fs.readdirSync(UPLOAD_DIR, { withFileTypes: true })
        .filter(dirent => dirent.isDirectory())
        .map(dirent => dirent.name);
      
      for (const clientDir of clientDirs) {
        const clientPath = path.join(UPLOAD_DIR, clientDir, filename);
        if (fs.existsSync(clientPath) && fs.statSync(clientPath).isFile()) {
          console.log("HEAD - File trovato in sottocartella:", clientPath);
          return res.sendStatus(200);
        }
      }
    }
    
    console.log("HEAD - File non trovato:", filePath);
    return res.sendStatus(404);
  });

  // Nuovo endpoint specializzato per servire PDF in modo affidabile
  app.get("/api/secure-pdf/:filename", async (req, res) => {
    let filename = req.params.filename;
    
    // Decodifica l'URI per gestire correttamente i caratteri speciali
    try {
      filename = decodeURIComponent(filename);
    } catch (e) {
      console.error("Errore nella decodifica del nome file:", e);
    }
    
    console.log("SECURE-PDF - Richiesta accesso al file:", filename);
    
    // Disabilita completamente il caching
    res.set({
      'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0',
      'Surrogate-Control': 'no-store'
    });
    
    // REPLIT SPECIFIC: Cerca prima nelle cartelle persistenti
    if (IN_REPLIT) {
      // Primo controllo: PDF_STORAGE_DIR
      const baseFileName = path.basename(filename);
      const persistentPath = path.join(PDF_STORAGE_DIR, baseFileName);
      
      if (fs.existsSync(persistentPath) && fs.statSync(persistentPath).isFile()) {
        console.log(`SECURE-PDF - File trovato in persistent storage: ${persistentPath}`);
        
        // Recupera il file in uploads
        const recoveryPath = path.join(UPLOAD_DIR, `recovered_${Date.now()}_${baseFileName}`);
        try {
          ensureDirectoryExists(UPLOAD_DIR);
          fs.copyFileSync(persistentPath, recoveryPath);
          console.log(`SECURE-PDF - File recuperato nella cartella upload: ${recoveryPath}`);
        } catch (copyError) {
          console.error(`SECURE-PDF - Errore nel recupero in uploads: ${copyError}`);
        }
        
        // Serve il file direttamente dalla cartella persistente
        return res.sendFile(persistentPath);
      }
      
      // Secondo controllo: BACKUP_DIR
      const backupPath = path.join(BACKUP_DIR, baseFileName);
      if (fs.existsSync(backupPath) && fs.statSync(backupPath).isFile()) {
        console.log(`SECURE-PDF - File trovato nel backup: ${backupPath}`);
        
        // Recupera il file in uploads
        const recoveryPath = path.join(UPLOAD_DIR, `backup_${Date.now()}_${baseFileName}`);
        try {
          ensureDirectoryExists(UPLOAD_DIR);
          fs.copyFileSync(backupPath, recoveryPath);
          console.log(`SECURE-PDF - File recuperato nella cartella upload: ${recoveryPath}`);
        } catch (copyError) {
          console.error(`SECURE-PDF - Errore nel recupero dal backup: ${copyError}`);
        }
        
        // Serve il file direttamente dalla cartella di backup
        return res.sendFile(backupPath);
      }
    }
    
    // Cerca PDF anche negli allegati e copia in uploads se necessario
    if (!filename.startsWith('attached_assets/') && !fs.existsSync(path.join(UPLOAD_DIR, filename))) {
      // Verifica se esiste in attached_assets
      const attachedAssetsDir = path.join(process.cwd(), "attached_assets");
      if (fs.existsSync(attachedAssetsDir)) {
        // Cerca in tutte le sottocartelle di attached_assets
        let attachedFiles: string[] = [];
        
        // Funzione ricorsiva per cercare file in tutte le sottocartelle (dichiarata fuori dal blocco)
        const searchPdfFilesInDir = (dir: string): string[] => {
          let results: string[] = [];
          const items = fs.readdirSync(dir, { withFileTypes: true });
          
          for (const item of items) {
            const itemPath = path.join(dir, item.name);
            if (item.isDirectory()) {
              results = [...results, ...searchPdfFilesInDir(itemPath)];
            } else if (item.isFile() && item.name.endsWith('.pdf')) {
              results.push(itemPath);
            }
          }
          
          return results;
        };
        
        // Cerca in tutte le sottocartelle
        try {
          const allPaths = searchPdfFilesInDir(attachedAssetsDir);
          
          // Estrai solo i nomi dei file con i loro percorsi relativi
          attachedFiles = allPaths.map(p => ({
            path: p,
            name: path.basename(p)
          })).filter(f => 
            f.name.toLowerCase().includes(path.basename(filename).toLowerCase()) || 
            path.basename(filename).toLowerCase().includes(f.name.toLowerCase().replace(/\s+/g, '_'))
          ).map(f => f.path);
          
          console.log(`SECURE-PDF - Trovati ${attachedFiles.length} file simili in attached_assets`);
        } catch (searchError) {
          console.error(`SECURE-PDF - Errore nella ricerca ricorsiva: ${searchError}`);
          
          // Fallback alla ricerca non ricorsiva
          attachedFiles = fs.readdirSync(attachedAssetsDir)
            .filter(f => f.endsWith('.pdf') && 
              (f.toLowerCase().includes(path.basename(filename).toLowerCase()) || 
               path.basename(filename).toLowerCase().includes(f.toLowerCase().replace(/\s+/g, '_')))
            )
            .map(f => path.join(attachedAssetsDir, f));
        }
        
        if (attachedFiles.length > 0) {
          // Prendi il primo file trovato
          const attachedFile = attachedFiles[0];
          // Nota: attachedFile è già il percorso completo dopo le modifiche
          const sourcePath = attachedFile;
          const targetPath = path.join(UPLOAD_DIR, filename);
          
          console.log(`SECURE-PDF - Copiando file da ${sourcePath} a ${targetPath}`);
          try {
            fs.copyFileSync(sourcePath, targetPath);
          } catch (err) {
            console.error(`SECURE-PDF - Errore nella copia del file: ${err}`);
          }
        }
      }
    }
    
    // Utilizza la nuova funzione findPdfFile per localizzare il file
    let fullPath = findPdfFile(filename);
    
    // Se non lo trova, tenta con nomi simili o file di fallback
    if (!fullPath) {
      // Prova a cercare file con nomi simili
      const uploadFiles = fs.readdirSync(UPLOAD_DIR);
      const similarFiles = uploadFiles.filter(f => 
        f.endsWith('.pdf') && 
        (f.includes(filename) || filename.includes(f))
      );
      
      if (similarFiles.length > 0) {
        fullPath = path.join(UPLOAD_DIR, similarFiles[0]);
        console.log(`SECURE-PDF - Trovato file simile: ${fullPath}`);
      } else {
        // Prova in attached_assets come ultimo tentativo
        const attachedAssetsDir = path.join(process.cwd(), "attached_assets");
        if (fs.existsSync(attachedAssetsDir)) {
          const attachedFiles = fs.readdirSync(attachedAssetsDir).filter(f => f.endsWith('.pdf'));
          if (attachedFiles.length > 0) {
            const sourcePath = path.join(attachedAssetsDir, attachedFiles[0]);
            const fallbackName = `fallback_${Date.now()}.pdf`;
            const targetPath = path.join(UPLOAD_DIR, fallbackName);
            
            console.log(`SECURE-PDF - Usando file di fallback: ${sourcePath}`);
            try {
              fs.copyFileSync(sourcePath, targetPath);
              fullPath = targetPath;
            } catch (err) {
              console.error(`SECURE-PDF - Errore nella copia del file di fallback: ${err}`);
            }
          }
        }
      }
    }
    
    if (fullPath) {
      console.log("SECURE-PDF - File trovato:", fullPath);
      
      // Controlla il parametro download per decidere se servire come attachment o inline
      const disposition = req.query.download === 'true' ? 'attachment' : 'inline';
      
      // Determina il nome del file per il download (estrai il nome base senza il timestamp se presente)
      let downloadName = path.basename(fullPath);
      
      // Rimuovi il timestamp dal nome se presente (formato: 1234567890-nome_file.pdf)
      const timestampMatch = downloadName.match(/^\d+-(.+)$/);
      if (timestampMatch) {
        downloadName = timestampMatch[1];
      }
      
      // Se richiesto dall'app, personalizza il nome del file con dati fattura
      if (req.query.invoiceId) {
        try {
          const invoiceId = parseInt(req.query.invoiceId as string);
          if (!isNaN(invoiceId)) {
            const invoice = await storage.getInvoice(invoiceId);
            if (invoice) {
              const client = await storage.getClient(invoice.clientId);
              const clientName = client ? client.name.replace(/\s+/g, '_') : 'Cliente';
              // Formatta la data in modo leggibile (DD-MM-YYYY)
              const formattedDate = invoice.issueDate 
                ? new Date(invoice.issueDate).toLocaleDateString('it-IT').replace(/\//g, '-')
                : 'NoData';
              
              // Crea un nome file descrittivo: Fattura_NumeroFattura_DataEmissione_Cliente.pdf
              downloadName = `Fattura_${invoice.number}_${formattedDate}_${clientName}.pdf`;
            }
          }
        } catch (err) {
          console.error('Errore durante il recupero delle info fattura:', err);
          // In caso di errore, usa il nome originale
        }
      }
      
      // Imposta header specifici anti-cache e con ETag dinamico
      const etag = `"pdf-${Date.now()}-${Math.random().toString(36).substring(2, 8)}"`;
      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `${disposition}; filename="${downloadName}"`,
        'ETag': etag,
        'Last-Modified': new Date().toUTCString(),
        'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0',
        'Pragma': 'no-cache',
        'Expires': '0'
      });
      
      // Usa sendFile con le opzioni per gestire errori
      res.sendFile(fullPath, {
        headers: {
          'Content-Type': 'application/pdf',
          'Content-Disposition': `${disposition}; filename="${downloadName}"`,
          'ETag': etag
        }
      }, (err) => {
        if (err) {
          console.error("SECURE-PDF - Errore nell'invio del file:", err);
          // Se c'è un errore nell'invio, ritentiamo con readFile
          try {
            if (fs.existsSync(fullPath)) {
              const fileContent = fs.readFileSync(fullPath);
              res.send(fileContent);
            } else {
              res.status(404).send("File not found on retry");
            }
          } catch (retryErr) {
            console.error("SECURE-PDF - Errore anche nel tentativo di retry:", retryErr);
            res.status(500).send("Error serving file");
          }
        }
      });
    } else {
      console.error("SECURE-PDF - File non trovato:", filename);
      res.status(404).send("File not found");
    }
  });
  
  // Endpoint tradizionale per scaricare PDF come attachment (manteniamo per retrocompatibilità)
  app.get("/api/download-pdf/:filename", (req, res) => {
    let filename = req.params.filename;
    // Decodifica l'URI per gestire correttamente i caratteri speciali
    try {
      filename = decodeURIComponent(filename);
    } catch (e) {
      console.error("Errore nella decodifica del nome file:", e);
    }
    
    console.log("Richiesta download PDF:", filename);
    
    // Supporta percorsi nidificati come "client_X/filename.pdf" o "NOME_AZIENDA_X/filename.pdf"
    // Estrae prima il percorso completo basato sulla potenziale struttura nidificata
    let directoryPart = "";
    let filePart = filename;
    const pathParts = filename.split('/');
    
    if (pathParts.length > 1) {
      // Se il nome del file contiene "/", allora è un percorso nidificato
      directoryPart = pathParts.slice(0, -1).join('/');
      filePart = pathParts[pathParts.length - 1];
    }
    
    let filePath = path.join(UPLOAD_DIR, filename);
    let clientId = null;
    let clientFolderName = null;
    
    // Determina il percorso del file basandosi sulla struttura directory/filename
    if (directoryPart.length === 0) {
      // Caso 1: nessun percorso nidificato, prova direttamente in uploads/
      console.log("Provo percorso diretto:", filePath);
    }
    // Caso 2: percorso nidificato con formato client_X
    else if (directoryPart.match(/^client_\d+$/)) {
      const match = directoryPart.match(/^client_(\d+)$/);
      if (match) {
        clientId = match[1];
        clientFolderName = directoryPart;
        filePath = path.join(UPLOAD_DIR, clientFolderName, filePart);
        console.log("Provo percorso vecchio formato (client_X):", filePath);
      }
    } 
    // Caso 3: percorso nidificato con nuovo formato (NOME_AZIENDA_X)
    else if (directoryPart.includes('_')) {
      const matches = directoryPart.match(/_(\d+)$/);
      if (matches) {
        clientId = matches[1];
        clientFolderName = directoryPart;
        filePath = path.join(UPLOAD_DIR, clientFolderName, filePart);
        console.log("Provo percorso nuovo formato (NOME_AZIENDA_X):", filePath);
      } else {
        // Se non contiene un ID in fondo, prova comunque il percorso
        clientFolderName = directoryPart;
        filePath = path.join(UPLOAD_DIR, clientFolderName, filePart);
        console.log("Provo percorso cartella generica:", filePath);
      }
    }
    
    console.log("Percorso file completo:", filePath);
    
    // Verifica se il file esiste (prima strategia)
    if (fs.existsSync(filePath)) {
      // File trovato esattamente come richiesto
      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${filePart}"`,
        'Cache-Control': 'public, max-age=3600',
      });
      const stat = fs.statSync(filePath);
      console.log(`File size: ${stat.size} bytes`);
      return res.sendFile(filePath);
    }
    
    // Estrai informazioni dal nome del file per ricerca intelligente
    let invoiceNumber = null;
    let clientName = null;
    
    // Tenta di estrarre il numero di fattura dal nome file
    const invoiceNumberMatch = filePart.match(/[^a-zA-Z0-9]([0-9]{1,5}(-|_|\s)?[A-Z]?)[^a-zA-Z0-9]/);
    if (invoiceNumberMatch) {
      invoiceNumber = invoiceNumberMatch[1].trim();
      console.log("Numero fattura estratto:", invoiceNumber);
    }
    
    // Tenta di estrarre il nome cliente dal nome file
    const clientNameMatch = filePart.match(/(MULTI[\s_-]*GENERAL[\s_-]*SERVICE|MGS)/i);
    if (clientNameMatch) {
      clientName = clientNameMatch[1].trim();
      console.log("Nome cliente estratto:", clientName);
    }
    
    // Se non è stato trovato e non abbiamo già cercato in una sottocartella, proviamo nelle cartelle dei client
    if (!clientId || !fs.existsSync(filePath)) {
      // Legge tutte le directory dei client
      const clientDirs = fs.readdirSync(UPLOAD_DIR, { withFileTypes: true })
        .filter(dirent => dirent.isDirectory() && dirent.name.startsWith('client_'))
        .map(dirent => dirent.name);
      
      console.log("Cercando nelle cartelle client:", clientDirs);
      
      // Cerca in tutte le cartelle dei client
      for (const clientDir of clientDirs) {
        const clientPath = path.join(UPLOAD_DIR, clientDir);
        try {
          const clientFiles = fs.readdirSync(clientPath);
          
          // 1. Prova con il nome esatto
          if (clientFiles.includes(filePart)) {
            filePath = path.join(clientPath, filePart);
            console.log("Trovato file esatto in cartella client:", clientDir);
            res.set({
              'Content-Type': 'application/pdf',
              'Content-Disposition': `attachment; filename="${filePart}"`,
              'Cache-Control': 'public, max-age=3600',
            });
            return res.sendFile(filePath);
          }
          
          // 2. Ricerca basata sul numero di fattura (se disponibile)
          if (invoiceNumber) {
            const matchByInvoiceNumber = clientFiles.find(file => {
              return file.includes(invoiceNumber) && file.endsWith('.pdf');
            });
            
            if (matchByInvoiceNumber) {
              filePath = path.join(clientPath, matchByInvoiceNumber);
              console.log("Trovato file tramite numero fattura in cartella client:", clientDir);
              res.set({
                'Content-Type': 'application/pdf',
                'Content-Disposition': `attachment; filename="${matchByInvoiceNumber}"`,
                'Cache-Control': 'public, max-age=3600',
              });
              return res.sendFile(filePath);
            }
          }
          
          // 3. Ricerca basata sul nome del cliente (se disponibile)
          if (clientName) {
            const matchByClientName = clientFiles.find(file => {
              return file.toUpperCase().includes(clientName.toUpperCase()) && file.endsWith('.pdf');
            });
            
            if (matchByClientName) {
              filePath = path.join(clientPath, matchByClientName);
              console.log("Trovato file tramite nome cliente in cartella client:", clientDir);
              res.set({
                'Content-Type': 'application/pdf',
                'Content-Disposition': `attachment; filename="${matchByClientName}"`,
                'Cache-Control': 'public, max-age=3600',
              });
              return res.sendFile(filePath);
            }
          }
          
          // 4. Prova cercando un file simile
          if (filePart.includes('.pdf')) {
            const baseFileName = filePart.split('.pdf')[0];
            const similarMatch = clientFiles.find(file => 
              file.endsWith(`${baseFileName}.pdf`) || 
              file.includes(baseFileName)
            );
            
            if (similarMatch) {
              filePath = path.join(clientPath, similarMatch);
              console.log("Trovato file simile in cartella client:", clientDir);
              res.set({
                'Content-Type': 'application/pdf',
                'Content-Disposition': `attachment; filename="${similarMatch}"`,
                'Cache-Control': 'public, max-age=3600',
              });
              return res.sendFile(filePath);
            }
          }
        } catch (error) {
          console.error(`Errore nella lettura della directory ${clientDir}:`, error);
        }
      }
    }
    
    // Se ancora non trovato, prova nella cartella principale
    // Prova a fare una ricerca più flessibile (con glob pattern)
    const uploadFiles = fs.readdirSync(UPLOAD_DIR);
    
    // 1. Prova con il nome esatto
    const exactMatch = uploadFiles.find(file => file === filePart);
    if (exactMatch) {
      filePath = path.join(UPLOAD_DIR, exactMatch);
      console.log("Trovato file con nome esatto nella directory principale:", exactMatch);
      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${exactMatch}"`,
        'Cache-Control': 'public, max-age=3600',
      });
      return res.sendFile(filePath);
    }
    
    // 2. Cerca per numero fattura se disponibile
    if (invoiceNumber) {
      const matchByInvoiceNumber = uploadFiles.find(file => {
        return file.includes(invoiceNumber) && file.endsWith('.pdf');
      });
      
      if (matchByInvoiceNumber) {
        filePath = path.join(UPLOAD_DIR, matchByInvoiceNumber);
        console.log("Trovato file tramite numero fattura nella directory principale:", matchByInvoiceNumber);
        res.set({
          'Content-Type': 'application/pdf',
          'Content-Disposition': `attachment; filename="${matchByInvoiceNumber}"`,
          'Cache-Control': 'public, max-age=3600',
        });
        return res.sendFile(filePath);
      }
    }
    
    // 3. Prova cercando il nome file al termine del percorso (ignora timestamp e id)
    if (filePart.includes('.pdf')) {
      const baseFileName = filePart.split('.pdf')[0];
      const similarMatch = uploadFiles.find(file => 
        file.endsWith(`${baseFileName}.pdf`) || 
        file.includes(baseFileName)
      );
      
      if (similarMatch) {
        filePath = path.join(UPLOAD_DIR, similarMatch);
        console.log("Trovato file simile nella directory principale:", similarMatch);
        res.set({
          'Content-Type': 'application/pdf',
          'Content-Disposition': `attachment; filename="${similarMatch}"`,
          'Cache-Control': 'public, max-age=3600',
        });
        return res.sendFile(filePath);
      }
    }
    
    // Ricerca in attached_assets come ultima risorsa
    const attachedAssetsDir = path.join(process.cwd(), "attached_assets");
    try {
      if (fs.existsSync(attachedAssetsDir)) {
        const assetFiles = fs.readdirSync(attachedAssetsDir);
        
        // Ricerca basata sul numero fattura
        if (invoiceNumber) {
          const matchByInvoiceNumber = assetFiles.find(file => {
            return file.includes(invoiceNumber) && file.endsWith('.pdf');
          });
          
          if (matchByInvoiceNumber) {
            // Copia il file nella cartella corretta
            const sourcePath = path.join(attachedAssetsDir, matchByInvoiceNumber);
            const targetDir = clientId ? path.join(UPLOAD_DIR, `client_${clientId}`) : UPLOAD_DIR;
            ensureDirectoryExists(targetDir);
            
            const sanitizedName = matchByInvoiceNumber.replace(/\s+/g, '_');
            const timestamp = Date.now();
            const newFilename = `${timestamp}-${sanitizedName}`;
            const targetPath = path.join(targetDir, newFilename);
            
            console.log(`Copiando file da ${sourcePath} a ${targetPath}`);
            fs.copyFileSync(sourcePath, targetPath);
            
            res.set({
              'Content-Type': 'application/pdf',
              'Content-Disposition': `attachment; filename="${matchByInvoiceNumber}"`,
              'Cache-Control': 'public, max-age=3600',
            });
            return res.sendFile(targetPath);
          }
        }
      }
    } catch (error) {
      console.error("Errore durante la ricerca in attached_assets:", error);
    }
    
    // Nessun file trovato
    console.log("Nessun file trovato in nessuna directory");
    return res.status(404).send("PDF file not found");
  });

  // Endpoint specifico per visualizzare PDF da uploads con gestione robusta degli errori
  app.get("/api/view-pdf/:filename", (req, res) => {
    let filename = req.params.filename;
    // Decodifica l'URI per gestire correttamente i caratteri speciali
    try {
      filename = decodeURIComponent(filename);
    } catch (e) {
      console.error("Errore nella decodifica del nome file:", e);
    }
    
    console.log("Richiesta visualizzazione PDF:", filename);
    
    // Supporta percorsi nidificati come "client_X/filename.pdf" o "NOME_AZIENDA_X/filename.pdf"
    // Estrae prima il percorso completo basato sulla potenziale struttura nidificata
    let directoryPart = "";
    let filePart = filename;
    const pathParts = filename.split('/');
    
    if (pathParts.length > 1) {
      // Se il nome del file contiene "/", allora è un percorso nidificato
      directoryPart = pathParts[0];
      filePart = pathParts.slice(1).join('/');
      console.log(`Percorso nidificato rilevato: directory=${directoryPart}, file=${filePart}`);
    }
    
    let filePath = "";
    let clientFolderName = "";
    let clientId = null;
    
    // Caso 1: Percorso non nidificato (file direttamente in uploads)
    if (!directoryPart) {
      filePath = path.join(UPLOAD_DIR, filename);
      console.log("Provo percorso semplice:", filePath);
    } 
    // Caso 2: percorso nidificato con formato client_X
    else if (directoryPart.match(/^client_\d+$/)) {
      const match = directoryPart.match(/^client_(\d+)$/);
      if (match) {
        clientId = match[1];
        clientFolderName = directoryPart;
        filePath = path.join(UPLOAD_DIR, clientFolderName, filePart);
        console.log("Provo percorso vecchio formato (client_X):", filePath);
      }
    } 
    // Caso 3: percorso nidificato con nuovo formato (NOME_AZIENDA_X)
    else if (directoryPart.includes('_')) {
      const matches = directoryPart.match(/_(\d+)$/);
      if (matches) {
        clientId = matches[1];
        clientFolderName = directoryPart;
        filePath = path.join(UPLOAD_DIR, clientFolderName, filePart);
        console.log("Provo percorso nuovo formato (NOME_AZIENDA_X):", filePath);
      } else {
        // Se non contiene un ID in fondo, prova comunque il percorso
        clientFolderName = directoryPart;
        filePath = path.join(UPLOAD_DIR, clientFolderName, filePart);
        console.log("Provo percorso cartella generica:", filePath);
      }
    }
    
    console.log("Percorso file completo:", filePath);
    
    // Verifica se il file esiste (prima strategia)
    if (fs.existsSync(filePath)) {
      // File trovato esattamente come richiesto
      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `inline; filename="${filePart}"`,
        'Cache-Control': 'public, max-age=3600',
      });
      return res.sendFile(filePath);
    }
    
    // Estrai informazioni dal nome del file per ricerca intelligente
    let invoiceNumber = null;
    let clientName = null;
    
    // Tenta di estrarre il numero di fattura dal nome file
    const invoiceNumberMatch = filePart.match(/[^a-zA-Z0-9]([0-9]{1,5}(-|_|\s)?[A-Z]?)[^a-zA-Z0-9]/);
    if (invoiceNumberMatch) {
      invoiceNumber = invoiceNumberMatch[1].trim();
      console.log("Numero fattura estratto:", invoiceNumber);
    }
    
    // Tenta di estrarre il nome cliente dal nome file
    const clientNameMatch = filePart.match(/(MULTI[\s_-]*GENERAL[\s_-]*SERVICE|MGS)/i);
    if (clientNameMatch) {
      clientName = clientNameMatch[1].trim();
      console.log("Nome cliente estratto:", clientName);
    }
    
    // Se non è stato trovato e non abbiamo già cercato in una sottocartella, proviamo nelle cartelle dei client
    if (!clientId || !fs.existsSync(filePath)) {
      // Legge tutte le directory dei client
      const clientDirs = fs.readdirSync(UPLOAD_DIR, { withFileTypes: true })
        .filter(dirent => dirent.isDirectory() && dirent.name.startsWith('client_'))
        .map(dirent => dirent.name);
      
      console.log("Cercando nelle cartelle client:", clientDirs);
      
      // Cerca in tutte le cartelle dei client
      for (const clientDir of clientDirs) {
        const clientPath = path.join(UPLOAD_DIR, clientDir);
        try {
          const clientFiles = fs.readdirSync(clientPath);
          
          // 1. Prova con il nome esatto
          if (clientFiles.includes(filePart)) {
            filePath = path.join(clientPath, filePart);
            console.log("Trovato file esatto in cartella client:", clientDir);
            res.set({
              'Content-Type': 'application/pdf',
              'Content-Disposition': `inline; filename="${filePart}"`,
              'Cache-Control': 'public, max-age=3600',
            });
            return res.sendFile(filePath);
          }
          
          // 2. Ricerca basata sul numero di fattura (se disponibile)
          if (invoiceNumber) {
            const matchByInvoiceNumber = clientFiles.find(file => {
              return file.includes(invoiceNumber) && file.endsWith('.pdf');
            });
            
            if (matchByInvoiceNumber) {
              filePath = path.join(clientPath, matchByInvoiceNumber);
              console.log("Trovato file tramite numero fattura in cartella client:", clientDir);
              res.set({
                'Content-Type': 'application/pdf',
                'Content-Disposition': `inline; filename="${matchByInvoiceNumber}"`,
                'Cache-Control': 'public, max-age=3600',
              });
              return res.sendFile(filePath);
            }
          }
          
          // 3. Ricerca basata sul nome del cliente (se disponibile)
          if (clientName) {
            const matchByClientName = clientFiles.find(file => {
              return file.toUpperCase().includes(clientName.toUpperCase()) && file.endsWith('.pdf');
            });
            
            if (matchByClientName) {
              filePath = path.join(clientPath, matchByClientName);
              console.log("Trovato file tramite nome cliente in cartella client:", clientDir);
              res.set({
                'Content-Type': 'application/pdf',
                'Content-Disposition': `inline; filename="${matchByClientName}"`,
                'Cache-Control': 'public, max-age=3600',
              });
              return res.sendFile(filePath);
            }
          }
          
          // 4. Prova cercando un file simile
          if (filePart.includes('.pdf')) {
            const baseFileName = filePart.split('.pdf')[0];
            const similarMatch = clientFiles.find(file => 
              file.endsWith(`${baseFileName}.pdf`) || 
              file.includes(baseFileName)
            );
            
            if (similarMatch) {
              filePath = path.join(clientPath, similarMatch);
              console.log("Trovato file simile in cartella client:", clientDir);
              res.set({
                'Content-Type': 'application/pdf',
                'Content-Disposition': `inline; filename="${similarMatch}"`,
                'Cache-Control': 'public, max-age=3600',
              });
              return res.sendFile(filePath);
            }
          }
        } catch (error) {
          console.error(`Errore nella lettura della directory ${clientDir}:`, error);
        }
      }
    }
    
    // Se ancora non trovato, prova nella cartella principale
    // Prova a fare una ricerca più flessibile (con glob pattern)
    const uploadFiles = fs.readdirSync(UPLOAD_DIR);
    
    // 1. Prova con il nome esatto
    const exactMatch = uploadFiles.find(file => file === filePart);
    if (exactMatch) {
      filePath = path.join(UPLOAD_DIR, exactMatch);
      console.log("Trovato file con nome esatto nella directory principale:", exactMatch);
      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `inline; filename="${exactMatch}"`,
        'Cache-Control': 'public, max-age=3600',
      });
      return res.sendFile(filePath);
    }
    
    // 2. Cerca per numero fattura se disponibile
    if (invoiceNumber) {
      const matchByInvoiceNumber = uploadFiles.find(file => {
        return file.includes(invoiceNumber) && file.endsWith('.pdf');
      });
      
      if (matchByInvoiceNumber) {
        filePath = path.join(UPLOAD_DIR, matchByInvoiceNumber);
        console.log("Trovato file tramite numero fattura nella directory principale:", matchByInvoiceNumber);
        res.set({
          'Content-Type': 'application/pdf',
          'Content-Disposition': `inline; filename="${matchByInvoiceNumber}"`,
          'Cache-Control': 'public, max-age=3600',
        });
        return res.sendFile(filePath);
      }
    }
    
    // 3. Prova cercando il nome file al termine del percorso (ignora timestamp e id)
    if (filePart.includes('.pdf')) {
      const baseFileName = filePart.split('.pdf')[0];
      const similarMatch = uploadFiles.find(file => 
        file.endsWith(`${baseFileName}.pdf`) || 
        file.includes(baseFileName)
      );
      
      if (similarMatch) {
        filePath = path.join(UPLOAD_DIR, similarMatch);
        console.log("Trovato file simile nella directory principale:", similarMatch);
        res.set({
          'Content-Type': 'application/pdf',
          'Content-Disposition': `inline; filename="${similarMatch}"`,
          'Cache-Control': 'public, max-age=3600',
        });
        return res.sendFile(filePath);
      }
    }
    
    // Ricerca in attached_assets come ultima risorsa
    const attachedAssetsDir = path.join(process.cwd(), "attached_assets");
    try {
      if (fs.existsSync(attachedAssetsDir)) {
        const assetFiles = fs.readdirSync(attachedAssetsDir);
        
        // Ricerca basata sul numero fattura
        if (invoiceNumber) {
          const matchByInvoiceNumber = assetFiles.find(file => {
            return file.includes(invoiceNumber) && file.endsWith('.pdf');
          });
          
          if (matchByInvoiceNumber) {
            // Copia il file nella cartella corretta
            const sourcePath = path.join(attachedAssetsDir, matchByInvoiceNumber);
            const targetDir = clientId ? path.join(UPLOAD_DIR, `client_${clientId}`) : UPLOAD_DIR;
            ensureDirectoryExists(targetDir);
            
            const sanitizedName = matchByInvoiceNumber.replace(/\s+/g, '_');
            const timestamp = Date.now();
            const newFilename = `${timestamp}-${sanitizedName}`;
            const targetPath = path.join(targetDir, newFilename);
            
            console.log(`Copiando file da ${sourcePath} a ${targetPath}`);
            fs.copyFileSync(sourcePath, targetPath);
            
            res.set({
              'Content-Type': 'application/pdf',
              'Content-Disposition': `inline; filename="${matchByInvoiceNumber}"`,
              'Cache-Control': 'public, max-age=3600',
            });
            return res.sendFile(targetPath);
          }
        }
      }
    } catch (error) {
      console.error("Errore durante la ricerca in attached_assets:", error);
    }
    
    // Nessun file trovato
    console.log("Nessun file trovato in nessuna directory");
    return res.status(404).send("PDF file not found");
  });
  
  // Serve temporary files - importante per l'anteprima prima del salvataggio definitivo
  // Gestione avanzata dei file temporanei
  app.get("/api/temp/:filename", (req, res) => {
    const filename = req.params.filename;
    // Prima tenta con il nome esatto
    let filePath = path.join(TEMP_DIR, filename);
    
    console.log("Richiesto file temporaneo:", filename);
    console.log("Percorso 1 (esatto):", filePath);
    
    if (fs.existsSync(filePath)) {
      console.log("File trovato con nome esatto, invio al client");
      // Aggiungi intestazioni appropriate per consentire corretta visualizzazione
      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `inline; filename="${filename}"`,
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      });
      return res.sendFile(filePath);
    }
    
    // Secondo tentativo: sostituisci underscore con spazi
    const originalFilename = filename.replace(/_/g, ' ');
    const originalFilePath = path.join(TEMP_DIR, originalFilename);
    console.log("Percorso 2 (spazi):", originalFilePath);
    
    if (fs.existsSync(originalFilePath)) {
      console.log("File trovato con spazi, invio al client");
      // Aggiungi intestazioni appropriate
      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `inline; filename="${originalFilename}"`,
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      });
      return res.sendFile(originalFilePath);
    }
    
    // Terzo tentativo: URL-decode il nome file
    try {
      const decodedFilename = decodeURIComponent(filename);
      if (decodedFilename !== filename) {
        const decodedFilePath = path.join(TEMP_DIR, decodedFilename);
        console.log("Percorso 3 (URL-decoded):", decodedFilePath);
        
        if (fs.existsSync(decodedFilePath)) {
          console.log("File trovato con URL-decode, invio al client");
          // Aggiungi intestazioni appropriate
          res.set({
            'Content-Type': 'application/pdf',
            'Content-Disposition': `inline; filename="${decodedFilename}"`,
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache',
            'Expires': '0'
          });
          return res.sendFile(decodedFilePath);
        }
      }
    } catch (e) {
      console.error("Errore durante il decode del nome file:", e);
    }
    
    // Quarto tentativo: cerca qualsiasi file che corrisponda ignorando la parte numerica iniziale
    console.log("Tentativo di ricerca avanzata del file");
    const filePattern = filename.replace(/^\d+-\d+-/, '');
    const tempFiles = fs.readdirSync(TEMP_DIR);
    
    const matchingFile = tempFiles.find(file => 
      file.includes(filePattern) || file.includes(filePattern.replace(/_/g, ' '))
    );
    
    if (matchingFile) {
      const matchingFilePath = path.join(TEMP_DIR, matchingFile);
      console.log("File simile trovato:", matchingFile);
      return res.sendFile(matchingFilePath);
    }
    
    // Nessun file trovato
    console.log("File non trovato con nessun metodo, risposta 404");
    return res.status(404).send("File not found");
  });
  
  // Nuovo endpoint per accedere ai file temporanei tramite timestamp e id
  app.get("/api/temp-file/:timestamp/:id", (req, res) => {
    const { timestamp, id } = req.params;
    const prefix = `${timestamp}-${id}-`;
    
    try {
      const tempFiles = fs.readdirSync(TEMP_DIR);
      const matchingFile = tempFiles.find(file => file.startsWith(prefix));
      
      if (matchingFile) {
        const filePath = path.join(TEMP_DIR, matchingFile);
        console.log("File trovato tramite id:", matchingFile);
        
        // Aggiungi intestazioni appropriate per consentire corretta visualizzazione
        res.set({
          'Content-Type': 'application/pdf',
          'Content-Disposition': `inline; filename="${matchingFile}"`,
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        });
        
        return res.sendFile(filePath);
      }
      
      console.log("Nessun file trovato con il prefisso:", prefix);
      return res.status(404).send("File not found");
    } catch (error) {
      console.error("Errore nella ricerca file per ID:", error);
      return res.status(500).send("Server error");
    }
  });
  
  // Stampa le directory configurate per debug
  console.log("Directory uploads:", UPLOAD_DIR);
  console.log("Directory temp:", TEMP_DIR);

  // CLIENT ROUTES

  // Get client profile for current user
  app.get("/api/client/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const clients = await storage.getClientsByUserId(userId);
      
      if (!clients || clients.length === 0) {
        return res.status(404).json({ message: "Client profile not found" });
      }
      
      // Return the first client associated with this user
      res.json(clients[0]);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  // Get invoices for current client
  app.get("/api/client/invoices", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const clients = await storage.getClientsByUserId(userId);
      
      if (!clients || clients.length === 0) {
        return res.status(404).json({ message: "Client profile not found" });
      }
      
      const clientId = clients[0].id;
      const invoices = await storage.getInvoicesByClientId(clientId);
      
      res.json(invoices);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  // Get specific invoice for client
  app.get("/api/client/invoices/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const clients = await storage.getClientsByUserId(userId);
      
      if (!clients || clients.length === 0) {
        return res.status(404).json({ message: "Client profile not found" });
      }
      
      const clientId = clients[0].id;
      const invoiceId = parseInt(req.params.id);
      
      if (isNaN(invoiceId)) {
        return res.status(400).json({ message: "Invalid invoice ID" });
      }
      
      const invoice = await storage.getInvoice(invoiceId);
      
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      
      if (invoice.clientId !== clientId) {
        return res.status(403).json({ message: "Not authorized to access this invoice" });
      }
      
      const invoiceWithItems = await storage.getInvoiceWithItems(invoiceId);
      res.json(invoiceWithItems);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  // ADMIN ROUTES

  // Get all clients
  app.get("/api/admin/clients", isAdmin, async (req, res) => {
    try {
      const clients = await storage.getClients();
      res.json(clients);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  // Get specific client
  app.get("/api/admin/clients/:id", isAdmin, async (req, res) => {
    try {
      const clientId = parseInt(req.params.id);
      
      if (isNaN(clientId)) {
        return res.status(400).json({ message: "Invalid client ID" });
      }
      
      const client = await storage.getClient(clientId);
      
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }
      
      res.json(client);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  // Create new client
  app.post("/api/admin/clients", isAdmin, async (req, res) => {
    try {
      const clientData = insertClientSchema.parse(req.body);
      const client = await storage.createClient(clientData);
      res.status(201).json(client);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid client data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error });
    }
  });

  // Update client
  app.put("/api/admin/clients/:id", isAdmin, async (req, res) => {
    try {
      const clientId = parseInt(req.params.id);
      
      if (isNaN(clientId)) {
        return res.status(400).json({ message: "Invalid client ID" });
      }
      
      const client = await storage.getClient(clientId);
      
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }
      
      const clientData = insertClientSchema.partial().parse(req.body);
      const updatedClient = await storage.updateClient(clientId, clientData);
      
      res.json(updatedClient);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid client data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error });
    }
  });

  // Delete client
  app.delete("/api/admin/clients/:id", isAdmin, async (req, res) => {
    try {
      const clientId = parseInt(req.params.id);
      
      if (isNaN(clientId)) {
        return res.status(400).json({ message: "Invalid client ID" });
      }
      
      const client = await storage.getClient(clientId);
      
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }
      
      const deleted = await storage.deleteClient(clientId);
      
      if (!deleted) {
        return res.status(500).json({ message: "Failed to delete client" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  // Get all invoices with client info
  app.get("/api/admin/invoices", isAdmin, async (req, res) => {
    try {
      console.log("Richiesta di tutte le fatture ricevuta");
      const invoices = await storage.getInvoices();
      console.log(`Trovate ${invoices.length} fatture nel database`);
      
      // Verifica che le fatture contengano dati validi
      if (invoices.length > 0) {
        console.log("Prima fattura:", {
          id: invoices[0].id,
          number: invoices[0].number,
          clientName: invoices[0].client?.name
        });
      }
      
      res.json(invoices);
    } catch (error) {
      console.error("Errore nel recupero delle fatture:", error);
      res.status(500).json({ message: "Errore nel recupero delle fatture", error });
    }
  });
  
  // API per ottenere le fatture senza PDF
  app.get("/api/admin/invoices/missing-pdf", isAdmin, async (req, res) => {
    try {
      const allInvoices = await storage.getInvoices();
      
      // Filtra le fatture senza PDF o con PDF non esistenti
      const missingPdfInvoices = await Promise.all(
        allInvoices.map(async (invoice) => {
          // Verifica se ci sono allegati disponibili
          const hasAttachments = invoice.attachments && Array.isArray(invoice.attachments) && invoice.attachments.length > 0;
          
          // Se non c'è nessun documento (né pdfPath né attachments), è sicuramente mancante
          if (!invoice.pdfPath && !hasAttachments) {
            return { 
              ...invoice, 
              reason: "PDF mancante", 
              paths_checked: ["Nessun documento disponibile"],
              amount: Number(invoice.amount) // Assicuriamoci che amount sia un numero per evitare problemi
            };
          }
          
          // Array dei percorsi controllati (per debugging)
          const pathsChecked = [];
          let fileExists = false;
          
          // Caso 1: Controlla pdfPath se esiste
          if (invoice.pdfPath) {
            const filePath = path.join(process.cwd(), invoice.pdfPath.replace("/api/uploads/", "uploads/"));
            pathsChecked.push(filePath);
            fileExists = fs.existsSync(filePath);
            
            // Se non esiste nel percorso principale, prova con le varianti di percorso cliente
            if (!fileExists && invoice.clientId) {
              try {
                // Prova con la variante nuova (nome_cliente_ID)
                const clientFolderName = await getClientFolderName(invoice.clientId);
                const clientFolderPath = path.join(process.cwd(), "uploads", clientFolderName);
                
                // Se la cartella del cliente esiste, cerca il file al suo interno
                if (fs.existsSync(clientFolderPath)) {
                  // Ottieni il nome del file dal percorso originale
                  const fileName = path.basename(filePath);
                  const clientFilePath = path.join(clientFolderPath, fileName);
                  pathsChecked.push(clientFilePath);
                  
                  if (fs.existsSync(clientFilePath)) {
                    // Se il file esiste nella cartella cliente, aggiorna il percorso nel database
                    const relativePath = `/api/uploads/${clientFolderName}/${fileName}`;
                    await storage.updateInvoice(invoice.id, { pdfPath: relativePath });
                    console.log(`Percorso PDF aggiornato per fattura ${invoice.id}: ${relativePath}`);
                    
                    // Segnala che il file esiste ma era nel percorso sbagliato
                    return { 
                      ...invoice, 
                      reason: "PDF trovato in una posizione alternativa e percorso corretto", 
                      paths_checked: pathsChecked,
                      corrected_path: relativePath,
                      amount: Number(invoice.amount)
                    };
                  }
                }
                
                // Prova con la vecchia variante (client_ID)
                const oldClientFolder = `client_${invoice.clientId}`;
                const oldClientFolderPath = path.join(process.cwd(), "uploads", oldClientFolder);
                
                if (fs.existsSync(oldClientFolderPath)) {
                  const fileName = path.basename(filePath);
                  const oldClientFilePath = path.join(oldClientFolderPath, fileName);
                  pathsChecked.push(oldClientFilePath);
                  
                  if (fs.existsSync(oldClientFilePath)) {
                    // Se il file esiste nella vecchia cartella cliente, aggiorna il percorso nel database
                    const relativePath = `/api/uploads/${oldClientFolder}/${fileName}`;
                    await storage.updateInvoice(invoice.id, { pdfPath: relativePath });
                    console.log(`Percorso PDF aggiornato per fattura ${invoice.id} (vecchio formato): ${relativePath}`);
                    
                    return { 
                      ...invoice, 
                      reason: "PDF trovato nella vecchia struttura di cartelle e percorso corretto", 
                      paths_checked: pathsChecked,
                      corrected_path: relativePath,
                      amount: Number(invoice.amount)
                    };
                  }
                }
              } catch (error) {
                console.error(`Errore durante il controllo delle cartelle cliente per fattura ${invoice.id}:`, error);
              }
            }
          }
          
          // Caso 2: Se ci sono allegati, verifica che esistano tutti fisicamente
          if (hasAttachments) {
            const validAttachments = [];
            let allAttachmentsExist = true;
            const attachments = invoice.attachments || [];
            
            for (const attachment of attachments) {
              if (attachment && attachment.path) {
                const attachmentFilePath = path.join(process.cwd(), attachment.path.replace("/api/uploads/", "uploads/"));
                pathsChecked.push(attachmentFilePath);
                
                const attachmentExists = fs.existsSync(attachmentFilePath);
                if (attachmentExists) {
                  validAttachments.push(attachment);
                } else {
                  allAttachmentsExist = false;
                }
              } else {
                allAttachmentsExist = false;
              }
            }
            
            // Se tutti gli allegati esistono fisicamente e non ci sono problemi con pdfPath
            if (allAttachmentsExist && (fileExists || !invoice.pdfPath)) {
              return null; // Tutto a posto, nessun problema
            }
            
            // Se ci sono solo alcuni allegati validi, aggiorna l'invoice per mantenere solo quelli
            if (validAttachments.length > 0 && attachments && validAttachments.length < attachments.length) {
              await storage.updateInvoice(invoice.id, { attachments: validAttachments });
              console.log(`Aggiornati allegati per fattura ${invoice.id}: rimossi ${attachments.length - validAttachments.length} file non trovati`);
              
              // Se ci sono ancora allegati validi ma pdfPath è invalido, consideriamo la fattura a posto
              if (validAttachments.length > 0 && !fileExists && invoice.pdfPath) {
                await storage.updateInvoice(invoice.id, { pdfPath: null }); // Rimuovi il percorso pdfPath obsoleto
                console.log(`Rimosso percorso pdfPath obsoleto per fattura ${invoice.id}`);
                return null; // Fattura risolta
              }
            }
          }
          
          // Se siamo arrivati qui, significa che la fattura ha problemi
          if (!fileExists && invoice.pdfPath && (!hasAttachments || (invoice.attachments && invoice.attachments.length === 0))) {
            return { 
              ...invoice, 
              reason: "I documenti risultano nel database ma non esistono fisicamente", 
              paths_checked: pathsChecked,
              amount: Number(invoice.amount)
            };
          }
          
          // Tutti i controlli sono passati oppure sono stati gestiti sopra
          return null;
        })
      );
      
      // Filtra gli elementi null (fatture con PDF validi)
      const filteredInvoices = missingPdfInvoices.filter(invoice => invoice !== null);
      
      // Aggiunge suggerimenti AI per ogni fattura
      const enhancedInvoices = filteredInvoices.map(invoice => {
        let suggestion = "";
        
        if (invoice.reason === "PDF mancante") {
          suggestion = "Aggiungi un file PDF per questa fattura tramite la funzione di upload";
        } else if (invoice.reason.includes("trovato in")) {
          suggestion = "Il PDF è stato trovato in una posizione alternativa e il percorso è stato corretto automaticamente";
        } else {
          suggestion = "Il file potrebbe essere stato spostato o eliminato. Carica nuovamente il PDF";
        }
        
        return {
          ...invoice,
          suggestion
        };
      });
      
      res.json(enhancedInvoices);
    } catch (error) {
      console.error("Errore nel recupero delle fatture senza PDF:", error);
      res.status(500).json({ message: "Errore nel recupero delle fatture senza PDF", error });
    }
  });

  // API per l'upload di PDF per fatture senza PDF
  app.post("/api/admin/invoices/pdf-upload/:id", isAdmin, upload.single("pdf"), async (req, res) => {
    try {
      const invoiceId = parseInt(req.params.id);
      
      if (isNaN(invoiceId)) {
        return res.status(400).json({ message: "ID fattura non valido" });
      }
      
      const invoice = await storage.getInvoice(invoiceId);
      
      if (!invoice) {
        return res.status(404).json({ message: "Fattura non trovata" });
      }
      
      if (!req.file) {
        return res.status(400).json({ message: "Nessun file PDF caricato" });
      }
      
      try {
        console.log("Aggiungendo PDF a fattura ID:", invoiceId);
        
        // Il file è stato caricato nella cartella temporanea, ora spostalo nella cartella definitiva
        const tempFilePath = req.file.path;
        console.log("File PDF caricato:", tempFilePath);
        
        // Elimina il vecchio PDF se esiste
        if (invoice.pdfPath) {
          const oldPdfPath = path.join(process.cwd(), invoice.pdfPath.replace("/api/uploads/", "uploads/"));
          console.log("Vecchio percorso del PDF:", oldPdfPath);
          
          if (fs.existsSync(oldPdfPath)) {
            fs.unlinkSync(oldPdfPath);
            console.log("Deleted old PDF file:", oldPdfPath);
          }
        }
        
        // Ottieni l'ID del cliente per organizzare il file nella cartella appropriata
        const clientId = invoice.clientId;
        console.log("Organizing PDF for client ID:", clientId);
        
        // Verifica che il file temporaneo esista e non sia vuoto
        if (!fs.existsSync(tempFilePath)) {
          throw new Error(`File temporaneo non trovato: ${tempFilePath}`);
        }
        
        const tempStats = fs.statSync(tempFilePath);
        if (tempStats.size === 0) {
          throw new Error(`File temporaneo vuoto: ${tempFilePath}`);
        }
        
        console.log(`Dimensione file temporaneo: ${tempStats.size} bytes`);
        
        // Sposta il file nella cartella definitiva, senza mantenere l'originale
        const finalPdfPath = await moveFileFromTempToUploads(tempFilePath, false, clientId);
        console.log("Percorso finale PDF:", finalPdfPath);
        
        // Verifica che il file sia stato spostato correttamente
        const absolutePath = path.join(process.cwd(), finalPdfPath.replace("/api/uploads/", "uploads/"));
        
        if (!fs.existsSync(absolutePath)) {
          console.error(`ERRORE CRITICO: File non trovato dopo lo spostamento: ${absolutePath}`);
          throw new Error("File non trovato dopo lo spostamento");
        }
        
        const finalStats = fs.statSync(absolutePath);
        console.log(`Verifica file finale: ${absolutePath}, dimensione: ${finalStats.size} bytes`);
        
        // Aggiorna il percorso del PDF
        const updatedInvoice = await storage.updateInvoice(invoiceId, { pdfPath: finalPdfPath });
        
        if (!updatedInvoice) {
          return res.status(500).json({ message: "Impossibile aggiornare il PDF della fattura" });
        }
        
        return res.json({
          success: true,
          invoice: updatedInvoice,
          message: "PDF caricato con successo"
        });
      } catch (fileError) {
        console.error("Errore durante l'upload del PDF:", fileError);
        return res.status(500).json({ message: "Errore durante l'upload del PDF", error: String(fileError) });
      }
    } catch (error) {
      console.error("Errore:", error);
      res.status(500).json({ 
        message: "Errore durante l'operazione", 
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Get specific invoice with items
  app.get("/api/admin/invoices/:id", isAdmin, async (req, res) => {
    try {
      const invoiceId = parseInt(req.params.id);
      
      if (isNaN(invoiceId)) {
        return res.status(400).json({ message: "Invalid invoice ID" });
      }
      
      const invoice = await storage.getInvoiceWithItems(invoiceId);
      
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      
      const client = await storage.getClient(invoice.clientId);
      
      res.json({
        ...invoice,
        client
      });
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  // Create new invoice
  app.post("/api/admin/invoices", isAdmin, upload.single("pdf"), async (req, res) => {
    try {
      // Check if req.body.data exists
      if (!req.body.data) {
        return res.status(400).json({ message: "Missing invoice data" });
      }
      
      let invoiceData;
      try {
        invoiceData = JSON.parse(req.body.data);
      } catch (jsonError) {
        console.error("JSON parse error:", jsonError);
        return res.status(400).json({ message: "Invalid JSON data format" });
      }
      
      console.log("Invoice data received:", invoiceData);
      
      // Gestisci il file PDF (temporaneo -> definitivo)
      if (req.file) {
        try {
          // Il file è stato caricato nella cartella temporanea, ora spostalo nella cartella definitiva
          const tempFilePath = req.file.path;
          console.log("Temporary file path:", tempFilePath);
          
          // Ottieni l'ID del cliente per organizzare il file nella cartella appropriata
          const clientId = invoiceData.clientId ? parseInt(invoiceData.clientId) : undefined;
          console.log("Organizing PDF for client ID:", clientId);
          
          if (!clientId) {
            console.warn("ATTENZIONE: ID cliente non disponibile, impossibile organizzare il PDF in una cartella specifica");
          }
          
          // Verifica che il file temporaneo esista e non sia vuoto
          if (!fs.existsSync(tempFilePath)) {
            throw new Error(`File temporaneo non trovato: ${tempFilePath}`);
          }
          
          const tempStats = fs.statSync(tempFilePath);
          if (tempStats.size === 0) {
            throw new Error(`File temporaneo vuoto: ${tempFilePath}`);
          }
          
          console.log(`Dimensione file temporaneo: ${tempStats.size} bytes`);
          
          // Sposta il file nella cartella definitiva, senza mantenere l'originale
          const finalPdfPath = await moveFileFromTempToUploads(tempFilePath, false, clientId);
          console.log("Final PDF path:", finalPdfPath);
          
          // Verifica che il file sia stato effettivamente spostato
          // Ottieni il percorso assoluto del file appena spostato
          const absolutePath = path.join(process.cwd(), finalPdfPath.replace("/api/uploads/", "uploads/"));
          
          if (!fs.existsSync(absolutePath)) {
            console.error(`ERRORE CRITICO: Il file ${absolutePath} non è stato trovato dopo lo spostamento`);
            throw new Error(`File non trovato dopo lo spostamento: ${absolutePath}`);
          } else {
            console.log(`Verifica file esistente dopo spostamento: OK - ${absolutePath}`);
          }
          
          // Aggiorna il percorso del PDF nei dati della fattura
          invoiceData.pdfPath = finalPdfPath;
        } catch (fileError) {
          console.error("Error moving file from temp directory:", fileError);
          
          // Verifica se il file temporaneo esiste ancora
          if (fs.existsSync(req.file.path)) {
            // Se fallisce lo spostamento ma il file temporaneo esiste ancora, creiamo una copia diretta in uploads
            try {
              const sanitizedFileName = `emergency_${Date.now()}_${path.basename(req.file.path)}`;
              const emergencyPath = path.join(UPLOAD_DIR, sanitizedFileName);
              
              console.log(`Tentativo di recupero emergenza: copio da ${req.file.path} a ${emergencyPath}`);
              fs.copyFileSync(req.file.path, emergencyPath);
              
              // Usa il percorso di emergenza
              invoiceData.pdfPath = `/api/uploads/${sanitizedFileName}`;
              console.log(`Percorso PDF di emergenza impostato: ${invoiceData.pdfPath}`);
            } catch (emergencyError) {
              console.error("Anche il recupero di emergenza è fallito:", emergencyError);
              // In caso di errore persistente, lascia il campo pdfPath a null
              invoiceData.pdfPath = null;
            }
          } else {
            console.error("Il file temporaneo non esiste più:", req.file.path);
            invoiceData.pdfPath = null;
          }
        }
      }
      
      // Validate required fields before processing
      if (!invoiceData.number || !invoiceData.clientId || !invoiceData.issueDate || !invoiceData.dueDate || !invoiceData.amount) {
        return res.status(400).json({ 
          message: "Invalid invoice data", 
          details: "Missing required fields. Required: number, clientId, issueDate, dueDate, amount" 
        });
      }
      
      // Ensure dates are properly formatted
      try {
        // Converti le date in oggetti Date se sono stringhe
        if (typeof invoiceData.issueDate === 'string') {
          invoiceData.issueDate = new Date(invoiceData.issueDate);
        }
        if (typeof invoiceData.dueDate === 'string') {
          invoiceData.dueDate = new Date(invoiceData.dueDate);
        }
        if (typeof invoiceData.paymentDate === 'string' && invoiceData.paymentDate) {
          invoiceData.paymentDate = new Date(invoiceData.paymentDate);
        }
        
        // Converti amount in numero se è una stringa
        if (typeof invoiceData.amount === 'string') {
          invoiceData.amount = parseFloat(invoiceData.amount);
        }
      } catch (dateError) {
        console.error("Errore nella conversione delle date:", dateError);
        return res.status(400).json({ 
          message: "Invalid date format", 
          details: "Make sure dates are in a valid format (YYYY-MM-DD)"
        });
      }
      
      try {
        console.log("Prima della validazione:", JSON.stringify(invoiceData, null, 2));
        
        // Gestione della data di pagamento (può essere null)
        if (invoiceData.paymentDate === null || invoiceData.paymentDate === '') {
          console.log("Data di pagamento impostata a null durante la creazione");
          invoiceData.paymentDate = null;
        } else if (typeof invoiceData.paymentDate === 'string' && invoiceData.paymentDate) {
          console.log("Conversione data di pagamento:", invoiceData.paymentDate);
          invoiceData.paymentDate = new Date(invoiceData.paymentDate);
        }
        
        // Aggiorna automaticamente lo stato a "paid" se c'è una data di pagamento
        if (invoiceData.paymentDate && invoiceData.status === "pending") {
          console.log("Aggiornamento automatico dello stato a 'paid' durante la creazione");
          invoiceData.status = "paid";
        }
        
        // Rimuove la data di pagamento se lo stato non è "paid"
        if (invoiceData.status !== "paid" && invoiceData.paymentDate) {
          console.log("Rimozione data di pagamento durante la creazione");
          invoiceData.paymentDate = null;
        }
        
        // Aggiungiamo ulteriori log dettagliati
        console.log("TIPI DATA: issueDate:", typeof invoiceData.issueDate, "dueDate:", typeof invoiceData.dueDate);
        console.log("TIPO amount:", typeof invoiceData.amount);
        
        // Validazione finale attraverso Zod
        const validatedData = insertInvoiceSchema.parse(invoiceData);
        console.log("Dati validati con successo:", JSON.stringify(validatedData, null, 2));
        
        // Creazione fattura
        const invoice = await storage.createInvoice(validatedData);
        console.log("Fattura creata con ID:", invoice.id);
        
        // Create invoice items if provided
        if (invoiceData.items && Array.isArray(invoiceData.items)) {
          console.log(`Elaborazione di ${invoiceData.items.length} voci fattura`);
          let itemsProcessed = 0;
          
          for (const item of invoiceData.items) {
            try {
              const itemData = {
                ...item,
                invoiceId: invoice.id
              };
              
              // Assicuriamoci che quantity e price siano numeri
              if (typeof itemData.quantity === 'string') {
                itemData.quantity = parseFloat(itemData.quantity.replace(',', '.'));
              }
              if (typeof itemData.price === 'string') {
                itemData.price = parseFloat(itemData.price.replace(',', '.'));
              }
              if (typeof itemData.total === 'string') {
                itemData.total = parseFloat(itemData.total.replace(',', '.'));
              }
              
              // Se total non è presente, lo calcoliamo
              if (!itemData.total && itemData.quantity && itemData.price) {
                itemData.total = itemData.quantity * itemData.price;
              }
              
              await storage.createInvoiceItem(insertInvoiceItemSchema.parse(itemData));
              itemsProcessed++;
            } catch (itemError) {
              console.error("Errore durante il salvataggio dell'elemento fattura:", itemError);
              // Non interrompiamo l'esecuzione, continuiamo con gli altri elementi
            }
          }
          console.log(`Elaborati ${itemsProcessed}/${invoiceData.items.length} elementi`);
        }
        
        // Recupero della fattura completa con elementi
        const fullInvoice = await storage.getInvoiceWithItems(invoice.id);
        return res.status(201).json(fullInvoice);
      } catch (validationError) {
        if (validationError instanceof z.ZodError) {
          console.error("Validation error:", validationError.errors);
          return res.status(400).json({ 
            message: "Invalid invoice data", 
            errors: validationError.errors,
            receivedData: invoiceData
          });
        }
        throw validationError;
      }
    } catch (error) {
      console.error("Error creating invoice:", error);
      res.status(500).json({ 
        message: "Impossibile creare la fattura", 
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Configurazione per upload multipli
  const uploadMultiple = multer({
    storage: multer.diskStorage({
      destination: function (req, file, cb) {
        cb(null, TEMP_DIR);
      },
      filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
        let sanitizedName = file.originalname.replace(/\s+/g, '_');
        if (!sanitizedName.toLowerCase().endsWith('.pdf')) {
          sanitizedName += '.pdf';
        }
        const finalName = uniqueSuffix + "-" + sanitizedName;
        console.log("File multi caricato con nome:", finalName);
        cb(null, finalName);
      }
    }),
    limits: {
      fileSize: 10 * 1024 * 1024, // 10MB
      files: 10 // massimo 10 file
    }
  });

  // API per gestire gli allegati di una fattura
  app.post("/api/admin/invoices/:id/attachments", isAdmin, uploadMultiple.array("pdfs", 10), async (req, res) => {
    try {
      const invoiceId = parseInt(req.params.id);
      if (isNaN(invoiceId)) {
        return res.status(400).json({ message: "ID fattura non valido" });
      }
      
      // Ottieni la fattura corrente
      const invoice = await storage.getInvoice(invoiceId);
      if (!invoice) {
        return res.status(404).json({ message: "Fattura non trovata" });
      }
      
      console.log(`Aggiunta allegati per fattura ${invoiceId}`);
      const files = req.files as Express.Multer.File[];
      
      if (!files || files.length === 0) {
        return res.status(400).json({ message: "Nessun file caricato" });
      }
      
      // Prepara l'array di allegati esistenti
      const currentAttachments = invoice.attachments || [];
      const newAttachments = [];
      
      // Processa ogni file
      for (const file of files) {
        try {
          const tempFilePath = file.path;
          console.log(`Processando allegato ${file.originalname} dal percorso temporaneo ${tempFilePath}`);
          
          // Verifica che il file temporaneo esista
          if (!fs.existsSync(tempFilePath)) {
            console.error(`File temporaneo non esiste: ${tempFilePath}`);
            continue;
          }
          
          // Ottieni dimensione del file per controllo
          const tempStats = fs.statSync(tempFilePath);
          console.log(`File temporaneo: ${tempFilePath}, dimensione: ${tempStats.size} bytes`);
          
          if (tempStats.size === 0) {
            console.error(`File vuoto ignorato: ${tempFilePath}`);
            continue;
          }
          
          // Sposta il file nella cartella definitiva - sempre mantieni i file temporanei
          const finalPdfPath = await moveFileFromTempToUploads(tempFilePath, true, invoice.clientId);
          
          // Verifica che il file sia stato effettivamente spostato
          const absolutePath = path.join(process.cwd(), finalPdfPath.replace("/api/uploads/", "uploads/"));
          
          // Crea copie di backup in posizioni diverse
          const backupFolders = [
            path.join(process.cwd(), "uploads", "backup"),
            path.join(process.cwd(), "attached_assets", "pdf_backup")
          ];
          
          // Assicurati che le cartelle di backup esistano
          for (const folder of backupFolders) {
            try {
              if (!fs.existsSync(folder)) {
                fs.mkdirSync(folder, { recursive: true });
                console.log(`Cartella di backup creata: ${folder}`);
              }
              
              // Crea una copia del file nella cartella di backup
              const backupPath = path.join(folder, path.basename(finalPdfPath));
              fs.copyFileSync(absolutePath, backupPath);
              console.log(`Backup creato in: ${backupPath}`);
            } catch (err) {
              console.error(`Errore nel creare backup in ${folder}:`, err);
            }
          }
          
          if (!fs.existsSync(absolutePath)) {
            console.error(`ERRORE: Il file ${absolutePath} non è stato trovato dopo lo spostamento`);
            
            // Tenta di recuperare dai backup
            let recovered = false;
            for (const folder of backupFolders) {
              const backupPath = path.join(folder, path.basename(finalPdfPath));
              if (fs.existsSync(backupPath)) {
                try {
                  fs.copyFileSync(backupPath, absolutePath);
                  console.log(`File recuperato dal backup: ${backupPath}`);
                  recovered = true;
                  break;
                } catch (recErr) {
                  console.error(`Errore nel recupero dal backup ${backupPath}:`, recErr);
                }
              }
            }
            
            if (!recovered) {
              continue;
            }
          }
          
          // Aggiungi il nuovo allegato alla lista
          newAttachments.push({
            path: finalPdfPath,
            name: file.originalname
          });
          
          console.log(`Allegato aggiunto con successo: ${finalPdfPath}`);
        } catch (fileError) {
          console.error(`Errore nel processare il file ${file.originalname}:`, fileError);
        }
      }
      
      // Aggiorna la fattura con i nuovi allegati
      const updatedAttachments = [...currentAttachments, ...newAttachments];
      
      // Aggiorna il campo allegati nella fattura
      const updatedInvoice = await storage.updateInvoice(invoiceId, {
        attachments: updatedAttachments
      });
      
      if (!updatedInvoice) {
        return res.status(500).json({ message: "Impossibile aggiornare gli allegati della fattura" });
      }
      
      res.status(200).json({
        message: `${newAttachments.length} allegati aggiunti con successo`,
        attachments: updatedAttachments
      });
    } catch (error) {
      console.error("Errore nell'aggiunta di allegati:", error);
      res.status(500).json({ 
        message: "Errore nell'aggiornamento degli allegati", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // API per rimuovere un allegato
  app.delete("/api/admin/invoices/:id/attachments/:index", isAdmin, async (req, res) => {
    try {
      const invoiceId = parseInt(req.params.id);
      const attachmentIndex = parseInt(req.params.index);
      
      if (isNaN(invoiceId) || isNaN(attachmentIndex)) {
        return res.status(400).json({ message: "Parametri non validi" });
      }
      
      // Ottieni la fattura corrente
      const invoice = await storage.getInvoice(invoiceId);
      if (!invoice) {
        return res.status(404).json({ message: "Fattura non trovata" });
      }
      
      // Verifica che l'allegato esista
      const attachments = invoice.attachments || [];
      if (attachmentIndex < 0 || attachmentIndex >= attachments.length) {
        return res.status(404).json({ message: "Allegato non trovato" });
      }
      
      // Ottieni il percorso dell'allegato da rimuovere
      const attachmentToRemove = attachments[attachmentIndex];
      console.log(`Rimozione allegato ${attachmentToRemove.name} dalla fattura ${invoiceId}`);
      
      // Rimuovi fisicamente il file, se esiste
      if (attachmentToRemove.path) {
        const filePath = path.join(process.cwd(), attachmentToRemove.path.replace("/api/uploads/", "uploads/"));
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
          console.log(`File eliminato: ${filePath}`);
        } else {
          console.log(`File non trovato sul disco: ${filePath}`);
        }
      }
      
      // Rimuovi l'allegato dall'array
      const updatedAttachments = [...attachments];
      updatedAttachments.splice(attachmentIndex, 1);
      
      // Aggiorna la fattura
      const updatedInvoice = await storage.updateInvoice(invoiceId, {
        attachments: updatedAttachments
      });
      
      if (!updatedInvoice) {
        return res.status(500).json({ message: "Impossibile aggiornare gli allegati della fattura" });
      }
      
      res.status(200).json({
        message: "Allegato rimosso con successo",
        attachments: updatedAttachments
      });
    } catch (error) {
      console.error("Errore nella rimozione dell'allegato:", error);
      res.status(500).json({ 
        message: "Errore nella rimozione dell'allegato", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Update invoice field (PATCH)
  app.patch("/api/admin/invoices/:id", isAdmin, upload.single("pdf"), async (req, res) => {
    try {
      const invoiceId = parseInt(req.params.id);
      
      if (isNaN(invoiceId)) {
        return res.status(400).json({ message: "Invalid invoice ID" });
      }
      
      const invoice = await storage.getInvoice(invoiceId);
      
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      
      // Se abbiamo un PDF caricato, gestiscilo separatamente
      if (req.file) {
        try {
          console.log("Aggiornamento PDF per fattura ID:", invoiceId);
          
          // Il file è stato caricato nella cartella temporanea, ora spostalo nella cartella definitiva
          const tempFilePath = req.file.path;
          console.log("Aggiornamento fattura con nuovo PDF:", tempFilePath);
          
          // Elimina il vecchio PDF se esiste
          if (invoice.pdfPath) {
            const oldPdfPath = path.join(process.cwd(), invoice.pdfPath.replace("/api/uploads/", "uploads/"));
            console.log("Vecchio percorso del PDF:", oldPdfPath);
            
            if (fs.existsSync(oldPdfPath)) {
              fs.unlinkSync(oldPdfPath);
              console.log("Deleted old PDF file:", oldPdfPath);
            } else {
              console.log("Il file PDF precedente non esiste più sul disco:", oldPdfPath);
            }
          }
          
          // Ottieni l'ID del cliente per organizzare il file nella cartella appropriata
          const clientId = invoice.clientId;
          console.log("Organizing updated PDF for client ID:", clientId);
          
          if (!clientId) {
            console.warn("ATTENZIONE: ID cliente non disponibile, impossibile organizzare il PDF in una cartella specifica");
          }
          
          // Sposta il file nella cartella definitiva mantenendo l'originale per l'anteprima
          const finalPdfPath = await moveFileFromTempToUploads(tempFilePath, false, clientId);
          console.log("Nuovo percorso PDF:", finalPdfPath);
          
          // Verifica che il file sia stato effettivamente spostato
          const absolutePath = path.join(process.cwd(), finalPdfPath.replace("/api/uploads/", "uploads/"));
          
          if (!fs.existsSync(absolutePath)) {
            console.error(`ERRORE CRITICO: Il file ${absolutePath} non è stato trovato dopo lo spostamento`);
            throw new Error(`File non trovato dopo lo spostamento: ${absolutePath}`);
          } else {
            console.log(`Verifica file esistente dopo spostamento: OK - ${absolutePath}`);
          }
          
          // Aggiorna il percorso del PDF
          const updatedInvoice = await storage.updateInvoice(invoiceId, { pdfPath: finalPdfPath });
          
          if (!updatedInvoice) {
            return res.status(500).json({ message: "Failed to update invoice PDF" });
          }
          
          return res.json(updatedInvoice);
        } catch (fileError) {
          console.error("Errore durante l'aggiornamento del file PDF:", fileError);
          
          // Verifica se il file temporaneo esiste ancora
          if (fs.existsSync(req.file.path)) {
            // Se fallisce lo spostamento ma il file temporaneo esiste ancora, creiamo una copia diretta in uploads
            try {
              const sanitizedFileName = `emergency_${Date.now()}_${path.basename(req.file.path)}`;
              const emergencyPath = path.join(UPLOAD_DIR, sanitizedFileName);
              
              console.log(`Tentativo di recupero emergenza: copio da ${req.file.path} a ${emergencyPath}`);
              fs.copyFileSync(req.file.path, emergencyPath);
              
              // Usa il percorso di emergenza
              const emergencyPdfPath = `/api/uploads/${sanitizedFileName}`;
              console.log(`Percorso PDF di emergenza impostato: ${emergencyPdfPath}`);
              
              // Aggiorna il percorso del PDF con quello di emergenza
              const emergencyUpdatedInvoice = await storage.updateInvoice(invoiceId, { pdfPath: emergencyPdfPath });
              
              if (emergencyUpdatedInvoice) {
                console.log("File di emergenza salvato con successo");
                return res.json(emergencyUpdatedInvoice);
              }
            } catch (emergencyError) {
              console.error("Anche il recupero di emergenza è fallito:", emergencyError);
            }
          } else {
            console.error("Il file temporaneo non esiste più:", req.file.path);
          }
          
          return res.status(500).json({ message: "Failed to update PDF file", error: String(fileError) });
        }
      } else {
        // Gestione normale dei campi (per campi singoli)
        // Recupera campo e valore
        const { field, value } = req.body;
        console.log(`Aggiornamento campo "${field}" a "${value}" per fattura ID: ${invoiceId}`);
        
        // Crea un oggetto con solo il campo da aggiornare
        let updateData: any = { [field]: value };
        
        // IMPORTANTE: Mantieni sempre il percorso del PDF esistente per evitare di perderlo durante l'aggiornamento
        if (invoice.pdfPath) {
          console.log(`Preservando percorso PDF esistente: ${invoice.pdfPath}`);
          updateData.pdfPath = invoice.pdfPath;
        }
        
        // Gestione speciale delle date
        if (field === 'issueDate' || field === 'dueDate') {
          if (value) {
            updateData[field] = new Date(value);
          }
        }
        
        // Gestione speciale della data di pagamento
        if (field === 'paymentDate') {
          if (value === null || value === '') {
            console.log("Data di pagamento rimossa");
            updateData.paymentDate = null;
          } else if (value) {
            console.log("Impostazione data di pagamento:", value);
            updateData.paymentDate = new Date(value);
            
            // Imposta automaticamente lo stato a "paid" se non è già così
            if (invoice.status === "pending") {
              console.log("Aggiornamento automatico dello stato a 'paid'");
              updateData.status = "paid";
            }
          }
        }
        
        // Gestione speciale dello stato
        if (field === 'status') {
          // Se lo stato non è "paid", rimuovi la data di pagamento
          if (value !== "paid" && invoice.paymentDate) {
            console.log("Rimozione data di pagamento perché lo stato non è 'paid'");
            updateData.paymentDate = null;
          }
        }
      
      console.log("Dati da aggiornare:", updateData);
      const validatedData = insertInvoiceSchema.partial().parse(updateData);
      const updatedInvoice = await storage.updateInvoice(invoiceId, validatedData);
      
      if (!updatedInvoice) {
        return res.status(500).json({ message: "Failed to update invoice" });
      }
      
      res.json(updatedInvoice);
      }  // chiusura dell'else aggiunto
    } catch (error) {
      console.error("Error updating invoice field:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error: String(error) });
    }
  });
  
  // Update complete invoice
  app.put("/api/admin/invoices/:id", isAdmin, upload.single("pdf"), async (req, res) => {
    try {
      const invoiceId = parseInt(req.params.id);
      
      if (isNaN(invoiceId)) {
        return res.status(400).json({ message: "Invalid invoice ID" });
      }
      
      const invoice = await storage.getInvoice(invoiceId);
      
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      
      let invoiceData = JSON.parse(req.body.data);
      
      // Gestisci il file PDF (temporaneo -> definitivo)
      if (req.file) {
        try {
          // Il file è stato caricato nella cartella temporanea, ora spostalo nella cartella definitiva
          const tempFilePath = req.file.path;
          console.log("Aggiornamento fattura con nuovo PDF:", tempFilePath);
          
          // Elimina il vecchio PDF se esiste
          if (invoice.pdfPath) {
            const oldPdfPath = path.join(process.cwd(), invoice.pdfPath.replace("/api/uploads/", "uploads/"));
            console.log("Vecchio percorso del PDF:", oldPdfPath);
            
            if (fs.existsSync(oldPdfPath)) {
              fs.unlinkSync(oldPdfPath);
              console.log("Deleted old PDF file:", oldPdfPath);
            } else {
              console.log("Il file PDF precedente non esiste più sul disco:", oldPdfPath);
            }
          }
          
          // Ottieni l'ID del cliente per organizzare il file nella cartella appropriata
          const clientId = invoice.clientId;
          console.log("Organizing updated PDF for client ID:", clientId);
          
          if (!clientId) {
            console.warn("ATTENZIONE: ID cliente non disponibile, impossibile organizzare il PDF in una cartella specifica");
          }
          
          // Sposta il file nella cartella definitiva mantenendo l'originale per l'anteprima
          const finalPdfPath = await moveFileFromTempToUploads(tempFilePath, false, clientId);
          console.log("Nuovo percorso PDF:", finalPdfPath);
          
          // Verifica che il file sia stato effettivamente spostato
          const absolutePath = path.join(process.cwd(), finalPdfPath.replace("/api/uploads/", "uploads/"));
          
          if (!fs.existsSync(absolutePath)) {
            console.error(`ERRORE CRITICO: Il file ${absolutePath} non è stato trovato dopo lo spostamento`);
            throw new Error(`File non trovato dopo lo spostamento: ${absolutePath}`);
          } else {
            console.log(`Verifica file esistente dopo spostamento: OK - ${absolutePath}`);
          }
          
          // Aggiorna il percorso del PDF nei dati della fattura
          invoiceData.pdfPath = finalPdfPath;
        } catch (fileError) {
          console.error("Errore durante l'aggiornamento del file PDF:", fileError);
          
          // Verifica se il file temporaneo esiste ancora
          if (fs.existsSync(req.file.path)) {
            // Se fallisce lo spostamento ma il file temporaneo esiste ancora, creiamo una copia diretta in uploads
            try {
              const sanitizedFileName = `emergency_${Date.now()}_${path.basename(req.file.path)}`;
              const emergencyPath = path.join(UPLOAD_DIR, sanitizedFileName);
              
              console.log(`Tentativo di recupero emergenza: copio da ${req.file.path} a ${emergencyPath}`);
              fs.copyFileSync(req.file.path, emergencyPath);
              
              // Usa il percorso di emergenza
              invoiceData.pdfPath = `/api/uploads/${sanitizedFileName}`;
              console.log(`Percorso PDF di emergenza impostato: ${invoiceData.pdfPath}`);
            } catch (emergencyError) {
              console.error("Anche il recupero di emergenza è fallito:", emergencyError);
              // Mantieni il vecchio percorso se esiste
              invoiceData.pdfPath = invoice.pdfPath || null;
            }
          } else {
            console.error("Il file temporaneo non esiste più:", req.file.path);
            // Mantieni il vecchio percorso se esiste
            invoiceData.pdfPath = invoice.pdfPath || null;
          }
        }
      } else {
        console.log("Nessun nuovo PDF fornito, mantengo il PDF esistente");
        // Assicuriamoci che il percorso PDF sia mantenuto anche se non è presente nei dati inviati
        if (invoice.pdfPath && !invoiceData.pdfPath) {
          console.log(`Preservando percorso PDF esistente nell'aggiornamento completo: ${invoice.pdfPath}`);
          invoiceData.pdfPath = invoice.pdfPath;
        }
      }
      
      // Converti le date in formato ISO prima della validazione
      if (typeof invoiceData.issueDate === 'string') {
        invoiceData.issueDate = new Date(invoiceData.issueDate);
      }
      if (typeof invoiceData.dueDate === 'string') {
        invoiceData.dueDate = new Date(invoiceData.dueDate);
      }
      
      // Gestione della data di pagamento (può essere null)
      if (invoiceData.paymentDate === null || invoiceData.paymentDate === '') {
        console.log("Data di pagamento impostata a null");
        invoiceData.paymentDate = null;
      } else if (typeof invoiceData.paymentDate === 'string' && invoiceData.paymentDate) {
        console.log("Conversione data di pagamento:", invoiceData.paymentDate);
        invoiceData.paymentDate = new Date(invoiceData.paymentDate);
      }
      
      // Aggiorna automaticamente lo stato a "paid" se c'è una data di pagamento
      if (invoiceData.paymentDate && invoiceData.status === "pending") {
        console.log("Aggiornamento automatico dello stato a 'paid' perché è presente una data di pagamento");
        invoiceData.status = "paid";
      }
      
      // Rimuove la data di pagamento se lo stato non è "paid"
      if (invoiceData.status !== "paid" && invoiceData.paymentDate) {
        console.log("Rimozione data di pagamento perché lo stato non è 'paid'");
        invoiceData.paymentDate = null;
      }
      
      console.log("Dati validati prima dell'aggiornamento:", JSON.stringify(invoiceData, null, 2));
      const validatedData = insertInvoiceSchema.partial().parse(invoiceData);
      console.log("Dati validati con successo:", JSON.stringify(validatedData, null, 2));
      const updatedInvoice = await storage.updateInvoice(invoiceId, validatedData);
      
      if (!updatedInvoice) {
        return res.status(500).json({ message: "Failed to update invoice" });
      }
      
      console.log("Fattura aggiornata con successo:", updatedInvoice.id);
      
      // Update invoice items if provided
      if (invoiceData.items && Array.isArray(invoiceData.items)) {
        // Get existing items
        const existingItems = await storage.getInvoiceItems(invoiceId);
        
        // Delete items that are not in the new list
        for (const existingItem of existingItems) {
          const itemStillExists = invoiceData.items.some((item: any) => 
            item.id && item.id === existingItem.id
          );
          
          if (!itemStillExists) {
            await storage.deleteInvoiceItem(existingItem.id);
          }
        }
        
        // Update or create items
        for (const item of invoiceData.items) {
          if (item.id) {
            // Update existing item
            await storage.updateInvoiceItem(item.id, {
              ...item,
              invoiceId
            });
          } else {
            // Create new item
            await storage.createInvoiceItem(insertInvoiceItemSchema.parse({
              ...item,
              invoiceId
            }));
          }
        }
      }
      
      const fullInvoice = await storage.getInvoiceWithItems(invoiceId);
      res.json(fullInvoice);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid invoice data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error });
    }
  });

  // Delete invoice
  app.delete("/api/admin/invoices/:id", isAdmin, async (req, res) => {
    try {
      const invoiceId = parseInt(req.params.id);
      
      if (isNaN(invoiceId)) {
        return res.status(400).json({ message: "Invalid invoice ID" });
      }
      
      const invoice = await storage.getInvoice(invoiceId);
      
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      
      // Delete PDF file if it exists
      if (invoice.pdfPath) {
        const pdfPath = path.join(process.cwd(), invoice.pdfPath.replace("/api/uploads/", "uploads/"));
        if (fs.existsSync(pdfPath)) {
          fs.unlinkSync(pdfPath);
        }
      }
      
      // Delete all associated invoice items
      const items = await storage.getInvoiceItems(invoiceId);
      for (const item of items) {
        await storage.deleteInvoiceItem(item.id);
      }
      
      const deleted = await storage.deleteInvoice(invoiceId);
      
      if (!deleted) {
        return res.status(500).json({ message: "Failed to delete invoice" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });
  
  // Extract data from a PDF invoice
  app.post("/api/admin/invoices/extract", isAdmin, upload.single("pdf"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      // Il file è stato caricato nella cartella temporanea
      const tempFilePath = req.file.path;
      console.log("Processing PDF file (temp):", tempFilePath);
      
      // Sanitizza il nome del file per evitare problemi con gli spazi
      const originalFileName = path.basename(tempFilePath);
      const sanitizedFileName = originalFileName.replace(/\s+/g, '_');
      let filePathForProcessing = tempFilePath;
      
      // Se il nome del file è stato modificato, rinomina il file fisico
      if (sanitizedFileName !== originalFileName) {
        const sanitizedFilePath = path.join(path.dirname(tempFilePath), sanitizedFileName);
        console.log(`Rinomino file da ${tempFilePath} a ${sanitizedFilePath}`);
        fs.renameSync(tempFilePath, sanitizedFilePath);
        filePathForProcessing = sanitizedFilePath;
      }
      
      // Import the PDF extractor functions, OpenAI functions, and client matcher
      const { extractTextFromPdf, extractInvoiceDataFromText } = await import("./utils/pdf-extractor.js");
      const { analyzePdfText, analyzePdfAsImage } = await import("./openai.js");
      const { matchOrSuggestClient } = await import("./utils/client-matcher.js");
      
      // Extract text from PDF using the sanitized path
      let pdfText = "";
      try {
        pdfText = await extractTextFromPdf(filePathForProcessing);
        console.log("PDF text extracted, length:", pdfText.length);
      } catch (textExtractionError) {
        console.error("Error extracting text from PDF:", textExtractionError);
        pdfText = ""; // Se l'estrazione fallisce, utilizziamo una stringa vuota
      }
      
      // Extract structured data from text
      let invoiceData = {};
      if (pdfText && pdfText.length > 0) {
        invoiceData = extractInvoiceDataFromText(pdfText);
        console.log("Extracted invoice data:", invoiceData);
      }
      
      // Determina il metodo di estrazione più appropriato
      let aiExtractedData: {
        invoiceNumber?: string;
        issueDate?: string;
        total?: string;
        client?: string;
        dueDate?: string;
        paymentMethod?: string;
      } = {};
      
      if (!pdfText || pdfText.length < 50) {
        // Se il testo è insufficiente o assente, usa l'analisi basata su immagine
        console.log("PDF text is too short or empty, using image-based analysis");
        try {
          // Passiamo direttamente il percorso locale del file, non il percorso API
          console.log("Analyzing PDF image with local path:", tempFilePath);
          aiExtractedData = await analyzePdfAsImage(tempFilePath);
          console.log("Image-based AI extraction results:", aiExtractedData);
        } catch (imageAnalysisError) {
          console.error("Error in image-based analysis:", imageAnalysisError);
          // Se fallisce l'analisi basata su immagine, continuiamo con quanto già abbiamo
        }
      } else if (typeof invoiceData === 'object' && invoiceData) {
        // Verifica se ha le proprietà necessarie
        const hasInvoiceNumber = 'invoiceNumber' in invoiceData && invoiceData.invoiceNumber;
        const hasIssueDate = 'issueDate' in invoiceData && invoiceData.issueDate;
        const hasTotalAmount = 'totalAmount' in invoiceData && invoiceData.totalAmount;
        
        if (!hasInvoiceNumber && !hasIssueDate && !hasTotalAmount) {
          // Se l'estrazione regex non ha prodotto risultati utili, usa l'analisi basata su testo
          try {
            console.log("Using text-based OpenAI analysis");
            aiExtractedData = await analyzePdfText(pdfText);
            console.log("Text-based AI extraction results:", aiExtractedData);
          } catch (textAnalysisError) {
            console.error("Error in text-based analysis:", textAnalysisError);
            // Se fallisce l'analisi basata su testo, continuiamo con quanto già abbiamo
          }
        }
      }
      
      // Gestione del nuovo formato di output (total invece di totalAmount)
      // con normalizzazione avanzata degli importi
      let aiTotalAmount: number | undefined = undefined;
      
      if (aiExtractedData.total) {
        const amount = aiExtractedData.total.trim();
        let normalizedAmount: string;
        
        // Determina quale formato numerico è stato usato
        if (amount.includes(',') && amount.includes('.')) {
          const lastCommaIndex = amount.lastIndexOf(',');
          const lastDotIndex = amount.lastIndexOf('.');
          
          if (lastCommaIndex > lastDotIndex) {
            // Formato italiano: 1.234,56 (virgola per decimali)
            normalizedAmount = amount.replace(/\./g, '').replace(',', '.');
          } else {
            // Formato inglese: 1,234.56 (punto per decimali)
            normalizedAmount = amount.replace(/,/g, '');
          }
        } else if (amount.includes(',')) {
          // Solo virgole (es. 1234,56) - assumiamo formato italiano
          normalizedAmount = amount.replace(',', '.');
        } else {
          // Solo punti o nessun separatore (es. 1234.56 o 1234)
          normalizedAmount = amount;
        }
        
        const parsedAmount = parseFloat(normalizedAmount);
        if (!isNaN(parsedAmount)) {
          aiTotalAmount = parsedAmount;
          console.log(`OpenAI totale: ${amount} -> normalizzato: ${normalizedAmount} -> valore: ${parsedAmount}`);
        }
      }
      
      const processedAIData = {
        invoiceNumber: aiExtractedData.invoiceNumber,
        issueDate: aiExtractedData.issueDate,
        totalAmount: aiTotalAmount,
        client: aiExtractedData.client,
        dueDate: aiExtractedData.dueDate,
        paymentMethod: aiExtractedData.paymentMethod
      };
      
      // Merge data prioritizing AI extracted data over regex extracted data
      const mergedData: {
        invoiceNumber?: string;
        issueDate?: string;
        totalAmount?: number;
        client?: string;
        dueDate?: string;
        paymentMethod?: string;
        [key: string]: any;
      } = {
        ...invoiceData, // Prima i dati estratti con regex
        ...processedAIData // Poi i dati AI che sovrascrivono quelli regex se presenti
      };
      
      // Determina il metodo di estrazione utilizzato
      let extractionMethod = "regex";
      if (!pdfText || pdfText.length < 50) {
        extractionMethod = "image-based-ai";
      } else if (typeof invoiceData === 'object' && invoiceData) {
        // Verifica se ha le proprietà necessarie
        const hasInvoiceNumber = 'invoiceNumber' in invoiceData && invoiceData.invoiceNumber;
        const hasIssueDate = 'issueDate' in invoiceData && invoiceData.issueDate;
        const hasTotalAmount = 'totalAmount' in invoiceData && invoiceData.totalAmount;
        
        if (Object.keys(invoiceData).length === 0 || (!hasInvoiceNumber && !hasIssueDate && !hasTotalAmount)) {
          extractionMethod = "text-based-ai";
        }
      }
      
      if (Object.keys(processedAIData).some(key => !!processedAIData[key as keyof typeof processedAIData])) {
        extractionMethod = "hybrid";
      }
      
      // Trova una corrispondenza per il cliente se è stato estratto un nome
      let clientMatch = null;
      let suggestedClientId = null;
      
      if (mergedData.client) {
        // Cerca una corrispondenza nel database
        try {
          const clientMatchResult = await matchOrSuggestClient(mergedData.client);
          console.log("Client match result:", clientMatchResult);
          
          if (clientMatchResult.clientId) {
            suggestedClientId = clientMatchResult.clientId;
            clientMatch = {
              id: clientMatchResult.clientId,
              matchType: clientMatchResult.matchType,
              similarityScore: clientMatchResult.similarityScore,
              suggestedName: clientMatchResult.suggestedName
            };
          }
        } catch (matchError) {
          console.error("Error matching client:", matchError);
          // Non fermiamo l'esecuzione se il matching fallisce
        }
      }
      
      // Verifica la presenza di dati significativi
      const hasSignificantData = mergedData.invoiceNumber || 
                                mergedData.issueDate || 
                                mergedData.totalAmount || 
                                mergedData.total ||
                                mergedData.client;
                                
      // Se non ci sono dati significativi, aggiungi un messaggio di avviso
      const warningMessage = !hasSignificantData 
        ? "Non sono stati estratti dati significativi dal PDF. La qualità del file potrebbe essere insufficiente o il formato non è supportato."
        : undefined;
      
      // Converti correttamente il valore dell'importo totale
      let parsedTotalAmount = mergedData.totalAmount;
      const total = mergedData.total; // Nuovo campo da OpenAI
      
      // Se c'è un total invece di totalAmount (dal modello AI)
      if (total && !parsedTotalAmount) {
        try {
          // Converti in formato numerico se possibile
          const cleanTotal = String(total)
            .replace(/[^\d,.]/g, '') // Rimuovi tutto tranne cifre, punti e virgole
            .replace(',', '.'); // Converti virgole in punti decimali
          
          parsedTotalAmount = parseFloat(cleanTotal);
          if (isNaN(parsedTotalAmount)) {
            parsedTotalAmount = 0;
          }
        } catch (e) {
          console.warn("Failed to parse total amount:", total);
          parsedTotalAmount = 0;
        }
      }
      
      // Formatta e restituisci il risultato finale
      // Prepara il percorso del file per la visualizzazione dal frontend
      // Usa il nome file sanitizzato per l'URL
      const tempPdfUrl = `/api/temp/${sanitizedFileName}`;
      console.log("URL per accesso PDF:", tempPdfUrl);
      
      res.json({
        ...mergedData,
        invoiceNumber: mergedData.invoiceNumber || "",
        issueDate: mergedData.issueDate || "",
        dueDate: mergedData.dueDate || "",
        totalAmount: parsedTotalAmount || 0,
        total: mergedData.total || "",  // Conserva anche il valore originale
        client: mergedData.client || "",
        paymentMethod: mergedData.paymentMethod || "",
        pdfExtracted: true,
        extractionMethod,
        clientId: suggestedClientId, // Aggiungi l'ID del cliente se trovato
        clientMatch: clientMatch, // Fornisce dettagli sul risultato della corrispondenza
        warningMessage, // Aggiungi un messaggio di avviso se necessario
        tempPath: tempFilePath, // Aggiungi il percorso temporaneo del file
        pdfUrl: tempPdfUrl // Aggiungi l'URL per accedere al file dal frontend
      });
    } catch (error) {
      console.error("PDF processing error:", error);
      res.status(500).json({ 
        message: "Errore durante l'elaborazione del PDF", 
        error: (error instanceof Error) ? error.message : String(error)
      });
    }
  });

  // Endpoint dedicato per il test di estrazione da PDF caricati direttamente (senza reindirizzamento)
  app.post("/api/admin/test-pdf-extraction-upload", upload.single("pdf"), async (req, res) => {
    try {
      // Questa rotta è essenzialmente identica a "/api/admin/invoices/extract", ma:
      // 1. Non reindirizza l'utente dopo l'elaborazione
      // 2. Ritorna solo JSON e non reindirizza mai
      // 3. Utilizza la cartella temporanea per i file
      
      if (!req.file) {
        return res.status(400).json({ message: "Nessun file caricato" });
      }
      
      const file = req.file;
      console.log("Received PDF file for extraction test:", file.originalname);
      
      // Il file è già stato caricato nella cartella temporanea da multer
      const tempFilePath = file.path;
      console.log("Temporary file path:", tempFilePath);
      
      // Sanitizza il nome del file per evitare problemi con gli spazi
      const originalFileName = path.basename(tempFilePath);
      const sanitizedFileName = originalFileName.replace(/\s+/g, '_');
      let filePathForProcessing = tempFilePath;
      
      // Se il nome del file è stato modificato, rinomina il file fisico
      if (sanitizedFileName !== originalFileName) {
        const sanitizedFilePath = path.join(path.dirname(tempFilePath), sanitizedFileName);
        console.log(`Rinomino file da ${tempFilePath} a ${sanitizedFilePath}`);
        fs.renameSync(tempFilePath, sanitizedFilePath);
        filePathForProcessing = sanitizedFilePath;
      }
      
      // Estrai il testo dal PDF usando il percorso sanitizzato
      let pdfText = "";
      try {
        pdfText = await extractTextFromPdf(filePathForProcessing);
        console.log(`Extracted ${pdfText.length} characters of text from PDF`);
      } catch (textExtractionError) {
        console.error("Error extracting text from PDF:", textExtractionError);
        pdfText = ""; // Se l'estrazione fallisce, utilizziamo una stringa vuota
      }
      
      // Extract structured data from text
      let invoiceData = {};
      if (pdfText && pdfText.length > 0) {
        invoiceData = extractInvoiceDataFromText(pdfText);
        console.log("Extracted invoice data:", invoiceData);
      }
      
      // Determina il metodo di estrazione più appropriato
      let aiExtractedData: {
        invoiceNumber?: string;
        issueDate?: string;
        total?: string;
        client?: string;
        dueDate?: string;
        paymentMethod?: string;
      } = {};
      
      if (!pdfText || pdfText.length < 50) {
        // Se il testo è insufficiente o assente, usa l'analisi basata su immagine
        console.log("PDF text is too short or empty, using image-based analysis");
        try {
          // Passiamo direttamente il percorso locale del file, non il percorso API
          console.log("Analyzing PDF image with local path:", tempFilePath);
          aiExtractedData = await analyzePdfAsImage(tempFilePath);
          console.log("Image-based AI extraction results:", aiExtractedData);
        } catch (imageAnalysisError) {
          console.error("Error in image-based analysis:", imageAnalysisError);
          // Se fallisce l'analisi basata su immagine, continuiamo con quanto già abbiamo
        }
      } else if (typeof invoiceData === 'object' && invoiceData) {
        // Verifica se l'estrazione regex ha prodotto risultati utili
        const hasInvoiceNumber = 'invoiceNumber' in invoiceData && invoiceData.invoiceNumber;
        const hasIssueDate = 'issueDate' in invoiceData && invoiceData.issueDate;
        const hasTotalAmount = 'totalAmount' in invoiceData && invoiceData.totalAmount;
        
        if (!hasInvoiceNumber && !hasIssueDate && !hasTotalAmount) {
          // Se l'estrazione regex non ha prodotto risultati utili, usa l'analisi basata su testo
          try {
            console.log("Using text-based OpenAI analysis");
            aiExtractedData = await analyzePdfText(pdfText);
            console.log("Text-based AI extraction results:", aiExtractedData);
          } catch (textAnalysisError) {
            console.error("Error in text-based analysis:", textAnalysisError);
            // Se fallisce l'analisi basata su testo, continuiamo con quanto già abbiamo
          }
        }
      }
      
      // Gestione del nuovo formato di output (total invece di totalAmount)
      // con normalizzazione avanzata degli importi
      let aiTotalAmount: number | undefined = undefined;
      
      if (aiExtractedData.total) {
        const amount = aiExtractedData.total;
        // Pulizia e normalizzazione della stringa dell'importo
        const amountString = String(amount)
          .replace(/[^\d,.\s€$£]/g, '') // Rimuovi caratteri non numerici eccetto separatori e valute
          .trim(); 
        
        // Normalizzazione in base ai separatori
        let normalizedAmount = "";
        if (amountString.includes(',') && amountString.includes('.')) {
          // Formato con entrambi i separatori (es. 1.234,56)
          // Assumiamo che il punto sia per migliaia e la virgola per decimali
          normalizedAmount = amountString.replace(/\./g, '').replace(',', '.');
        } else if (amountString.includes(',')) {
          // Solo virgole (es. 1234,56)
          normalizedAmount = amountString.replace(',', '.');
        } else {
          // Solo punti o nessun separatore (es. 1234.56 o 1234)
          normalizedAmount = amountString;
        }
        
        const parsedAmount = parseFloat(normalizedAmount);
        if (!isNaN(parsedAmount)) {
          aiTotalAmount = parsedAmount;
          console.log(`OpenAI totale: ${amount} -> normalizzato: ${normalizedAmount} -> valore: ${parsedAmount}`);
        }
      }
      
      const processedAIData = {
        invoiceNumber: aiExtractedData.invoiceNumber,
        issueDate: aiExtractedData.issueDate,
        totalAmount: aiTotalAmount,
        client: aiExtractedData.client,
        dueDate: aiExtractedData.dueDate,
        paymentMethod: aiExtractedData.paymentMethod
      };
      
      // Merge data prioritizing AI extracted data over regex extracted data
      const mergedData: {
        invoiceNumber?: string;
        issueDate?: string;
        totalAmount?: number;
        client?: string;
        dueDate?: string;
        paymentMethod?: string;
        [key: string]: any;
      } = {
        ...invoiceData, // Prima i dati estratti con regex
        ...processedAIData // Poi i dati AI che sovrascrivono quelli regex se presenti
      };
      
      // Determina il metodo di estrazione utilizzato
      let extractionMethod = "regex";
      if (!pdfText || pdfText.length < 50) {
        extractionMethod = "image-based-ai";
      } else if (typeof invoiceData === 'object' && invoiceData) {
        // Verifica se l'estrazione regex ha prodotto risultati utili
        const hasInvoiceNumber = 'invoiceNumber' in invoiceData && invoiceData.invoiceNumber;
        const hasIssueDate = 'issueDate' in invoiceData && invoiceData.issueDate;
        const hasTotalAmount = 'totalAmount' in invoiceData && invoiceData.totalAmount;
        
        if (Object.keys(invoiceData).length === 0 || (!hasInvoiceNumber && !hasIssueDate && !hasTotalAmount)) {
          extractionMethod = "text-based-ai";
        }
      }
      
      // Se l'AI ha contribuito con almeno un dato significativo, è un'estrazione ibrida
      if (Object.keys(processedAIData).some(key => !!processedAIData[key as keyof typeof processedAIData])) {
        extractionMethod = "hybrid";
      }
      
      // Trova una corrispondenza per il cliente se è stato estratto un nome
      let clientMatch = null;
      let suggestedClientId = null;
      
      if (mergedData.client) {
        // Cerca una corrispondenza nel database
        try {
          const clientMatchResult = await matchOrSuggestClient(mergedData.client);
          console.log("Client match result:", clientMatchResult);
          
          if (clientMatchResult.clientId) {
            suggestedClientId = clientMatchResult.clientId;
            clientMatch = {
              id: clientMatchResult.clientId,
              matchType: clientMatchResult.matchType,
              similarityScore: clientMatchResult.similarityScore,
              suggestedName: clientMatchResult.suggestedName
            };
          }
        } catch (matchError) {
          console.error("Error matching client:", matchError);
          // Non fermiamo l'esecuzione se il matching fallisce
        }
      }
      
      // Verifica la presenza di dati significativi
      const hasSignificantData = mergedData.invoiceNumber || 
                                mergedData.issueDate || 
                                mergedData.totalAmount || 
                                mergedData.total ||
                                mergedData.client;
                                
      // Se non ci sono dati significativi, aggiungi un messaggio di avviso
      const warningMessage = !hasSignificantData 
        ? "Non sono stati estratti dati significativi dal PDF. La qualità del file potrebbe essere insufficiente o il formato non è supportato."
        : undefined;
      
      // Converti correttamente il valore dell'importo totale
      let parsedTotalAmount = mergedData.totalAmount;
      const total = mergedData.total; // Nuovo campo da OpenAI
      
      // Se c'è un total invece di totalAmount (dal modello AI)
      if (total && !parsedTotalAmount) {
        try {
          // Converti in formato numerico se possibile
          const cleanTotal = String(total)
            .replace(/[^\d,.]/g, '') // Rimuovi tutto tranne cifre, punti e virgole
            .replace(',', '.'); // Converti virgole in punti decimali
          
          parsedTotalAmount = parseFloat(cleanTotal);
          if (isNaN(parsedTotalAmount)) {
            parsedTotalAmount = 0;
          }
        } catch (e) {
          console.warn("Failed to parse total amount:", total);
          parsedTotalAmount = 0;
        }
      }
      
      // Crea un URL per l'API che possa essere usato dal frontend
      // Il percorso temporaneo per riferimento futuro (debug)
      // Conserva il percorso temporaneo del file per il debug
      const tempPath = filePathForProcessing;
      
      // Crea l'URL per accedere al PDF dal frontend
      const pdfFileUrl = `/api/temp/${sanitizedFileName}`;
      console.log("URL per accesso PDF:", pdfFileUrl);
      
      // Crea un estratto di anteprima del testo
      const textPreview = pdfText.slice(0, 200) + (pdfText.length > 200 ? "..." : "");
      
      // Formatta e restituisci il risultato finale
      res.json({
        ...mergedData,
        invoiceNumber: mergedData.invoiceNumber || "",
        issueDate: mergedData.issueDate || "",
        dueDate: mergedData.dueDate || "",
        totalAmount: parsedTotalAmount || 0,
        total: mergedData.total || "",  // Conserva anche il valore originale
        client: mergedData.client || "",
        paymentMethod: mergedData.paymentMethod || "",
        pdfExtracted: true,
        extractionMethod,
        clientId: suggestedClientId, // Aggiungi l'ID del cliente se trovato
        clientMatch: clientMatch, // Fornisce dettagli sul risultato della corrispondenza
        warningMessage, // Aggiungi un messaggio di avviso se necessario
        textLength: pdfText.length,
        textPreview,
        tempPath, // Solo per test, da rimuovere in produzione
        pdfPath: pdfFileUrl, // URL per il frontend
        pdfUrl: pdfFileUrl, // URL aggiuntivo esplicito
        aiExtraction: aiExtractedData,
        regexExtraction: invoiceData
      });
    } catch (error) {
      console.error("PDF test extraction error:", error);
      res.status(500).json({ 
        message: "Errore durante l'estrazione dal PDF", 
        error: (error instanceof Error) ? error.message : String(error)
      });
    }
  });

  // AI-powered invoice insights routes
  app.get("/api/admin/invoices/:id/insights", isAdmin, async (req, res) => {
    try {
      const invoiceId = parseInt(req.params.id);
      
      if (isNaN(invoiceId)) {
        return res.status(400).json({ message: "Invalid invoice ID" });
      }
      
      const invoice = await storage.getInvoiceWithItems(invoiceId);
      
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      // Get client information
      const client = await storage.getClient(invoice.clientId);
      
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }

      // Import the OpenAI functions
      const { analyzeInvoice } = await import("./openai.js");
      
      // Combine invoice data with client data for better analysis
      const invoiceWithClientData = {
        ...invoice,
        clientName: client.name,
        clientEmail: client.email,
        clientAddress: client.address,
        clientTaxId: client.taxId,
        clientStats: {
          totalPaid: client.totalPaid,
          totalPending: client.totalPending,
          totalOverdue: client.totalOverdue,
          totalInvoices: client.totalInvoices,
          paidInvoices: client.paidInvoices,
          pendingInvoices: client.pendingInvoices,
          overdueInvoices: client.overdueInvoices
        }
      };
      
      // Generate insights
      const insights = await analyzeInvoice(invoiceWithClientData);
      res.json(insights);
    } catch (error) {
      console.error(error);
      res.status(500).json({ 
        message: "Error analyzing invoice", 
        error: (error instanceof Error) ? error.message : String(error)
      });
    }
  });

  app.get("/api/admin/clients/:id/payment-trends", isAdmin, async (req, res) => {
    try {
      const clientId = parseInt(req.params.id);
      
      if (isNaN(clientId)) {
        return res.status(400).json({ message: "Invalid client ID" });
      }
      
      const client = await storage.getClient(clientId);
      
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }

      // Get all invoices for this client
      const invoices = await storage.getInvoicesByClientId(clientId);
      
      // Import the OpenAI functions
      const { analyzePaymentTrends } = await import("./openai.js");
      
      // Generate payment trend analysis
      const combinedData = {
        client: client,
        invoices: invoices
      };
      
      const trends = await analyzePaymentTrends(invoices);
      
      res.json(trends);
    } catch (error) {
      console.error(error);
      res.status(500).json({ 
        message: "Error analyzing payment trends", 
        error: (error instanceof Error) ? error.message : String(error)
      });
    }
  });

  // Endpoint per rilevare fatture con PDF mancanti
  app.get("/api/admin/missing-pdfs-report", isAdmin, async (req, res) => {
    try {
      // Ottieni tutte le fatture
      const invoices = await storage.getInvoices();
      
      // Arricchisci i dati delle fatture con informazioni sul cliente 
      // e verifica dell'esistenza del PDF
      const enrichedInvoices = await Promise.all(invoices.map(async (invoice) => {
        const client = await storage.getClient(invoice.clientId);
        
        // Verifica se il PDF esiste fisicamente nel filesystem
        let pdfExists = false;
        let pdfPath = invoice.pdfPath;
        
        if (invoice.pdfPath) {
          // 1. Cerca il file in base al percorso completo
          const pdfFullPath = path.join(process.cwd(), invoice.pdfPath.replace(/^\/api\/uploads\//, "uploads/"));
          pdfExists = fs.existsSync(pdfFullPath);
          
          // 2. Se non trovato, prova a estrarre il nome del file e cercarlo in tutte le posizioni possibili
          if (!pdfExists) {
            const fileName = invoice.pdfPath.split('/').pop();
            if (fileName) {
              // Cerca nella directory principale uploads
              const mainDirPath = path.join(process.cwd(), "uploads", fileName);
              if (fs.existsSync(mainDirPath)) {
                pdfExists = true;
              } else {
                // Cerca nelle directory dei clienti
                const uploadDir = path.join(process.cwd(), "uploads");
                try {
                  const clientDirs = fs.readdirSync(uploadDir, { withFileTypes: true })
                    .filter(dirent => dirent.isDirectory())
                    .map(dirent => dirent.name);
                  
                  for (const clientDir of clientDirs) {
                    const clientPath = path.join(uploadDir, clientDir, fileName);
                    if (fs.existsSync(clientPath)) {
                      pdfExists = true;
                      break;
                    }
                  }
                } catch (fsError) {
                  console.error("Errore nella lettura directory:", fsError);
                }
              }
            }
          }
        }
        
        return {
          ...invoice,
          client: {
            id: client?.id || 0,
            name: client?.name || "Cliente sconosciuto",
            email: client?.email || "",
          },
          pdfExists // aggiungiamo una flag esplicita per indicare se il PDF esiste
        };
      }));
      
      // Filtra manualmente le fatture senza PDF
      const missingPdfs = enrichedInvoices.filter(invoice => !invoice.pdfExists);
      
      // Determina l'urgenza in base al numero di fatture mancanti
      let urgencyLevel = "Bassa";
      if (missingPdfs.length > 20) {
        urgencyLevel = "Alta";
      } else if (missingPdfs.length > 5) {
        urgencyLevel = "Media";
      }
      
      // Prepara l'analisi di base senza utilizzare l'AI
      let analysis = "Tutte le fatture hanno un PDF correttamente associato.";
      let recommendedActions: string[] = [];
      
      if (missingPdfs.length > 0) {
        analysis = `Sono state rilevate ${missingPdfs.length} fatture senza PDF allegato. È consigliabile caricare i PDF mancanti per mantenere una corretta documentazione.`;
        
        recommendedActions = [
          "Carica i PDF mancanti utilizzando il pulsante dedicato",
          "Verifica che i documenti originali siano disponibili negli archivi fisici",
          "Considera di impostare un processo di verifica periodica per i documenti mancanti"
        ];
        
        if (missingPdfs.length > 20) {
          analysis += " Il numero elevato di documenti mancanti richiede attenzione urgente.";
        }
      }
      
      // Invia la risposta
      if (missingPdfs.length > 0) {
        res.json({
          hasMissingPdfs: true,
          missingCount: missingPdfs.length,
          analysis: analysis,
          invoicesWithMissingPdf: missingPdfs.map(invoice => ({
            id: invoice.id,
            number: invoice.number,
            issueDate: invoice.issueDate,
            clientId: invoice.clientId,
            clientName: invoice.client.name,
            pdfPath: invoice.pdfPath || "",
            // Aggiungiamo dati per il debug
            status: "missing_pdf"
          })),
          recommendedActions: recommendedActions,
          urgencyLevel: urgencyLevel
        });
      } else {
        // Nessun PDF mancante
        res.json({
          hasMissingPdfs: false,
          missingCount: 0,
          analysis: "Tutte le fatture hanno un PDF correttamente associato.",
          invoicesWithMissingPdf: [],
          urgencyLevel: "Bassa"
        });
      }
    } catch (error) {
      console.error(error);
      res.status(500).json({ 
        message: "Errore nell'analisi dei PDF mancanti", 
        error: (error instanceof Error) ? error.message : String(error)
      });
    }
  });
  
  app.get("/api/admin/pending-payments-report", isAdmin, async (req, res) => {
    try {
      // Get all invoices
      const allInvoices = await storage.getInvoices();
      
      // Filter to get only pending and overdue invoices
      const pendingInvoices = allInvoices.filter(invoice => 
        invoice.status === "pending" || invoice.status === "overdue"
      );

      // Get client details for each invoice
      const enrichedInvoices = await Promise.all(pendingInvoices.map(async (invoice) => {
        const client = await storage.getClient(invoice.clientId);
        return {
          ...invoice,
          clientName: client?.name || "Unknown Client",
          clientEmail: client?.email || "",
          clientAddress: client?.address || "",
          clientTotalPaid: client?.totalPaid || "0.00",
          clientTotalPending: client?.totalPending || "0.00",
          clientTotalOverdue: client?.totalOverdue || "0.00"
        };
      }));
      
      // Import the OpenAI functions
      const { generatePendingPaymentsReport } = await import("./openai.js");
      
      // Generate report
      const report = await generatePendingPaymentsReport(enrichedInvoices);
      res.json(report);
    } catch (error) {
      console.error(error);
      res.status(500).json({ 
        message: "Error generating pending payments report", 
        error: (error instanceof Error) ? error.message : String(error)
      });
    }
  });

  app.get("/api/admin/invoices/:id/payment-probability", isAdmin, async (req, res) => {
    try {
      const invoiceId = parseInt(req.params.id);
      
      if (isNaN(invoiceId)) {
        return res.status(400).json({ message: "Invalid invoice ID" });
      }
      
      const invoice = await storage.getInvoiceWithItems(invoiceId);
      
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      // Get client information
      const client = await storage.getClient(invoice.clientId);
      
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }

      // Get client's payment history
      const clientInvoices = await storage.getInvoicesByClientId(invoice.clientId);
      
      // Filter to exclude the current invoice
      const paymentHistory = clientInvoices.filter(inv => inv.id !== invoiceId);

      // Import the OpenAI functions
      const { predictPaymentProbability } = await import("./openai.js");
      
      // Generate prediction
      const prediction = await predictPaymentProbability(invoice, {
        client,
        paymentHistory
      });
      
      res.json(prediction);
    } catch (error) {
      console.error(error);
      res.status(500).json({ 
        message: "Error predicting payment probability", 
        error: (error instanceof Error) ? error.message : String(error)
      });
    }
  });

  // API Settings Management
  
  // Endpoint per esportare impostazioni rimosso per motivi di prestazioni
  // Le funzionalità di esportazione sono state rimosse per garantire tempi
  // di avvio del server più rapidi su Replit
  
  // Get all API settings
  app.get("/api/settings", isAdmin, async (req, res) => {
    try {
      const settings = await storage.getApiSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ 
        message: "Error retrieving API settings", 
        error: (error instanceof Error) ? error.message : String(error) 
      });
    }
  });

  // Get active API settings
  app.get("/api/settings/active", isAdmin, async (req, res) => {
    try {
      const settings = await storage.getActiveApiSettings();
      if (!settings) {
        return res.status(404).json({ message: "No active API settings found" });
      }
      res.json(settings);
    } catch (error) {
      res.status(500).json({ 
        message: "Error retrieving active API settings", 
        error: (error instanceof Error) ? error.message : String(error) 
      });
    }
  });

  // Create new API settings
  app.post("/api/settings", isAdmin, async (req, res) => {
    try {
      // If this setting should be active, first deactivate all others
      if (req.body.isActive) {
        const currentSettings = await storage.getApiSettings();
        for (const setting of currentSettings) {
          if (setting.isActive) {
            await storage.updateApiSettings(setting.id, { isActive: false });
          }
        }
      }
      
      // Handle extraOptions as JSON object
      let formattedData = { ...req.body };
      if (typeof req.body.extraOptions === 'string') {
        try {
          formattedData.extraOptions = JSON.parse(req.body.extraOptions);
        } catch (e) {
          return res.status(400).json({ message: "Invalid JSON in extraOptions" });
        }
      }
      
      const settings = await storage.createApiSettings(formattedData);
      res.status(201).json(settings);
    } catch (error) {
      res.status(500).json({ 
        message: "Error creating API settings", 
        error: (error instanceof Error) ? error.message : String(error) 
      });
    }
  });

  // Update API settings
  app.put("/api/settings/:id", isAdmin, async (req, res) => {
    try {
      const settingsId = parseInt(req.params.id);
      
      if (isNaN(settingsId)) {
        return res.status(400).json({ message: "Invalid settings ID" });
      }
      
      const settings = await storage.getApiSettings();
      const existingSettings = settings.find(s => s.id === settingsId);
      
      if (!existingSettings) {
        return res.status(404).json({ message: "API settings not found" });
      }
      
      // Handle extraOptions as JSON object
      let formattedData = { ...req.body };
      if (typeof req.body.extraOptions === 'string') {
        try {
          formattedData.extraOptions = JSON.parse(req.body.extraOptions);
        } catch (e) {
          return res.status(400).json({ message: "Invalid JSON in extraOptions" });
        }
      }
      
      // If this setting should be active, first deactivate all others
      if (req.body.isActive && !existingSettings.isActive) {
        for (const setting of settings) {
          if (setting.isActive) {
            await storage.updateApiSettings(setting.id, { isActive: false });
          }
        }
      }
      
      const updatedSettings = await storage.updateApiSettings(settingsId, formattedData);
      res.json(updatedSettings);
    } catch (error) {
      res.status(500).json({ 
        message: "Error updating API settings", 
        error: (error instanceof Error) ? error.message : String(error) 
      });
    }
  });

  // Delete API settings
  app.delete("/api/settings/:id", isAdmin, async (req, res) => {
    try {
      const settingsId = parseInt(req.params.id);
      
      if (isNaN(settingsId)) {
        return res.status(400).json({ message: "Invalid settings ID" });
      }
      
      const settings = await storage.getApiSettings();
      const existingSettings = settings.find(s => s.id === settingsId);
      
      if (!existingSettings) {
        return res.status(404).json({ message: "API settings not found" });
      }
      
      const deleted = await storage.deleteApiSettings(settingsId);
      
      if (!deleted) {
        return res.status(500).json({ message: "Failed to delete API settings" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ 
        message: "Error deleting API settings", 
        error: (error instanceof Error) ? error.message : String(error) 
      });
    }
  });

  // Activate API settings
  app.post("/api/settings/:id/activate", isAdmin, async (req, res) => {
    try {
      const settingsId = parseInt(req.params.id);
      
      if (isNaN(settingsId)) {
        return res.status(400).json({ message: "Invalid settings ID" });
      }
      
      const settings = await storage.getApiSettings();
      const existingSettings = settings.find(s => s.id === settingsId);
      
      if (!existingSettings) {
        return res.status(404).json({ message: "API settings not found" });
      }
      
      const activated = await storage.setActiveApiSettings(settingsId);
      
      if (!activated) {
        return res.status(500).json({ message: "Failed to activate API settings" });
      }
      
      res.status(200).json({ message: "API settings activated successfully" });
    } catch (error) {
      res.status(500).json({ 
        message: "Error activating API settings", 
        error: (error instanceof Error) ? error.message : String(error) 
      });
    }
  });

  // User management
  app.get("/api/admin/users", isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });

  // User-Client associations management
  app.get("/api/admin/user-clients/user/:userId", isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const associations = await storage.getUserClientAssociations(userId);
      res.json(associations);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });
  
  app.get("/api/admin/user-clients/client/:clientId", isAdmin, async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      
      if (isNaN(clientId)) {
        return res.status(400).json({ message: "Invalid client ID" });
      }
      
      const client = await storage.getClient(clientId);
      
      if (!client) {
        return res.status(404).json({ message: "Client not found" });
      }
      
      const associations = await storage.getClientUserAssociations(clientId);
      res.json(associations);
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });
  
  app.post("/api/admin/user-clients", isAdmin, async (req, res) => {
    try {
      console.log("Received request to create user-client association with body:", JSON.stringify(req.body, null, 2));
      
      const associationData = insertUserClientSchema.parse(req.body);
      console.log("Parsed association data:", JSON.stringify(associationData, null, 2));
      
      // Verify that user and client exist
      const user = await storage.getUser(associationData.userId);
      if (!user) {
        console.log("User not found with ID:", associationData.userId);
        return res.status(404).json({ message: "User not found" });
      }
      console.log("Found user:", JSON.stringify(user, null, 2));
      
      const client = await storage.getClient(associationData.clientId);
      if (!client) {
        console.log("Client not found with ID:", associationData.clientId);
        return res.status(404).json({ message: "Client not found" });
      }
      console.log("Found client:", JSON.stringify(client, null, 2));
      
      // If this is set as default, update any existing default for this user
      if (associationData.isDefault) {
        console.log("This association is marked as default, updating existing defaults");
        const userAssociations = await storage.getUserClientAssociations(associationData.userId);
        for (const assoc of userAssociations) {
          if (assoc.isDefault) {
            await storage.updateUserClientAssociation(assoc.id, { isDefault: false });
          }
        }
      }
      
      try {
        const association = await storage.createUserClientAssociation(associationData);
        console.log("Association created successfully:", JSON.stringify(association, null, 2));
        res.status(201).json(association);
      } catch (dbError) {
        console.error("Database error creating association:", dbError);
        res.status(500).json({ 
          message: "Errore durante la creazione dell'associazione nel database", 
          error: dbError instanceof Error ? dbError.message : String(dbError)
        });
      }
    } catch (error) {
      console.error("Error in user-client association route:", error);
      if (error instanceof z.ZodError) {
        console.log("Validation error:", JSON.stringify(error.errors, null, 2));
        return res.status(400).json({ message: "Invalid association data", errors: error.errors });
      }
      res.status(500).json({ 
        message: "Server error", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });
  
  app.put("/api/admin/user-clients/:id", isAdmin, async (req, res) => {
    try {
      const associationId = parseInt(req.params.id);
      
      if (isNaN(associationId)) {
        return res.status(400).json({ message: "Invalid association ID" });
      }
      
      // Get the association to verify it exists and to get the userId
      const associations = await db.select().from(userClients).where(eq(userClients.id, associationId));
      if (associations.length === 0) {
        return res.status(404).json({ message: "Association not found" });
      }
      
      const association = associations[0];
      const associationData = insertUserClientSchema.partial().parse(req.body);
      
      // If this is set as default, update any existing default for this user
      if (associationData.isDefault) {
        const userAssociations = await storage.getUserClientAssociations(association.userId);
        for (const assoc of userAssociations) {
          if (assoc.id !== associationId && assoc.isDefault) {
            await storage.updateUserClientAssociation(assoc.id, { isDefault: false });
          }
        }
      }
      
      const updatedAssociation = await storage.updateUserClientAssociation(associationId, associationData);
      
      res.json(updatedAssociation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid association data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error });
    }
  });
  
  app.delete("/api/admin/user-clients/:id", isAdmin, async (req, res) => {
    try {
      const associationId = parseInt(req.params.id);
      
      if (isNaN(associationId)) {
        return res.status(400).json({ message: "Invalid association ID" });
      }
      
      const deleted = await storage.deleteUserClientAssociation(associationId);
      
      if (!deleted) {
        return res.status(500).json({ message: "Failed to delete association" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Server error", error });
    }
  });
  
  // Route di test per l'estrazione dati PDF tramite OpenAI e Regex
  app.post("/api/admin/test-pdf-extraction", isAdmin, async (req, res) => {
    try {
      const { pdfPath } = req.body;
      
      if (!pdfPath) {
        return res.status(400).json({ error: "Percorso PDF mancante" });
      }
      
      // Converti percorso API in percorso file
      const filePath = path.join(process.cwd(), pdfPath.replace("/api/uploads/", "uploads/"));
      
      // Verifica che il file esista
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: "File PDF non trovato", path: filePath });
      }
      
      // Import necessari
      const { extractTextFromPdf, extractInvoiceDataFromText } = await import("./utils/pdf-extractor.js");
      const { analyzePdfText, analyzePdfAsImage } = await import("./openai.js");
      
      // Estrai il testo dal PDF
      let pdfText = "";
      try {
        pdfText = await extractTextFromPdf(filePath);
      } catch (error) {
        console.error("Errore nell'estrazione del testo dal PDF:", error);
        pdfText = "\n\n..."; // Placeholder in caso di errore
      }
      
      // Estrai dati con il metodo regex
      console.log(`Estrazione dati da PDF tramite regex per ${filePath}`);
      const regexData = extractInvoiceDataFromText(pdfText);
      
      // Determina il metodo di estrazione più appropriato per OpenAI
      let openaiData;
      if (pdfText.length < 50) {
        // Se il testo è molto breve, probabilmente è un PDF basato su immagini
        console.log(`Testo PDF troppo breve (${pdfText.length} caratteri), utilizzo analisi basata su immagine per ${filePath}`);
        // Qui passiamo direttamente il percorso locale del file, non il percorso API
        openaiData = await analyzePdfAsImage(filePath);
      } else {
        // Altrimenti usa l'analisi basata su testo
        console.log(`Estrazione dati da PDF tramite OpenAI per ${filePath}`);
        openaiData = await analyzePdfText(pdfText);
      }
      
      // Restituisci entrambi i risultati per confronto
      return res.json({
        pdfPath,
        textLength: pdfText.length,
        textPreview: pdfText.substring(0, Math.min(100, pdfText.length)) + (pdfText.length > 100 ? "..." : ""),
        regexExtraction: regexData,
        aiExtraction: openaiData,
      });
    } catch (error) {
      console.error("Errore nel test di estrazione PDF:", error);
      return res.status(500).json({ 
        error: "Errore nell'estrazione dei dati dal PDF", 
        details: error instanceof Error ? error.message : String(error)
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

import express from "express";
