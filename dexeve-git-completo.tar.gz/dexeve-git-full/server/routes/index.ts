import { Express, static as expressStatic } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "../auth";
import multer from "multer";
import path from "path";
import { registerInvoiceRoutes } from "./invoice-routes";
import { registerClientRoutes } from "./client-routes";
import { registerUserRoutes } from "./user-routes";
import { registerApiSettingsRoutes } from "./api-settings-routes";
import { initializeDirectories, UPLOADS_DIR, TEMP_UPLOADS_DIR } from "../utils/file-handler";

export async function registerRoutes(app: Express): Promise<Server> {
  // Inizializza directory necessarie
  console.log("Verifica e creazione directory uploads e temp...");
  initializeDirectories();
  console.log(`Directory uploads: ${UPLOADS_DIR}`);
  console.log(`Directory temp: ${TEMP_UPLOADS_DIR}`);
  
  // Configura l'autenticazione
  setupAuth(app);
  
  // Configura le rotte statiche
  app.use('/uploads', expressStatic(UPLOADS_DIR));
  app.use('/public', expressStatic(path.join(process.cwd(), 'public')));
  
  // Registra tutte le rotte specifiche
  registerInvoiceRoutes(app);
  registerClientRoutes(app);
  registerUserRoutes(app);
  registerApiSettingsRoutes(app);

  // Crea e restituisci il server HTTP
  const httpServer = createServer(app);
  return httpServer;
}