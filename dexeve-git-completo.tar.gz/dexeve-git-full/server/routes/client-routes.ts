import { Express, Request, Response } from "express";
import { storage } from "../storage";
import { insertClientSchema } from "@shared/schema";
import { isAuthenticated, isAdmin } from "../middleware/auth-middleware";

export function registerClientRoutes(app: Express) {
  // GET /api/clients - Ottiene tutti i clienti
  app.get("/api/clients", isAuthenticated, async (req, res) => {
    try {
      // Gli amministratori vedono tutti i clienti
      if (req.user?.role === "administrator") {
        const clients = await storage.getClients();
        res.json(clients);
      } else {
        // I client normali vedono solo i clienti a cui sono associati
        const clients = await storage.getClientsByUserId(req.user!.id);
        res.json(clients);
      }
    } catch (error) {
      console.error("Errore nel recupero dei clienti:", error);
      res.status(500).json({ error: "Errore nel recupero dei clienti" });
    }
  });

  // GET /api/clients/:id - Ottiene un cliente specifico
  app.get("/api/clients/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const client = await storage.getClient(id);
      
      if (!client) {
        return res.status(404).json({ error: "Cliente non trovato" });
      }
      
      // Se non è admin, verifica che l'utente sia associato al cliente
      if (req.user?.role !== "administrator") {
        const userClients = await storage.getUserClientAssociations(req.user!.id);
        const clientIds = userClients.map(uc => uc.clientId);
        
        if (!clientIds.includes(client.id)) {
          return res.status(403).json({ error: "Non autorizzato ad accedere a questo cliente" });
        }
      }
      
      res.json(client);
    } catch (error) {
      console.error("Errore nel recupero del cliente:", error);
      res.status(500).json({ error: "Errore nel recupero del cliente" });
    }
  });

  // POST /api/clients - Crea un nuovo cliente
  app.post("/api/clients", isAdmin, async (req, res) => {
    try {
      const validatedData = insertClientSchema.parse(req.body);
      const client = await storage.createClient(validatedData);
      res.status(201).json(client);
    } catch (error) {
      console.error("Errore nella creazione del cliente:", error);
      res.status(400).json({ error: "Errore nella creazione del cliente", details: error });
    }
  });

  // PUT /api/clients/:id - Aggiorna un cliente esistente
  app.put("/api/clients/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const client = await storage.updateClient(id, req.body);
      
      if (!client) {
        return res.status(404).json({ error: "Cliente non trovato" });
      }
      
      res.json(client);
    } catch (error) {
      console.error("Errore nell'aggiornamento del cliente:", error);
      res.status(400).json({ error: "Errore nell'aggiornamento del cliente", details: error });
    }
  });

  // DELETE /api/clients/:id - Elimina un cliente
  app.delete("/api/clients/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Prima verifica se ci sono fatture associate
      const invoices = await storage.getInvoicesByClientId(id);
      if (invoices.length > 0) {
        return res.status(400).json({ 
          error: "Non è possibile eliminare il cliente perché ha fatture associate",
          invoiceCount: invoices.length
        });
      }
      
      const success = await storage.deleteClient(id);
      
      if (!success) {
        return res.status(404).json({ error: "Cliente non trovato" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Errore nell'eliminazione del cliente:", error);
      res.status(500).json({ error: "Errore nell'eliminazione del cliente" });
    }
  });

  // GET /api/clients/:id/invoices - Ottiene tutte le fatture di un cliente
  app.get("/api/clients/:id/invoices", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const client = await storage.getClient(id);
      
      if (!client) {
        return res.status(404).json({ error: "Cliente non trovato" });
      }
      
      // Se non è admin, verifica che l'utente sia associato al cliente
      if (req.user?.role !== "administrator") {
        const userClients = await storage.getUserClientAssociations(req.user!.id);
        const clientIds = userClients.map(uc => uc.clientId);
        
        if (!clientIds.includes(client.id)) {
          return res.status(403).json({ error: "Non autorizzato ad accedere a questo cliente" });
        }
      }
      
      const invoices = await storage.getInvoicesByClientId(id);
      res.json(invoices);
    } catch (error) {
      console.error("Errore nel recupero delle fatture del cliente:", error);
      res.status(500).json({ error: "Errore nel recupero delle fatture del cliente" });
    }
  });
}