import { Express, Request, Response } from "express";
import { storage } from "../storage";
import { insertUserClientSchema } from "@shared/schema";
import { isAuthenticated, isAdmin } from "../middleware/auth-middleware";

export function registerUserRoutes(app: Express) {
  // GET /api/users - Ottiene tutti gli utenti (solo admin)
  app.get("/api/users", isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      
      // Rimuovi le password per sicurezza
      const sanitizedUsers = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      res.json(sanitizedUsers);
    } catch (error) {
      console.error("Errore nel recupero degli utenti:", error);
      res.status(500).json({ error: "Errore nel recupero degli utenti" });
    }
  });

  // PUT /api/users/:id/role - Aggiorna il ruolo di un utente (solo admin)
  app.put("/api/users/:id/role", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { role } = req.body;
      
      if (role !== "user" && role !== "administrator") {
        return res.status(400).json({ error: "Ruolo non valido" });
      }
      
      const user = await storage.updateUserRole(id, role);
      
      if (!user) {
        return res.status(404).json({ error: "Utente non trovato" });
      }
      
      // Rimuovi la password per sicurezza
      const { password, ...userWithoutPassword } = user;
      
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Errore nell'aggiornamento del ruolo:", error);
      res.status(500).json({ error: "Errore nell'aggiornamento del ruolo" });
    }
  });

  // GET /api/user-clients/:userId - Ottiene tutte le associazioni utente-cliente per un utente
  app.get("/api/user-clients/:userId", isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const associations = await storage.getUserClientAssociations(userId);
      res.json(associations);
    } catch (error) {
      console.error("Errore nel recupero delle associazioni:", error);
      res.status(500).json({ error: "Errore nel recupero delle associazioni" });
    }
  });

  // GET /api/client-users/:clientId - Ottiene tutte le associazioni utente-cliente per un cliente
  app.get("/api/client-users/:clientId", isAdmin, async (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const associations = await storage.getClientUserAssociations(clientId);
      res.json(associations);
    } catch (error) {
      console.error("Errore nel recupero delle associazioni:", error);
      res.status(500).json({ error: "Errore nel recupero delle associazioni" });
    }
  });

  // POST /api/user-clients - Crea una nuova associazione utente-cliente
  app.post("/api/user-clients", isAdmin, async (req, res) => {
    try {
      const validatedData = insertUserClientSchema.parse(req.body);
      const association = await storage.createUserClientAssociation(validatedData);
      res.status(201).json(association);
    } catch (error) {
      console.error("Errore nella creazione dell'associazione:", error);
      res.status(400).json({ error: "Errore nella creazione dell'associazione", details: error });
    }
  });

  // PUT /api/user-clients/:id - Aggiorna un'associazione utente-cliente
  app.put("/api/user-clients/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const association = await storage.updateUserClientAssociation(id, req.body);
      
      if (!association) {
        return res.status(404).json({ error: "Associazione non trovata" });
      }
      
      res.json(association);
    } catch (error) {
      console.error("Errore nell'aggiornamento dell'associazione:", error);
      res.status(400).json({ error: "Errore nell'aggiornamento dell'associazione", details: error });
    }
  });

  // DELETE /api/user-clients/:id - Elimina un'associazione utente-cliente
  app.delete("/api/user-clients/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteUserClientAssociation(id);
      
      if (!success) {
        return res.status(404).json({ error: "Associazione non trovata" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Errore nell'eliminazione dell'associazione:", error);
      res.status(500).json({ error: "Errore nell'eliminazione dell'associazione" });
    }
  });
}