import { Express, Request, Response } from "express";
import { storage } from "../storage";
import { insertApiSettingsSchema } from "@shared/schema";
import { isAdmin } from "../middleware/auth-middleware";

export function registerApiSettingsRoutes(app: Express) {
  // GET /api/settings - Ottiene tutte le impostazioni API
  app.get("/api/settings", isAdmin, async (req, res) => {
    try {
      const settings = await storage.getApiSettings();
      res.json(settings);
    } catch (error) {
      console.error("Errore nel recupero delle impostazioni:", error);
      res.status(500).json({ error: "Errore nel recupero delle impostazioni" });
    }
  });

  // GET /api/settings/active - Ottiene le impostazioni API attive
  app.get("/api/settings/active", isAdmin, async (req, res) => {
    try {
      const settings = await storage.getActiveApiSettings();
      res.json(settings || null);
    } catch (error) {
      console.error("Errore nel recupero delle impostazioni attive:", error);
      res.status(500).json({ error: "Errore nel recupero delle impostazioni attive" });
    }
  });

  // POST /api/settings - Crea nuove impostazioni API
  app.post("/api/settings", isAdmin, async (req, res) => {
    try {
      const validatedData = insertApiSettingsSchema.parse(req.body);
      const settings = await storage.createApiSettings(validatedData);
      res.status(201).json(settings);
    } catch (error) {
      console.error("Errore nella creazione delle impostazioni:", error);
      res.status(400).json({ error: "Errore nella creazione delle impostazioni", details: error });
    }
  });

  // PUT /api/settings/:id - Aggiorna impostazioni API esistenti
  app.put("/api/settings/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const settings = await storage.updateApiSettings(id, req.body);
      
      if (!settings) {
        return res.status(404).json({ error: "Impostazioni non trovate" });
      }
      
      res.json(settings);
    } catch (error) {
      console.error("Errore nell'aggiornamento delle impostazioni:", error);
      res.status(400).json({ error: "Errore nell'aggiornamento delle impostazioni", details: error });
    }
  });

  // DELETE /api/settings/:id - Elimina impostazioni API
  app.delete("/api/settings/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteApiSettings(id);
      
      if (!success) {
        return res.status(404).json({ error: "Impostazioni non trovate" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Errore nell'eliminazione delle impostazioni:", error);
      res.status(500).json({ error: "Errore nell'eliminazione delle impostazioni" });
    }
  });

  // PUT /api/settings/:id/activate - Attiva specifiche impostazioni API
  app.put("/api/settings/:id/activate", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.setActiveApiSettings(id);
      
      if (!success) {
        return res.status(404).json({ error: "Impostazioni non trovate" });
      }
      
      const settings = await storage.getApiSettings();
      res.json(settings);
    } catch (error) {
      console.error("Errore nell'attivazione delle impostazioni:", error);
      res.status(500).json({ error: "Errore nell'attivazione delle impostazioni" });
    }
  });


}