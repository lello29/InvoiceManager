import { Express, Request, Response } from "express";
import { storage } from "../storage";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";
import { db } from "../db";
import { insertInvoiceSchema, insertInvoiceItemSchema } from "@shared/schema";
import { extractTextFromPdf, extractInvoiceDataFromText } from "../utils/pdf-extractor";
import { analyzePdfAsImage, analyzePdfText } from "../openai";
import { matchOrSuggestClient } from "../utils/client-matcher";
import { 
  ensureDirectoryExists, 
  moveFileFromTempToUploads, 
  findPdfFile,
  TEMP_UPLOADS_DIR
} from "../utils/file-handler";
import { isAuthenticated, isAdmin } from "../middleware/auth-middleware";

// Configurazione di multer per il caricamento dei file
const storage_config = multer.diskStorage({
  destination: (req, file, cb) => {
    ensureDirectoryExists(TEMP_UPLOADS_DIR);
    cb(null, TEMP_UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    // Sanitizzazione del nome file
    const sanitizedName = file.originalname
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/\s+/g, '_')
      .replace(/[^a-zA-Z0-9_.-]/g, '');
    
    cb(null, sanitizedName);
  }
});

const upload = multer({ 
  storage: storage_config,
  limits: { fileSize: 10 * 1024 * 1024 }, // Limite a 10MB
  fileFilter: (req, file, cb) => {
    // Accetta solo PDF
    if (file.mimetype !== 'application/pdf') {
      cb(new Error('Solo file PDF sono accettati'));
      return;
    }
    cb(null, true);
  }
});

export function registerInvoiceRoutes(app: Express) {
  // GET /api/invoices - Ottiene tutte le fatture
  app.get("/api/invoices", isAuthenticated, async (req, res) => {
    try {
      if (req.user?.role === "administrator") {
        const invoices = await storage.getInvoices();
        res.json(invoices);
      } else {
        // Per i client normali, ottieni solo le fatture dei clienti associati
        const userClients = await storage.getUserClientAssociations(req.user!.id);
        if (userClients.length === 0) {
          return res.json([]);
        }
        
        const clientIds = userClients.map(uc => uc.clientId);
        let allInvoices: any[] = [];
        
        for (const clientId of clientIds) {
          const invoices = await storage.getInvoicesByClientId(clientId);
          allInvoices = [...allInvoices, ...invoices];
        }
        
        // Include informazioni sul cliente
        const invoicesWithClient = await Promise.all(
          allInvoices.map(async (invoice) => {
            const client = await storage.getClient(invoice.clientId);
            return {
              ...invoice,
              client: {
                name: client?.name || 'Cliente sconosciuto',
                email: client?.email || ''
              }
            };
          })
        );
        
        res.json(invoicesWithClient);
      }
    } catch (error) {
      console.error("Errore nel recupero delle fatture:", error);
      res.status(500).json({ error: "Errore nel recupero delle fatture" });
    }
  });

  // GET /api/invoices/:id - Ottiene una fattura specifica
  app.get("/api/invoices/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const invoice = await storage.getInvoiceWithItems(id);
      
      if (!invoice) {
        return res.status(404).json({ error: "Fattura non trovata" });
      }
      
      // Se non è admin, verifica che l'utente abbia accesso al cliente
      if (req.user?.role !== "administrator") {
        const userClients = await storage.getUserClientAssociations(req.user!.id);
        const clientIds = userClients.map(uc => uc.clientId);
        
        if (!clientIds.includes(invoice.clientId)) {
          return res.status(403).json({ error: "Non autorizzato ad accedere a questa fattura" });
        }
      }
      
      res.json(invoice);
    } catch (error) {
      console.error("Errore nel recupero della fattura:", error);
      res.status(500).json({ error: "Errore nel recupero della fattura" });
    }
  });

  // POST /api/invoices - Crea una nuova fattura
  app.post("/api/invoices", isAdmin, async (req, res) => {
    try {
      const validatedData = insertInvoiceSchema.parse(req.body);
      const invoice = await storage.createInvoice(validatedData);
      
      // Se ci sono elementi nella fattura, creali
      if (req.body.items && Array.isArray(req.body.items)) {
        for (const item of req.body.items) {
          const validatedItem = insertInvoiceItemSchema.parse({
            ...item,
            invoiceId: invoice.id
          });
          await storage.createInvoiceItem(validatedItem);
        }
      }
      
      res.status(201).json(invoice);
    } catch (error) {
      console.error("Errore nella creazione della fattura:", error);
      res.status(400).json({ error: "Errore nella creazione della fattura", details: error });
    }
  });

  // PUT /api/invoices/:id - Aggiorna una fattura esistente
  app.put("/api/invoices/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const invoice = await storage.updateInvoice(id, req.body);
      
      if (!invoice) {
        return res.status(404).json({ error: "Fattura non trovata" });
      }
      
      // Aggiorna gli elementi se forniti
      if (req.body.items && Array.isArray(req.body.items)) {
        // Ottieni gli elementi esistenti
        const existingItems = await storage.getInvoiceItems(id);
        
        // Aggiorna gli elementi esistenti e crea quelli nuovi
        for (const item of req.body.items) {
          if (item.id) {
            // Elemento esistente
            const existingItem = existingItems.find(i => i.id === item.id);
            if (existingItem) {
              await storage.updateInvoiceItem(item.id, item);
            }
          } else {
            // Nuovo elemento
            const validatedItem = insertInvoiceItemSchema.parse({
              ...item,
              invoiceId: id
            });
            await storage.createInvoiceItem(validatedItem);
          }
        }
        
        // Elimina gli elementi che non sono presenti nella nuova lista
        const newItemIds = req.body.items.map(item => item.id).filter(Boolean);
        for (const existingItem of existingItems) {
          if (!newItemIds.includes(existingItem.id)) {
            await storage.deleteInvoiceItem(existingItem.id);
          }
        }
      }
      
      res.json(invoice);
    } catch (error) {
      console.error("Errore nell'aggiornamento della fattura:", error);
      res.status(400).json({ error: "Errore nell'aggiornamento della fattura", details: error });
    }
  });

  // DELETE /api/invoices/:id - Elimina una fattura
  app.delete("/api/invoices/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      // Prima elimina tutti gli elementi della fattura
      const items = await storage.getInvoiceItems(id);
      for (const item of items) {
        await storage.deleteInvoiceItem(item.id);
      }
      
      // Poi elimina la fattura
      const success = await storage.deleteInvoice(id);
      
      if (!success) {
        return res.status(404).json({ error: "Fattura non trovata" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Errore nell'eliminazione della fattura:", error);
      res.status(500).json({ error: "Errore nell'eliminazione della fattura" });
    }
  });

  // POST /api/invoices/:id/items - Aggiunge un elemento a una fattura
  app.post("/api/invoices/:id/items", isAdmin, async (req, res) => {
    try {
      const invoiceId = parseInt(req.params.id);
      const invoice = await storage.getInvoice(invoiceId);
      
      if (!invoice) {
        return res.status(404).json({ error: "Fattura non trovata" });
      }
      
      const validatedItem = insertInvoiceItemSchema.parse({
        ...req.body,
        invoiceId
      });
      
      const item = await storage.createInvoiceItem(validatedItem);
      res.status(201).json(item);
    } catch (error) {
      console.error("Errore nella creazione dell'elemento:", error);
      res.status(400).json({ error: "Errore nella creazione dell'elemento", details: error });
    }
  });

  // PUT /api/invoice-items/:id - Aggiorna un elemento di una fattura
  app.put("/api/invoice-items/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.updateInvoiceItem(id, req.body);
      
      if (!item) {
        return res.status(404).json({ error: "Elemento non trovato" });
      }
      
      res.json(item);
    } catch (error) {
      console.error("Errore nell'aggiornamento dell'elemento:", error);
      res.status(400).json({ error: "Errore nell'aggiornamento dell'elemento", details: error });
    }
  });

  // DELETE /api/invoice-items/:id - Elimina un elemento di una fattura
  app.delete("/api/invoice-items/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteInvoiceItem(id);
      
      if (!success) {
        return res.status(404).json({ error: "Elemento non trovato" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Errore nell'eliminazione dell'elemento:", error);
      res.status(500).json({ error: "Errore nell'eliminazione dell'elemento" });
    }
  });

  // POST /api/invoices/upload-pdf - Carica un PDF e estrai i dati
  app.post("/api/invoices/upload-pdf", isAdmin, upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "Nessun file caricato" });
      }
      
      const filePath = req.file.path;
      
      // Estrai testo dal PDF
      let pdfText = await extractTextFromPdf(filePath);
      
      // Estrai dati strutturati dal testo
      const extractedData = extractInvoiceDataFromText(pdfText);
      
      // Se contiene pochi dati, prova con OpenAI
      if (!extractedData.invoiceNumber || !extractedData.issueDate || !extractedData.totalAmount) {
        console.log("Dati insufficienti estratti con metodo standard, tentativo con OpenAI...");
        try {
          // Prima prova con analisi del testo
          const aiTextAnalysis = await analyzePdfText(pdfText);
          console.log("Risultati analisi OpenAI (testo):", aiTextAnalysis);
          
          // Se non ha funzionato bene, prova con l'analisi dell'immagine
          if (!aiTextAnalysis.invoiceNumber || !aiTextAnalysis.issueDate || !aiTextAnalysis.totalAmount) {
            console.log("Tentativo di analisi con conversione in immagine...");
            const aiImageAnalysis = await analyzePdfAsImage(filePath);
            console.log("Risultati analisi OpenAI (immagine):", aiImageAnalysis);
            
            // Completa i dati mancanti da entrambe le analisi
            Object.keys(aiImageAnalysis).forEach(key => {
              if (aiImageAnalysis[key] && (!extractedData[key] || extractedData[key] === "")) {
                extractedData[key] = aiImageAnalysis[key];
              }
            });
          } else {
            // Completa con i dati dell'analisi del testo
            Object.keys(aiTextAnalysis).forEach(key => {
              if (aiTextAnalysis[key] && (!extractedData[key] || extractedData[key] === "")) {
                extractedData[key] = aiTextAnalysis[key];
              }
            });
          }
        } catch (error) {
          console.error("Errore nell'analisi AI:", error);
        }
      }
      
      // Tenta di abbinare il cliente
      let clientMatch = null;
      if (extractedData.client) {
        clientMatch = await matchOrSuggestClient(extractedData.client);
      }
      
      // Prepara la risposta
      res.json({
        filePath,
        fileName: req.file.originalname,
        extractedData,
        clientMatch,
        rawText: pdfText
      });
    } catch (error) {
      console.error("Errore nell'elaborazione del PDF:", error);
      res.status(500).json({ error: "Errore nell'elaborazione del PDF", details: error });
    }
  });

  // GET /api/invoices/:id/pdf - Ottiene il PDF di una fattura
  app.get("/api/invoices/:id/pdf", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const invoice = await storage.getInvoice(id);
      
      if (!invoice) {
        return res.status(404).json({ error: "Fattura non trovata" });
      }
      
      // Se non è admin, verifica che l'utente abbia accesso al cliente
      if (req.user?.role !== "administrator") {
        const userClients = await storage.getUserClientAssociations(req.user!.id);
        const clientIds = userClients.map(uc => uc.clientId);
        
        if (!clientIds.includes(invoice.clientId)) {
          return res.status(403).json({ error: "Non autorizzato ad accedere a questa fattura" });
        }
      }
      
      // Se non c'è un file collegato
      if (!invoice.pdfPath) {
        return res.status(404).json({ error: "Nessun PDF disponibile per questa fattura" });
      }
      
      // Trova il file PDF in tutte le posizioni possibili
      const pdfFilePath = findPdfFile(invoice.pdfPath);
      
      if (!pdfFilePath) {
        return res.status(404).json({ error: "File PDF non trovato" });
      }
      
      // Ottieni il nome del cliente per il nome del file da scaricare
      const client = await storage.getClient(invoice.clientId);
      const clientName = client ? client.name.replace(/\s+/g, '_') : 'Cliente';
      
      // Formatta il nome del file di download
      const downloadFilename = `${clientName}_${invoice.invoiceNumber}_${invoice.issueDate}.pdf`;
      
      res.download(pdfFilePath, downloadFilename);
    } catch (error) {
      console.error("Errore nel recupero del PDF:", error);
      res.status(500).json({ error: "Errore nel recupero del PDF" });
    }
  });

  // Endpoint per visualizzare un PDF in sicurezza (senza download)
  app.get("/api/secure-pdf/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const invoice = await storage.getInvoice(id);
      
      if (!invoice) {
        return res.status(404).send("Fattura non trovata");
      }
      
      // Se non è admin, verifica che l'utente abbia accesso al cliente
      if (req.user?.role !== "administrator") {
        const userClients = await storage.getUserClientAssociations(req.user!.id);
        const clientIds = userClients.map(uc => uc.clientId);
        
        if (!clientIds.includes(invoice.clientId)) {
          return res.status(403).send("Non autorizzato ad accedere a questa fattura");
        }
      }
      
      // Se non c'è un file collegato
      if (!invoice.pdfPath) {
        return res.status(404).send("Nessun PDF disponibile per questa fattura");
      }
      
      // Trova il file PDF in tutte le posizioni possibili
      const pdfFilePath = findPdfFile(invoice.pdfPath);
      
      if (!pdfFilePath) {
        return res.status(404).send("File PDF non trovato");
      }
      
      // Imposta gli header per evitare la memorizzazione nella cache
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', 'inline');
      res.setHeader('Cache-Control', 'no-store, max-age=0');
      
      // Aggiungi un parametro casuale per evitare la memorizzazione nella cache del browser
      const noCacheParam = `?nocache=${Date.now()}`;
      
      // Leggi il file e invialo come risposta
      fs.createReadStream(pdfFilePath).pipe(res);
    } catch (error) {
      console.error("Errore nel recupero del PDF:", error);
      res.status(500).send("Errore nel recupero del PDF");
    }
  });

  // Endpoint per verificare lo stato e aggiornare i PDF mancanti per le fatture
  app.get("/api/invoices/check-missing-pdfs", isAdmin, async (req, res) => {
    try {
      const invoices = await storage.getInvoices();
      const missingPdfs: any[] = [];
      
      for (const invoice of invoices) {
        // Controlla solo fatture che dovrebbero avere un PDF
        if (invoice.pdfPath) {
          const pdfExists = findPdfFile(invoice.pdfPath) !== null;
          
          if (!pdfExists) {
            const client = await storage.getClient(invoice.clientId);
            missingPdfs.push({
              id: invoice.id,
              invoiceNumber: invoice.invoiceNumber,
              issueDate: invoice.issueDate,
              clientId: invoice.clientId,
              clientName: client ? client.name : 'Cliente sconosciuto',
              pdfPath: invoice.pdfPath
            });
          }
        }
      }
      
      res.json({ missingCount: missingPdfs.length, missingInvoices: missingPdfs });
    } catch (error) {
      console.error("Errore nella verifica dei PDF mancanti:", error);
      res.status(500).json({ error: "Errore nella verifica dei PDF mancanti" });
    }
  });

  // POST /api/invoices/:id/update-pdf - Aggiorna il PDF di una fattura
  app.post("/api/invoices/:id/update-pdf", isAdmin, upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "Nessun file caricato" });
      }
      
      const id = parseInt(req.params.id);
      const invoice = await storage.getInvoice(id);
      
      if (!invoice) {
        return res.status(404).json({ error: "Fattura non trovata" });
      }
      
      // Sposta il file nella directory corretta
      const newPdfPath = await moveFileFromTempToUploads(req.file.path, false, invoice.clientId);
      
      // Aggiorna il percorso del PDF nella fattura
      const updatedInvoice = await storage.updateInvoice(id, {
        pdfPath: newPdfPath
      });
      
      res.json({
        success: true,
        invoice: updatedInvoice,
        message: "PDF aggiornato con successo"
      });
    } catch (error) {
      console.error("Errore nell'aggiornamento del PDF:", error);
      res.status(500).json({ error: "Errore nell'aggiornamento del PDF", details: error });
    }
  });

  // POST /api/invoices/upload-multiple-files - Carica più file per una fattura
  app.post("/api/invoices/upload-multiple-files", isAdmin, upload.array('files', 10), async (req, res) => {
    try {
      const files = req.files as Express.Multer.File[];
      if (!files || files.length === 0) {
        return res.status(400).json({ error: "Nessun file caricato" });
      }
      
      const fileResults = [];
      
      for (const file of files) {
        if (file.mimetype === 'application/pdf') {
          // Estrai testo dal PDF
          let pdfText = '';
          try {
            pdfText = await extractTextFromPdf(file.path);
          } catch (error) {
            console.error("Errore nell'estrazione del testo dal PDF:", error);
          }
          
          // Estrai dati strutturati dal testo
          const extractedData = extractInvoiceDataFromText(pdfText);
          
          // Analisi AI solo se necessario
          if (!extractedData.invoiceNumber || !extractedData.issueDate || !extractedData.totalAmount) {
            try {
              // Analisi del testo
              const aiTextAnalysis = await analyzePdfText(pdfText);
              
              // Completa i dati mancanti
              Object.keys(aiTextAnalysis).forEach(key => {
                if (aiTextAnalysis[key] && (!extractedData[key] || extractedData[key] === "")) {
                  extractedData[key] = aiTextAnalysis[key];
                }
              });
              
              // Se ancora insufficiente, prova con l'analisi dell'immagine
              if (!extractedData.invoiceNumber || !extractedData.issueDate || !extractedData.totalAmount) {
                const aiImageAnalysis = await analyzePdfAsImage(file.path);
                
                Object.keys(aiImageAnalysis).forEach(key => {
                  if (aiImageAnalysis[key] && (!extractedData[key] || extractedData[key] === "")) {
                    extractedData[key] = aiImageAnalysis[key];
                  }
                });
              }
            } catch (error) {
              console.error("Errore nell'analisi AI:", error);
            }
          }
          
          // Tenta di abbinare il cliente
          let clientMatch = null;
          if (extractedData.client) {
            clientMatch = await matchOrSuggestClient(extractedData.client);
          }
          
          fileResults.push({
            filePath: file.path,
            fileName: file.originalname,
            extractedData,
            clientMatch,
            rawText: pdfText
          });
        } else {
          fileResults.push({
            filePath: file.path,
            fileName: file.originalname,
            error: "Formato file non supportato"
          });
        }
      }
      
      res.json({
        success: true,
        files: fileResults
      });
    } catch (error) {
      console.error("Errore nell'elaborazione dei file:", error);
      res.status(500).json({ error: "Errore nell'elaborazione dei file", details: error });
    }
  });
}