import { Request, Response, NextFunction } from "express";

// Middleware per verificare se l'utente è autenticato
export const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Not authenticated" });
};

// Middleware per verificare se l'utente è un amministratore
export const isAdmin = (req: Request, res: Response, next: NextFunction) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  
  if (req.user && req.user.role === "administrator") {
    return next();
  }
  
  res.status(403).json({ message: "Not authorized: admin role required" });
};