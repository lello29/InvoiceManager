import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { LogOut, BarChart3, FileText, Users, Settings, User, Home, UserCog, LineChart, FileX, MessageSquare } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  const isAdmin = user?.role === "admin";

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const navLinkClass = (path: string) => {
    return cn(
      "flex items-center px-4 py-3 text-sm rounded-md",
      location === path 
        ? "bg-gray-900 text-white" 
        : "text-gray-300 hover:bg-gray-700 hover:text-white"
    );
  };

  // Link desktop standard
  const AdminLinks = () => (
    <>
      <Link href="/admin">
        <a className={navLinkClass("/admin")}>
          <BarChart3 className="mr-3 h-4 w-4" />
          <span>Dashboard</span>
        </a>
      </Link>
      <Link href="/admin/invoices">
        <a className={navLinkClass(location.startsWith("/admin/invoices") || location === "/invoices" ? "/admin/invoices" : "")}>
          <FileText className="mr-3 h-4 w-4" />
          <span>Fatture</span>
        </a>
      </Link>
      <Link href="/admin/clients">
        <a className={navLinkClass(location.startsWith("/admin/clients") || location === "/clients" ? "/admin/clients" : "")}>
          <Users className="mr-3 h-4 w-4" />
          <span>Clienti</span>
        </a>
      </Link>
      <Link href="/admin/user-clients">
        <a className={navLinkClass(location.startsWith("/admin/user-clients") ? "/admin/user-clients" : "")}>
          <UserCog className="mr-3 h-4 w-4" />
          <span>Utenti-Clienti</span>
        </a>
      </Link>
      <Link href="/admin/analytics">
        <a className={navLinkClass(location.startsWith("/admin/analytics") ? "/admin/analytics" : "")}>
          <LineChart className="mr-3 h-4 w-4" />
          <span>Analisi AI</span>
        </a>
      </Link>
      <Link href="/admin/missing-pdf">
        <a className={navLinkClass(location.startsWith("/admin/missing-pdf") ? "/admin/missing-pdf" : "")}>
          <FileX className="mr-3 h-4 w-4" />
          <span>PDF Mancanti</span>
        </a>
      </Link>
      <Link href="/admin/settings">
        <a className={navLinkClass(location.startsWith("/admin/settings") || location === "/settings" ? "/admin/settings" : "")}>
          <Settings className="mr-3 h-4 w-4" />
          <span>Impostazioni</span>
        </a>
      </Link>
    </>
  );

  const ClientLinks = () => {
    // Verifica quale tab è attivo dall'URL
    const currentTab = new URLSearchParams(location.split('?')[1] || '').get('tab') || 'fatture';
    
    return (
      <>
        <Link href="/client?tab=fatture">
          <a className={navLinkClass(currentTab === 'fatture' ? "/client?tab=fatture" : "")}>
            <FileText className="mr-3 h-4 w-4" />
            <span>Le mie fatture</span>
          </a>
        </Link>
        <Link href="/client?tab=profilo">
          <a className={navLinkClass(currentTab === 'profilo' ? "/client?tab=profilo" : "")}>
            <User className="mr-3 h-4 w-4" />
            <span>Profilo</span>
          </a>
        </Link>
        <Link href="/client?tab=azienda">
          <a className={navLinkClass(currentTab === 'azienda' ? "/client?tab=azienda" : "")}>
            <Home className="mr-3 h-4 w-4" />
            <span>Azienda</span>
          </a>
        </Link>
        <Link href="/client?tab=messaggi">
          <a className={navLinkClass(currentTab === 'messaggi' ? "/client?tab=messaggi" : "")}>
            <MessageSquare className="mr-3 h-4 w-4" />
            <span>Messaggi</span>
          </a>
        </Link>
      </>
    );
  };

  return (
    <>
      {/* Desktop Sidebar */}
      <div className="hidden md:flex md:flex-col md:fixed md:inset-y-0 md:w-64 bg-gray-800 text-white">
        <div className="flex items-center justify-center h-20 border-b border-gray-700">
          <div className="px-4">
            <svg className="h-10 w-auto" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect width="50" height="50" rx="10" fill="#F59E0B"/>
              <path d="M15 25H35M15 17H35M15 33H28" stroke="white" strokeWidth="3" strokeLinecap="round"/>
            </svg>
            <div className="mt-2 font-semibold text-lg">DEXEVE</div>
          </div>
        </div>

        <div className="flex flex-col overflow-y-auto flex-1 pt-5 pb-4 px-3 space-y-1">
          {isAdmin ? <AdminLinks /> : <ClientLinks />}
        </div>

        <div className="flex-shrink-0 flex border-t border-gray-700 p-4">
          <div className="flex-shrink-0 group block w-full">
            <div className="flex items-center">
              <div className="h-9 w-9 rounded-full bg-gray-700 flex items-center justify-center text-white">
                <User className="h-5 w-5" />
              </div>
              <div className="ml-3 flex-1">
                <p className="text-sm font-medium text-white">{user?.name}</p>
                <button 
                  onClick={handleLogout} 
                  className="text-xs font-medium text-gray-300 hover:text-white"
                >
                  Esci
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Intestazione mobile con logo e nome utente */}
      <div className="md:hidden bg-gray-800 text-white w-full py-4 px-4 flex items-center justify-between sticky top-0 z-20 shadow-md">
        <div className="flex items-center">
          <svg className="h-8 w-auto" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="50" height="50" rx="10" fill="#F59E0B"/>
            <path d="M15 25H35M15 17H35M15 33H28" stroke="white" strokeWidth="3" strokeLinecap="round"/>
          </svg>
          <div className="ml-2 font-semibold">DEXEVE</div>
        </div>
        <div className="flex items-center">
          <div className="text-sm mr-2 font-medium">{user?.name}</div>
        </div>
      </div>
    </>
  );
}