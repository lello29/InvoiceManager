import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Loader2, Save, Trash2, Settings2, Database, LogOut, Download, FileDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useAuth } from "@/hooks/use-auth";
import { useIsMobile } from "@/hooks/use-mobile";

// Sidebar component
import { Sidebar } from "@/components/dashboard/sidebar";

const apiSettingsSchema = z.object({
  name: z.string().min(1, "Il nome è obbligatorio"),
  apiKey: z.string().min(1, "L'API key è obbligatoria"),
  model: z.string().min(1, "Il modello è obbligatorio"),
  isActive: z.boolean().default(false),
  extraOptions: z.string().optional(),
});

type ApiSettingsFormValues = z.infer<typeof apiSettingsSchema>;

export default function Settings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [settingToDelete, setSettingToDelete] = useState<number | null>(null);

  // Redirect if not admin
  if (user?.role !== "admin") {
    return (
      <div className="flex h-screen items-center justify-center">
        <Card className="w-96">
          <CardHeader>
            <CardTitle>Accesso negato</CardTitle>
            <CardDescription>
              Non hai i permessi necessari per visualizzare questa pagina.
            </CardDescription>
          </CardHeader>
          <CardFooter>
            <Button onClick={() => window.location.href = "/"} className="w-full">
              Torna alla Dashboard
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  // Fetch API settings
  const { data: apiSettings = [], isLoading } = useQuery<any[]>({
    queryKey: ["/api/settings"],
    refetchOnWindowFocus: false,
  });

  // Form for adding/editing settings
  const form = useForm<ApiSettingsFormValues>({
    resolver: zodResolver(apiSettingsSchema),
    defaultValues: {
      name: "",
      apiKey: "",
      model: "gpt-4o",
      isActive: true,
      extraOptions: ""
    },
  });

  // Create settings mutation
  const createSettings = useMutation({
    mutationFn: async (data: ApiSettingsFormValues) => {
      // Convert extraOptions to JSON if provided
      let formattedData = { ...data };
      if (data.extraOptions) {
        try {
          formattedData.extraOptions = JSON.parse(data.extraOptions);
        } catch (e) {
          throw new Error("Opzioni extra non sono in formato JSON valido");
        }
      }
      
      return await apiRequest("POST", "/api/settings", formattedData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Impostazioni salvate",
        description: "Le impostazioni API sono state salvate con successo",
      });
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Errore",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete settings mutation
  const deleteSettings = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/settings/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Impostazioni eliminate",
        description: "Le impostazioni API sono state eliminate con successo",
      });
      setIsDeleteDialogOpen(false);
      setSettingToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Errore",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Activate settings mutation
  const activateSettings = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("POST", `/api/settings/${id}/activate`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Impostazioni attivate",
        description: "Le nuove impostazioni API sono ora attive",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Errore",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ApiSettingsFormValues) => {
    createSettings.mutate(data);
  };

  const handleDelete = (id: number) => {
    setSettingToDelete(id);
    setIsDeleteDialogOpen(true);
  };

  const handleConfirmDelete = () => {
    if (settingToDelete !== null) {
      deleteSettings.mutate(settingToDelete);
    }
  };

  const handleActivate = (id: number) => {
    activateSettings.mutate(id);
  };

  // Maschera la chiave API per la visualizzazione
  const maskApiKey = (key: string) => {
    if (!key) return "";
    if (key.length <= 8) return "••••••••";
    return key.substring(0, 4) + "•••••••••••" + key.substring(key.length - 4);
  };

  const isMobile = useIsMobile();
  const { logoutMutation } = useAuth();

  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  return (
    <div className="flex min-h-screen bg-gray-50">
      {!isMobile && <Sidebar />}
      <main className={`flex-1 p-4 md:p-6 pb-20 md:pb-6 ${!isMobile ? "md:ml-64" : "ml-0"}`}>
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-xl md:text-2xl font-bold tracking-tight">Impostazioni API</h1>
          {isMobile && (
            <Button variant="outline" size="sm" onClick={handleLogout} className="flex items-center gap-1">
              <LogOut className="h-4 w-4" />
              Esci
            </Button>
          )}
        </div>

        {/* Sezione di esportazione dati */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileDown className="w-5 h-5" />
              Esportazione dati
            </CardTitle>
            <CardDescription>
              Esporta database e file per il backup o la migrazione
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="rounded-md bg-blue-50 p-4 border border-blue-200">
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <Database className="h-5 w-5 text-blue-500" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-blue-800">Esportazione completa del sistema</h3>
                    <div className="mt-2 text-sm text-blue-700">
                      <p>L'esportazione include:</p>
                      <ul className="list-disc pl-5 mt-1 space-y-1">
                        <li>Impostazioni API</li>
                        <li>Database (utenti, clienti, fatture)</li>
                        <li>Tutti i file PDF associati</li>
                      </ul>
                    </div>
                    <div className="mt-4">
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-blue-300 bg-blue-100 hover:bg-blue-200 text-blue-800"
                        onClick={() => {
                          // Inizia il download diretto
                          window.location.href = '/api/admin/export';
                          
                          // Mostra una notifica di avvio download
                          toast({
                            title: "Download avviato",
                            description: "Esportazione in corso, il download inizierà a breve",
                          });
                        }}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Esporta tutto
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Form per aggiungere nuove impostazioni */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings2 className="w-5 h-5" />
                Aggiungi nuove impostazioni API
              </CardTitle>
              <CardDescription>
                Inserisci i dettagli per le nuove impostazioni API OpenAI
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nome configurazione</FormLabel>
                        <FormControl>
                          <Input placeholder="Es: OpenAI GPT-4" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="apiKey"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>API Key</FormLabel>
                        <FormControl>
                          <Input 
                            type="password" 
                            placeholder="sk-..." 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="model"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Modello</FormLabel>
                        <FormControl>
                          <Input placeholder="gpt-4o" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="extraOptions"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Opzioni aggiuntive (JSON)</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder='{"temperature": 0.7}' 
                            {...field} 
                            className="h-20"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="isActive"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                        <div className="space-y-0.5">
                          <FormLabel>Attiva</FormLabel>
                          <CardDescription>
                            Attiva queste impostazioni come predefinite
                          </CardDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={createSettings.isPending}
                  >
                    {createSettings.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Salvataggio...
                      </>
                    ) : (
                      <>
                        <Save className="mr-2 h-4 w-4" />
                        Salva impostazioni
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
          
          {/* Lista delle impostazioni esistenti */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5" />
                Impostazioni API esistenti
              </CardTitle>
              <CardDescription>
                Gestisci le impostazioni API esistenti
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center p-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : apiSettings.length === 0 ? (
                <div className="text-center p-6 text-gray-500">
                  Nessuna impostazione API trovata
                </div>
              ) : isMobile ? (
                <div className="space-y-4">
                  {apiSettings.map((setting: any) => (
                    <Card key={setting.id} className="overflow-hidden">
                      <CardHeader className="p-4 pb-3 bg-gray-50">
                        <div className="flex justify-between items-center">
                          <CardTitle className="text-base">{setting.name}</CardTitle>
                          {setting.isActive ? (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              Attiva
                            </span>
                          ) : (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                              Inattiva
                            </span>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent className="p-4 pt-3 space-y-2">
                        <div>
                          <p className="text-xs text-gray-500">API Key</p>
                          <p className="text-sm font-mono">{maskApiKey(setting.apiKey)}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Modello</p>
                          <p className="text-sm">{setting.model}</p>
                        </div>
                      </CardContent>
                      <CardFooter className="p-4 pt-0 flex justify-end gap-2">
                        {!setting.isActive && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleActivate(setting.id)}
                            disabled={activateSettings.isPending}
                          >
                            Attiva
                          </Button>
                        )}
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDelete(setting.id)}
                          disabled={deleteSettings.isPending}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="border rounded-md">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nome</TableHead>
                        <TableHead>API Key</TableHead>
                        <TableHead>Modello</TableHead>
                        <TableHead>Stato</TableHead>
                        <TableHead className="text-right">Azioni</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {apiSettings.map((setting: any) => (
                        <TableRow key={setting.id}>
                          <TableCell>{setting.name}</TableCell>
                          <TableCell>{maskApiKey(setting.apiKey)}</TableCell>
                          <TableCell>{setting.model}</TableCell>
                          <TableCell>
                            {setting.isActive ? (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                Attiva
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                Inattiva
                              </span>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              {!setting.isActive && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleActivate(setting.id)}
                                  disabled={activateSettings.isPending}
                                >
                                  Attiva
                                </Button>
                              )}
                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => handleDelete(setting.id)}
                                disabled={deleteSettings.isPending}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Sei sicuro di voler eliminare queste impostazioni?</AlertDialogTitle>
              <AlertDialogDescription>
                Questa azione eliminerà definitivamente le impostazioni API selezionate.
                Questa azione non può essere annullata.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Annulla</AlertDialogCancel>
              <AlertDialogAction 
                onClick={handleConfirmDelete} 
                className="bg-red-600 hover:bg-red-700"
                disabled={deleteSettings.isPending}
              >
                {deleteSettings.isPending ? "Eliminazione..." : "Elimina"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </main>
    </div>
  );
}