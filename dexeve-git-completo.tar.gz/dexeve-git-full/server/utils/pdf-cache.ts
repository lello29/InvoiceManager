/**
 * Sistema di caching per la conversione dei PDF in immagini
 * 
 * Riduce il carico di lavoro evitando di riconvertire ripetutamente
 * gli stessi PDF quando non sono cambiati.
 */

import fs from 'fs';
import path from 'path';
import { createHash } from 'crypto';
import { log } from '../vite';

// Directory dove salvare le immagini convertite
const CACHE_DIR = path.join(process.cwd(), 'uploads', 'cache');

// Assicurati che la directory del cache esista
if (!fs.existsSync(CACHE_DIR)) {
  try {
    fs.mkdirSync(CACHE_DIR, { recursive: true });
    log(`Directory cache creata: ${CACHE_DIR}`, "pdf-cache");
  } catch (error) {
    log(`Errore nella creazione della directory cache: ${error}`, "pdf-cache");
  }
}

/**
 * Genera un hash MD5 del file per usarlo come identificatore univoco
 * @param filePath Percorso al file
 * @returns Hash MD5 del file
 */
export function getFileHash(filePath: string): string {
  try {
    const fileBuffer = fs.readFileSync(filePath);
    return createHash('md5').update(fileBuffer).digest('hex');
  } catch (error) {
    log(`Errore nel calcolo dell'hash del file: ${error}`, "pdf-cache");
    // In caso di errore, usa il nome del file come fallback (meno efficiente)
    return path.basename(filePath);
  }
}

/**
 * Determina se un file è presente nella cache
 * @param pdfPath Percorso al file PDF
 * @returns Percorso al file nella cache se esiste, altrimenti null
 */
export function getFromCache(pdfPath: string): string | null {
  try {
    const fileHash = getFileHash(pdfPath);
    const cachePath = path.join(CACHE_DIR, `${fileHash}.png`);
    
    if (fs.existsSync(cachePath)) {
      const pdfStats = fs.statSync(pdfPath);
      const cacheStats = fs.statSync(cachePath);
      
      // Se il PDF è stato modificato dopo la creazione della cache, la cache non è valida
      if (pdfStats.mtime > cacheStats.mtime) {
        log(`Cache non valida per ${pdfPath}, PDF modificato dopo la creazione della cache`, "pdf-cache");
        return null;
      }
      
      log(`Cache trovata per ${pdfPath}: ${cachePath}`, "pdf-cache");
      return cachePath;
    }
    
    return null;
  } catch (error) {
    log(`Errore nel recupero dalla cache: ${error}`, "pdf-cache");
    return null;
  }
}

/**
 * Salva un file nella cache
 * @param pdfPath Percorso al file PDF originale
 * @param imagePath Percorso all'immagine convertita
 * @returns Percorso al file nella cache
 */
export function saveToCache(pdfPath: string, imagePath: string): string {
  try {
    const fileHash = getFileHash(pdfPath);
    const cachePath = path.join(CACHE_DIR, `${fileHash}.png`);
    
    // Copia l'immagine nella cache
    fs.copyFileSync(imagePath, cachePath);
    log(`File salvato nella cache: ${cachePath}`, "pdf-cache");
    
    return cachePath;
  } catch (error) {
    log(`Errore nel salvataggio nella cache: ${error}`, "pdf-cache");
    return imagePath; // In caso di errore, restituisci il percorso originale
  }
}

/**
 * Pulisce la cache eliminando i file non utilizzati di recente
 * @param maxAgeMs Età massima dei file in millisecondi (default: 7 giorni)
 */
export function cleanCache(maxAgeMs: number = 7 * 24 * 60 * 60 * 1000): void {
  try {
    const files = fs.readdirSync(CACHE_DIR);
    const now = Date.now();
    
    let deletedCount = 0;
    
    for (const file of files) {
      const filePath = path.join(CACHE_DIR, file);
      const stats = fs.statSync(filePath);
      const fileAge = now - stats.mtimeMs;
      
      if (fileAge > maxAgeMs) {
        fs.unlinkSync(filePath);
        deletedCount++;
      }
    }
    
    if (deletedCount > 0) {
      log(`Pulizia cache completata, eliminati ${deletedCount} file`, "pdf-cache");
    }
  } catch (error) {
    log(`Errore nella pulizia della cache: ${error}`, "pdf-cache");
  }
}

// Esegui una pulizia iniziale della cache all'avvio dell'applicazione
cleanCache();