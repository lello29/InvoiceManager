/**
 * Modulo per il matching intelligente dei nomi dei clienti estratti dai PDF
 * con quelli già presenti nel database.
 */

import { storage } from "../storage";
import { Client } from "@shared/schema";
import { log } from "../vite";

/**
 * Calcola la distanza di Levenshtein tra due stringhe
 * (misura la differenza tra due sequenze di caratteri)
 */
function levenshteinDistance(str1: string, str2: string): number {
  const track = Array(str2.length + 1).fill(null).map(() => 
    Array(str1.length + 1).fill(null));
  
  for (let i = 0; i <= str1.length; i += 1) {
    track[0][i] = i;
  }
  
  for (let j = 0; j <= str2.length; j += 1) {
    track[j][0] = j;
  }
  
  for (let j = 1; j <= str2.length; j += 1) {
    for (let i = 1; i <= str1.length; i += 1) {
      const indicator = str1[i - 1] === str2[j - 1] ? 0 : 1;
      track[j][i] = Math.min(
        track[j][i - 1] + 1, // cancellazione
        track[j - 1][i] + 1, // inserimento
        track[j - 1][i - 1] + indicator, // sostituzione
      );
    }
  }
  
  return track[str2.length][str1.length];
}

/**
 * Calcola la somiglianza percentuale tra due stringhe
 * basata sulla distanza di Levenshtein
 */
function similarityPercentage(str1: string, str2: string): number {
  if (!str1 || !str2) return 0;
  
  // Normalizza le stringhe: converti in minuscolo e rimuovi spazi in eccesso
  const s1 = str1.toLowerCase().trim();
  const s2 = str2.toLowerCase().trim();
  
  if (s1 === s2) return 100; // Corrispondenza esatta
  
  const maxLength = Math.max(s1.length, s2.length);
  if (maxLength === 0) return 100; // Entrambe le stringhe sono vuote
  
  const distance = levenshteinDistance(s1, s2);
  return Math.round((1 - distance / maxLength) * 100);
}

/**
 * Cerca il cliente più simile nel database a quello estratto dal PDF
 * @param extractedClientName Nome del cliente estratto dal PDF
 * @param threshold Soglia di somiglianza percentuale (default 70%)
 * @returns Il cliente più simile se la somiglianza supera la soglia, altrimenti null
 */
export async function findMatchingClient(
  extractedClientName: string, 
  threshold: number = 70
): Promise<Client | null> {
  if (!extractedClientName) return null;
  
  log(`Cercando corrispondenza per cliente: "${extractedClientName}"`, "client-matcher");
  
  try {
    // Recupera tutti i clienti dal database
    const allClients = await storage.getClients();
    
    if (!allClients.length) {
      log("Nessun cliente nel database per il confronto", "client-matcher");
      return null;
    }
    
    // Calcola la somiglianza per ogni cliente
    const matches = allClients.map(client => ({
      client,
      similarity: similarityPercentage(extractedClientName, client.name)
    }));
    
    // Ordina per somiglianza decrescente
    matches.sort((a, b) => b.similarity - a.similarity);
    
    // Prendi il miglior match
    const bestMatch = matches[0];
    
    log(`Miglior corrispondenza: "${bestMatch.client.name}" (${bestMatch.similarity}%)`, "client-matcher");
    
    // Restituisci il cliente se la somiglianza supera la soglia
    if (bestMatch.similarity >= threshold) {
      return bestMatch.client;
    }
    
    return null;
  } catch (error) {
    log(`Errore durante la ricerca del cliente: ${error}`, "client-matcher");
    return null;
  }
}

/**
 * Cerca o suggerisce un cliente in base al nome estratto
 * @param extractedClientName Nome del cliente estratto dal PDF
 * @returns Oggetto con id del cliente e stato del matching
 */
export async function matchOrSuggestClient(
  extractedClientName: string
): Promise<{
  clientId?: number;
  matchType: 'exact' | 'similar' | 'suggestion' | 'none';
  similarityScore?: number;
  suggestedName?: string;
}> {
  if (!extractedClientName) {
    return { matchType: 'none' };
  }
  
  try {
    // Prima cerca una corrispondenza esatta
    const exactClient = await storage.getClientByName(extractedClientName);
    if (exactClient) {
      return { 
        clientId: exactClient.id, 
        matchType: 'exact' 
      };
    }
    
    // Se non c'è una corrispondenza esatta, cerca una corrispondenza simile
    const similarClient = await findMatchingClient(extractedClientName);
    if (similarClient) {
      return { 
        clientId: similarClient.id, 
        matchType: 'similar',
        similarityScore: similarityPercentage(extractedClientName, similarClient.name),
        suggestedName: similarClient.name
      };
    }
    
    // Se non ci sono corrispondenze simili, suggerisci il nome estratto come nuovo cliente
    return { 
      matchType: 'suggestion',
      suggestedName: extractedClientName
    };
  } catch (error) {
    log(`Errore nel matching dei clienti: ${error}`, "client-matcher");
    return { matchType: 'none' };
  }
}