import fs from 'fs';
import pdfParse from 'pdf-parse/lib/pdf-parse.js';

// Dichiarazione modulo per risolvere l'errore di importazione
declare module 'pdf-parse/lib/pdf-parse.js';

// Interfaccia per i dati estratti
interface ExtractedInvoiceData {
  invoiceNumber?: string;
  issueDate?: string;
  totalAmount?: number;
  client?: string;
  dueDate?: string;
  paymentMethod?: string;
  [key: string]: any; // Index signature per consentire l'accesso dinamico
}

/**
 * Estrae il testo da un file PDF
 * @param filePath Percorso al file PDF
 * @returns Il testo estratto dal PDF
 */
export async function extractTextFromPdf(filePath: string): Promise<string> {
  try {
    if (!fs.existsSync(filePath)) {
      console.warn(`PDF file not found: ${filePath}`);
      return '';
    }
    const dataBuffer = fs.readFileSync(filePath);
    const data = await pdfParse(dataBuffer, { max: 0 }); // max:0 = nessun limite alle pagine
    return data.text;
  } catch (error) {
    console.error('Error extracting text from PDF:', error);
    return '';
  }
}

/**
 * Estrae dati strutturati da una fattura in formato PDF utilizzando il testo estratto
 * @param pdfText Testo estratto dal PDF
 * @returns Oggetto contenente i dati strutturati estratti
 */
export function extractInvoiceDataFromText(pdfText: string): {
  invoiceNumber?: string;
  issueDate?: string;
  totalAmount?: number;
  client?: string;
  dueDate?: string;
  paymentMethod?: string;
} {
  // Inizializziamo un oggetto vuoto per i dati estratti
  const extractedData: {
    invoiceNumber?: string;
    issueDate?: string;
    totalAmount?: number;
    client?: string;
    dueDate?: string;
    paymentMethod?: string;
  } = {};

  // Prima proviamo l'estrazione per fatture pro-forma
  const proformaData = extractProformaInvoiceData(pdfText);
  if (proformaData && Object.keys(proformaData).length > 0) {
    console.log("Utilizzando estrazione specifica per fatture pro-forma");
    return proformaData;
  }
  
  // Proviamo l'estrazione specifica per fatture DexEve
  const dexeveData = extractDexeveInvoiceData(pdfText);
  if (dexeveData && Object.keys(dexeveData).length > 0) {
    console.log("Utilizzando estrazione specifica per fatture DexEve");
    return dexeveData;
  }
  
  // Proviamo l'estrazione per il formato personalizzato del cliente (con bordi colorati)
  const customFormatData = extractCustomFormatInvoiceData(pdfText);
  if (customFormatData && Object.keys(customFormatData).length > 0) {
    console.log("Utilizzando estrazione specifica per il formato personalizzato");
    return customFormatData;
  }

  // Se l'estrazione specifica non ha funzionato, procediamo con i pattern generici
  // Patterns comuni per i dati delle fatture (ottimizzati per il formato specifico)
  const patterns = {
    invoiceNumber: [
      // Pattern specifici per il formato della fattura fornita
      /Fattura\s+NR[-\s]+(\d+[/\-][A-Za-z0-9]+)/i,
      /Fattura\s+n[.:,\s]+(\d+[/\-][A-Za-z0-9]+)/i,
      /Fattura\s+(?:n|nr|numero)[.:,\s]+(\d+[/\-][A-Za-z0-9]+)/i,
      
      // Pattern generici per altri formati
      /fattura\s+(?:n|nr|numero)[.:,]?\s*([A-Za-z0-9]+[-/]?[A-Za-z0-9]*)/i,
      /numero\s+fattura[.:,]?\s*([A-Za-z0-9]+[-/]?[A-Za-z0-9]*)/i,
      /(?:n|nr|numero)[.:,]?\s*([A-Za-z0-9]+[-/]?[A-Za-z0-9]*)/i,
      /invoice\s+(?:n|nr|number)[.:,]?\s*([A-Za-z0-9]+[-/]?[A-Za-z0-9]*)/i,
      /FTTR[^A-Za-z0-9]*([A-Za-z0-9]+[-/]?[A-Za-z0-9]*)/i,
      /Fatt\.\s*(?:n\.|nr\.|numero)?\s*([A-Za-z0-9]+[-/]?[A-Za-z0-9]*)/i,
    ],
    issueDate: [
      // Pattern specifici per il formato della fattura fornita
      /Fattura\s+NR[-\s]+\d+[/\-][A-Za-z0-9]+\s+del\s+(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})/i,
      /del\s+(\d{1,2}[-/.]\d{1,2}[-/.]\d{4})/i,
      
      // Pattern generici per altri formati
      /data\s+(?:fattura|emissione)[.:,]?\s*(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})/i,
      /(?:fattura|documento)(?:\s+del|\s+emessa\s+il)?[.:,]?\s*(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})/i,
      /emessa\s+(?:il|in)?\s+data[.:,]?\s*(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})/i,
      /data[.:,]?\s*(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})/i,
      /date[.:,]?\s*(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})/i,
    ],
    totalAmount: [
      // Pattern per totali in formato maiuscolo (alta priorità)
      /TOTALE\s+(?:DOCUMENTO|FATTURA|FT)\s*[:=]?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /IMPORTO\s+TOTALE\s*[:=]?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /TOTALE\s+(?:DA\s+PAGARE|DOVUTO|A\s+PAGARE)\s*[:=]?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      
      // Pattern specifici per il formato della fattura fornita
      /Tot\.\s+documento\s*€?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /Totale\s+documento\s*[:=]?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /Totale\s+(?:generale|complessivo)\s*[:=]?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /Totale\s+(?:da\s+pagare|dovuto|a\s+pagare)\s*[:=]?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /Scadenze:.*€\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      
      // Pattern per totali con IVA inclusa
      /Total(?:e)?\s+(?:iva\s+(?:inclusa|incl\.|compresa))[.:,]?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /Totale\s+ivato[.:,]?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      
      // Pattern generici per totali (priorità media)
      /Total(?:e)?\s+(?:fattura|documento|importo)[.:,]?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /Importo\s+(?:totale)[.:,]?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /Tot(?:ale)?\s+da\s+pagare[.:,]?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /Tot(?:ale)?\.?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /Importo\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /Total\s+amount[.:,]?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /Total[.:,]?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      
      // Pattern per importi senza parola "totale" (bassa priorità)
      /(?:€|EUR|euro)\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2}))\s*(?:€|EUR|euro)/i,
    ],
    client: [
      // Pattern specifici per il formato della fattura fornita
      /Fattura\s+intestata(?:\s+|[:,\r\n]+)([A-Za-z0-9\s.&]+)/i,
      /Fattura\s+intestata[\s\S]*?([A-Za-z0-9\s.]+(?:SRL|SPA|S\.R\.L\.|S\.P\.A\.|SRLS|S\.R\.L\.S\.|SAS|S\.A\.S\.))/i,
      
      // Pattern generici per altri formati
      /cliente[.:,]?\s*([A-Za-z0-9\s.&]+?)(?:\s*\n|\s*,|\s*P\.IVA)/i,
      /intestatario[.:,]?\s*([A-Za-z0-9\s.&]+?)(?:\s*\n|\s*,|\s*P\.IVA)/i,
      /fattura(?:to)?\s+(?:per|a|di)[.:,]?\s*([A-Za-z0-9\s.&]+?)(?:\s*\n|\s*,|\s*P\.IVA)/i,
      /destinatario[.:,]?\s*([A-Za-z0-9\s.&]+?)(?:\s*\n|\s*,|\s*P\.IVA)/i,
      /spett\.(?:le)?[.:,]?\s*([A-Za-z0-9\s.&]+?)(?:\s*\n|\s*,|\s*P\.IVA)/i,
      /cliente[.:,]?\s*([A-Za-z0-9\s.&]+)/i,
      /intestatario[.:,]?\s*([A-Za-z0-9\s.&]+)/i,
      /fattura(?:to)?\s+(?:per|a|di)[.:,]?\s*([A-Za-z0-9\s.&]+)/i,
      /destinatario[.:,]?\s*([A-Za-z0-9\s.&]+)/i,
      /spett\.(?:le)?[.:,]?\s*([A-Za-z0-9\s.&]+)/i,
    ],
    dueDate: [
      // Pattern specifici per il formato della fattura fornita
      /Scadenze:\s*(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})/i,
      
      // Pattern generici per altri formati
      /scadenza[.:,]?\s*(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})/i,
      /data\s+scadenza[.:,]?\s*(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})/i,
      /pagamento\s+entro\s+il[.:,]?\s*(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})/i,
      /scad\.[.:,]?\s*(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})/i,
      /termine\s+di\s+pagamento[.:,]?\s*(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})/i,
      /pagare\s+entro[.:,]?\s*(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})/i,
      /due\s+date[.:,]?\s*(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})/i,
    ],
    paymentMethod: [
      // Pattern specifici per il formato della fattura fornita
      /Pagamento:\s*([^:\n]+?)(?:\s*\n|$)/i,
      
      // Pattern generici per altri formati
      /(?:metodo|modalità)\s+(?:di)?\s*pagamento[.:,]?\s*([^:\n]+?)(?:\s*\n|$)/i,
      /pagamento[.:,]?\s*([^:\n]+?)(?:\s*\n|$)/i,
      /payment\s+method[.:,]?\s*([^:\n]+?)(?:\s*\n|$)/i,
    ],
  };

  // Ricerca dei pattern nel testo
  for (const [key, regexList] of Object.entries(patterns)) {
    for (const regex of regexList) {
      const match = pdfText.match(regex);
      if (match && match[1]) {
        if (key === 'totalAmount') {
          // Algoritmo migliorato per normalizzare gli importi
          // che gestisce correttamente entrambi i formati: 1.234,56 e 1,234.56
          
          const amount = match[1].trim();
          let normalizedAmount: string;
          
          // Determina quale formato numerico è stato usato
          if (amount.includes(',') && amount.includes('.')) {
            // Formato con entrambi i separatori (es. 1.234,56)
            const lastCommaIndex = amount.lastIndexOf(',');
            const lastDotIndex = amount.lastIndexOf('.');
            
            if (lastCommaIndex > lastDotIndex) {
              // Formato italiano: 1.234,56 (virgola per decimali)
              normalizedAmount = amount.replace(/\./g, '').replace(',', '.');
            } else {
              // Formato inglese: 1,234.56 (punto per decimali)
              normalizedAmount = amount.replace(/,/g, '');
            }
          } else if (amount.includes(',')) {
            // Solo virgole (es. 1234,56) - assumiamo formato italiano
            normalizedAmount = amount.replace(',', '.');
          } else {
            // Solo punti o nessun separatore (es. 1234.56 o 1234)
            normalizedAmount = amount;
          }
          
          // Assicurati che sia un numero valido
          const parsedAmount = parseFloat(normalizedAmount);
          if (!isNaN(parsedAmount)) {
            extractedData.totalAmount = parsedAmount;
            console.log(`Importo estratto: ${amount} -> normalizzato a: ${normalizedAmount} -> valore: ${parsedAmount}`);
          }
        } else if (key === 'invoiceNumber') {
          extractedData.invoiceNumber = match[1].trim();
        } else if (key === 'issueDate') {
          extractedData.issueDate = match[1].trim();
        } else if (key === 'dueDate') {
          extractedData.dueDate = match[1].trim();
        } else if (key === 'client') {
          extractedData.client = match[1].trim();
        } else if (key === 'paymentMethod') {
          extractedData.paymentMethod = match[1].trim();
        }
        break;
      }
    }
  }
  
  // Log dei dati estratti (per debugging)
  console.log("Dati estratti:", extractedData);

  return extractedData;
}

/**
 * Funzione specializzata per estrarre dati dal formato personalizzato con bordi colorati
 * come indicato dall'utente:
 * - bordo nero: numero fattura
 * - bordo rosso: data emissione
 * - bordo blu: tipo pagamento
 * - bordo giallo: totale fattura
 * @param pdfText Testo estratto dal PDF
 * @returns Oggetto contenente i dati strutturati estratti
 */
function extractCustomFormatInvoiceData(pdfText: string): {
  invoiceNumber?: string;
  issueDate?: string;
  totalAmount?: number;
  client?: string;
  dueDate?: string;
  paymentMethod?: string;
} {
  const data: {
    invoiceNumber?: string;
    issueDate?: string;
    totalAmount?: number;
    client?: string;
    dueDate?: string;
    paymentMethod?: string;
  } = {};
  
  try {
    // Pattern specifici per il formato personalizzato con bordi colorati
    
    // 1. Numero fattura (bordo nero): cercato in formati comuni
    const invoiceNumberPatterns = [
      /(?:fattura|fatt\.?)\s*(?:n\.?|nr\.?|numero)?\s*[:;]?\s*([A-Za-z0-9\/\-]+)/i,
      /(?:n\.?|nr\.?|numero)\s*[:;]?\s*([A-Za-z0-9\/\-]+)/i,
      /(?:invoice)\s*(?:no\.?|number)?\s*[:;]?\s*([A-Za-z0-9\/\-]+)/i,
      /^([A-Za-z0-9\/\-]+)$/
    ];
    
    // 2. Data emissione (bordo rosso): formati più comuni per date italiane
    const issueDatePatterns = [
      /data\s*(?:fattura|emissione)?\s*[:;]?\s*(\d{1,2}[\/\.\-]\d{1,2}[\/\.\-]\d{2,4})/i,
      /(?:del|emessa\sil)\s*(\d{1,2}[\/\.\-]\d{1,2}[\/\.\-]\d{2,4})/i,
      /(\d{1,2}[\/\.\-]\d{1,2}[\/\.\-]\d{2,4})/
    ];
    
    // 3. Metodo pagamento (bordo blu)
    const paymentMethodPatterns = [
      /(?:pagamento|modalità\sdi\spagamento)\s*[:;]?\s*([^\n]*)/i,
      /(?:payment|payment\smethod)\s*[:;]?\s*([^\n]*)/i,
      /(?:bonif|bonifico|contanti|assegno|riba|rid|sepa|paypal|bank\stransfer)/i
    ];
    
    // 4. Totale fattura (bordo giallo)
    const totalAmountPatterns = [
      // Pattern ad alta priorità
      /TOTALE\s+(?:DOCUMENTO|FATTURA|FT)\s*[:=]?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /IMPORTO\s+TOTALE\s*[:=]?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /TOTALE\s+(?:DA\s+PAGARE|DOVUTO|A\s+PAGARE)\s*[:=]?\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      // Pattern specifici (usano bordo giallo)
      /(?:totale|total|tot\.?)\s*(?:documento|fattura|invoice)?\s*[:;]?\s*[€$]?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /(?:importo|amount)\s*(?:totale|total)?\s*[:;]?\s*[€$]?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /(?:tot\.?|total)\s+(?:da\s+pagare|dovuto|a\s+pagare)\s*[:;]?\s*[€$]?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      // Pattern generici (bassa priorità)
      /[€$]\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)\s*[€$]/i
    ];
    
    // Applicazione dei pattern sul testo
    // Per il numero fattura (bordo nero)
    for (const pattern of invoiceNumberPatterns) {
      const match = pdfText.match(pattern);
      if (match && match[1]) {
        data.invoiceNumber = match[1].trim();
        break;
      }
    }
    
    // Per la data emissione (bordo rosso)
    for (const pattern of issueDatePatterns) {
      const match = pdfText.match(pattern);
      if (match && match[1]) {
        const dateStr = match[1].trim();
        // Converti in formato ISO
        const dateParts = dateStr.split(/[\/\.\-]/);
        if (dateParts.length === 3) {
          // Assumiamo il formato DD/MM/YYYY o MM/DD/YYYY in base al contesto italiano
          // In genere in Italia si usa DD/MM/YYYY
          const day = dateParts[0].padStart(2, '0');
          const month = dateParts[1].padStart(2, '0');
          let year = dateParts[2];
          if (year.length === 2) {
            // Se l'anno è in formato a 2 cifre, aggiungiamo il prefisso '20' (per anni 2000+)
            year = '20' + year;
          }
          data.issueDate = `${year}-${month}-${day}`;
        } else {
          data.issueDate = dateStr; // Manteniamo il formato originale se non riusciamo a convertirlo
        }
        break;
      }
    }
    
    // Per il metodo di pagamento (bordo blu)
    for (const pattern of paymentMethodPatterns) {
      const match = pdfText.match(pattern);
      if (match && match[1]) {
        data.paymentMethod = match[1].trim();
        break;
      }
    }
    
    // Per l'importo totale (bordo giallo)
    for (const pattern of totalAmountPatterns) {
      const match = pdfText.match(pattern);
      if (match && match[1]) {
        // Algoritmo avanzato di normalizzazione importi
        const amount = match[1].trim();
        let normalizedAmount: string;
        
        // Determina quale formato numerico è stato usato
        if (amount.includes(',') && amount.includes('.')) {
          // Formato con entrambi i separatori (es. 1.234,56)
          const lastCommaIndex = amount.lastIndexOf(',');
          const lastDotIndex = amount.lastIndexOf('.');
          
          if (lastCommaIndex > lastDotIndex) {
            // Formato italiano: 1.234,56 (virgola per decimali)
            normalizedAmount = amount.replace(/\./g, '').replace(',', '.');
          } else {
            // Formato inglese: 1,234.56 (punto per decimali)
            normalizedAmount = amount.replace(/,/g, '');
          }
        } else if (amount.includes(',')) {
          // Solo virgole (es. 1234,56) - assumiamo formato italiano
          normalizedAmount = amount.replace(',', '.');
        } else {
          // Solo punti o nessun separatore (es. 1234.56 o 1234)
          normalizedAmount = amount;
        }
        
        const parsedAmount = parseFloat(normalizedAmount);
        if (!isNaN(parsedAmount)) {
          data.totalAmount = parsedAmount;
          console.log(`Trovato importo totale (formato personalizzato): ${amount} -> normalizzato a: ${normalizedAmount} -> valore: ${parsedAmount}`);
          break;
        }
      }
    }
    
    // Verifichiamo se abbiamo estratto abbastanza informazioni
    const extractedFieldCount = Object.keys(data).filter(key => data[key as keyof typeof data] !== undefined).length;
    
    if (extractedFieldCount >= 2) {
      console.log("Estrazione formato personalizzato completata con successo:", data);
      return data;
    } else {
      console.log("Estrazione formato personalizzato incompleta, ritorno ai pattern generici");
      return {};
    }
    
  } catch (error) {
    console.error("Errore durante l'estrazione specifica per formato personalizzato:", error);
    return {};
  }
}

/**
 * Funzione specializzata per estrarre dati da fatture pro-forma
 * @param pdfText Testo estratto dal PDF
 * @returns Oggetto contenente i dati strutturati estratti
 */
function extractProformaInvoiceData(pdfText: string): ExtractedInvoiceData {
  const data: {
    invoiceNumber?: string;
    issueDate?: string;
    totalAmount?: number;
    client?: string;
    dueDate?: string;
    paymentMethod?: string;
  } = {};
  
  try {
    // Controllo se è effettivamente una fattura pro-forma
    if (!pdfText.toLowerCase().includes("pro-forma") && 
        !pdfText.toLowerCase().includes("proforma")) {
      return {};
    }
    
    console.log("Rilevata fattura pro-forma");
    
    // Estrai il numero di fattura dal nome del file o dal testo
    // Pattern speciale per fatture pro-forma
    const invoiceNumberPattern = /(?:Fattura|Ft)\s+(?:pro-forma|proforma)\s+(\d+[-/][A-Za-z0-9]+)/i;
    const invoiceNumberMatch = pdfText.match(invoiceNumberPattern);
    
    if (invoiceNumberMatch && invoiceNumberMatch[1]) {
      data.invoiceNumber = invoiceNumberMatch[1].trim();
    } else {
      // Estrai dal testo del PDF utilizzando pattern più generico
      const altPattern = /(\d+[-/][A-Za-z0-9]+)/i;
      const altMatch = pdfText.match(altPattern);
      
      if (altMatch && altMatch[1]) {
        data.invoiceNumber = altMatch[1].trim();
      }
    }
    
    // Estrai la data di emissione - pattern migliorati
    const datePatterns = [
      /del\s+(\d{1,2}[-/.]\d{1,2}[-/.]\d{4})/i,
      /data\s+(?:emissione|fattura)?\s*[:;]?\s*(\d{1,2}[-/.]\d{1,2}[-/.]\d{4})/i,
      /(?:emessa|emesso)\s+(?:il|in\s+data)?\s*[:;]?\s*(\d{1,2}[-/.]\d{1,2}[-/.]\d{4})/i,
      /data\s*[:;]?\s*(\d{1,2}[-/.]\d{1,2}[-/.]\d{4})/i,
      // Cerca date nel formato GG/MM/AAAA o GG-MM-AAAA stand-alone
      /\b(\d{1,2}[-/.]\d{1,2}[-/.]\d{4})\b/i
    ];
    
    let dateFound = false;
    
    for (const pattern of datePatterns) {
      const dateMatch = pdfText.match(pattern);
      if (dateMatch && dateMatch[1]) {
        const dateStr = dateMatch[1].trim();
        console.log(`Data fattura trovata con pattern ${pattern}: ${dateStr}`);
        
        // Converti al formato italiano DD/MM/YYYY
        const dateParts = dateStr.split(/[\/\.\-]/);
        if (dateParts.length === 3) {
          const day = dateParts[0].padStart(2, '0');
          const month = dateParts[1].padStart(2, '0');
          const year = dateParts[2];
          data.issueDate = `${day}/${month}/${year}`;
          dateFound = true;
          break;
        } else {
          data.issueDate = dateStr;
          dateFound = true;
          break;
        }
      }
    }
    
    // Se non è stata trovata una data di emissione, tenta un'estrazione più aggressiva
    if (!dateFound) {
      // Cerca qualsiasi sequenza che sembra una data nel formato GG/MM/AAAA
      const allDatesPattern = /(\d{1,2}[\/\.\-]\d{1,2}[\/\.\-]\d{4})/g;
      const allDatesMatches = pdfText.match(allDatesPattern);
      
      if (allDatesMatches && allDatesMatches.length > 0) {
        // Usa la prima data trovata come fallback
        const dateStr = allDatesMatches[0].trim();
        console.log(`Data trovata con ricerca generica: ${dateStr}`);
        
        const dateParts = dateStr.split(/[\/\.\-]/);
        if (dateParts.length === 3) {
          const day = dateParts[0].padStart(2, '0');
          const month = dateParts[1].padStart(2, '0');
          const year = dateParts[2];
          data.issueDate = `${day}/${month}/${year}`;
        } else {
          data.issueDate = dateStr;
        }
      }
    }
    
    // Estrai importo totale
    const patterns = [
      /[Tt]otale\s+(?:documento|fattura|importo)[\s:]*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /[Tt]otale\s*(?:€|EUR|euro)?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2}))\s*(?:€|EUR|euro)/i
    ];
    
    for (const pattern of patterns) {
      const match = pdfText.match(pattern);
      if (match && match[1]) {
        const amountStr = match[1].trim();
        // Gestione dei separatori numerici
        let normalizedAmount = amountStr;
        
        if (amountStr.includes(',') && amountStr.includes('.')) {
          // Formato con punto per migliaia e virgola per decimali (es. 1.234,56)
          normalizedAmount = amountStr.replace(/\./g, '').replace(',', '.');
        } else if (amountStr.includes(',')) {
          // Formato con virgola per decimali (es. 1234,56)
          normalizedAmount = amountStr.replace(',', '.');
        }
        
        const parsedAmount = parseFloat(normalizedAmount);
        if (!isNaN(parsedAmount)) {
          data.totalAmount = parsedAmount;
          break;
        }
      }
    }
    
    // Estrai nome cliente
    const clientPatterns = [
      /Destinazione\s+([A-Za-z0-9\s\.]+(?:SRL|SPA|S\.R\.L\.|S\.P\.A\.|SRLS|S\.A\.S\.))/i,
      /(?:cliente|customer|intestatario)[\s:]+([A-Za-z0-9\s\.]+(?:SRL|SPA|S\.R\.L\.|S\.P\.A\.|SRLS|S\.A\.S\.))/i,
      /(?:fattura|documento)(?:\s+intestat[oa])?(?:\s+a)?[\s:]+([A-Za-z0-9\s\.]+(?:SRL|SPA|S\.R\.L\.|S\.P\.A\.|SRLS|S\.A\.S\.))/i
    ];
    
    for (const pattern of clientPatterns) {
      const match = pdfText.match(pattern);
      if (match && match[1]) {
        data.client = match[1].trim();
        break;
      }
    }
    
    // Estrai metodo di pagamento
    const paymentPatterns = [
      /[Pp]agamento[\s:]+([^\n\.]+)/i,
      /[Pp]ag\.[\s:]+([^\n\.]+)/i,
      /[Mm]odalità\s+di\s+pagamento[\s:]+([^\n\.]+)/i
    ];
    
    for (const pattern of paymentPatterns) {
      const match = pdfText.match(pattern);
      if (match && match[1]) {
        data.paymentMethod = match[1].trim();
        break;
      }
    }
    
    // Verifica se abbiamo estratto abbastanza informazioni
    const extractedFieldCount = Object.keys(data).filter(key => {
      const typedKey = key as keyof typeof data;
      return data[typedKey] !== undefined;
    }).length;
    
    if (extractedFieldCount >= 2) {
      console.log("Estrazione formato pro-forma completata con successo:", data);
      return data;
    } else {
      console.log("Estrazione formato pro-forma incompleta, tentando altri metodi");
      return {};
    }
    
  } catch (error) {
    console.error("Errore durante l'estrazione specifica per formato pro-forma:", error);
    return {};
  }
}

/**
 * Funzione specializzata per estrarre dati da fatture DexEve (come gli esempi forniti)
 * @param pdfText Testo estratto dal PDF
 * @returns Oggetto contenente i dati strutturati estratti
 */
function extractDexeveInvoiceData(pdfText: string): {
  invoiceNumber?: string;
  issueDate?: string;
  totalAmount?: number;
  client?: string;
  dueDate?: string;
  paymentMethod?: string;
} {
  const data: {
    invoiceNumber?: string;
    issueDate?: string;
    totalAmount?: number;
    client?: string;
    dueDate?: string;
    paymentMethod?: string;
  } = {};
  
  try {
    // Verifica se il testo contiene elementi caratteristici delle fatture DexEve
    if (!pdfText.includes('Via Vigonovese 40 - 35127 PADOVA') && 
        !pdfText.includes('Pec: dexeve@pec.it')) {
      return {}; // Non è una fattura DexEve
    }
    
    console.log("Rilevata fattura DexEve, applicando estrazione specifica");
    
    // 1. Estrai numero fattura
    const invoiceNumberMatch = pdfText.match(/Fattura\s+NR[-\s]+(\d+[/\-][A-Za-z0-9]+)/i);
    if (invoiceNumberMatch && invoiceNumberMatch[1]) {
      data.invoiceNumber = invoiceNumberMatch[1].trim();
    }
    
    // 2. Estrai data emissione
    const issueDateMatch = pdfText.match(/del\s+(\d{1,2}\/\d{1,2}\/\d{4})/i);
    if (issueDateMatch && issueDateMatch[1]) {
      const dateStr = issueDateMatch[1].trim();
      // Converti data in formato YYYY-MM-DD
      const parts = dateStr.split('/');
      if (parts.length === 3) {
        data.issueDate = `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
      } else {
        data.issueDate = dateStr;
      }
    }
    
    // 3. Estrai cliente - formato specifico per fatture DexEve
    const clientMatch = pdfText.match(/Fattura\s+intestata\s+([^\n]+)/i);
    if (clientMatch && clientMatch[1]) {
      let clientName = clientMatch[1].trim();
      // Rimuovi eventuale indirizzo che segue il nome
      const addressStartIndex = clientName.indexOf('P.ZZA');
      if (addressStartIndex > 0) {
        clientName = clientName.substring(0, addressStartIndex).trim();
      }
      data.client = clientName;
    }
    
    // 4. Estrai importo totale - usa una serie di pattern con priorità
    const totalPatterns = [
      // Totale documento (alta priorità)
      /Tot\.\s+documento\s+€\s+(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /Totale\s+documento\s+€\s+(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /TOTALE\s+documento\s+€\s+(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      
      // Sezione Scadenze (alta priorità)
      /Scadenze:\s*\d{1,2}\/\d{1,2}\/\d{4}\s+€\s+(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      
      // Importi IVA e totali (media priorità) 
      /Totale\s+Imponibile\s+€\s+(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /Imposta\s+IVA\s+€\s+(?:\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?).+?Totale\s+€\s+(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      /Totale\s+€\s+(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i,
      
      // Ultima spiaggia (bassa priorità)
      /€\s+(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)/i
    ];
    
    // Prova i pattern in ordine
    for (const pattern of totalPatterns) {
      const match = pdfText.match(pattern);
      if (match && match[1]) {
        // Algoritmo avanzato di normalizzazione importi
        const amount = match[1].trim();
        let normalizedAmount: string;
        
        // Determina quale formato numerico è stato usato
        if (amount.includes(',') && amount.includes('.')) {
          // Formato con entrambi i separatori (es. 1.234,56)
          const lastCommaIndex = amount.lastIndexOf(',');
          const lastDotIndex = amount.lastIndexOf('.');
          
          if (lastCommaIndex > lastDotIndex) {
            // Formato italiano: 1.234,56 (virgola per decimali)
            normalizedAmount = amount.replace(/\./g, '').replace(',', '.');
          } else {
            // Formato inglese: 1,234.56 (punto per decimali)
            normalizedAmount = amount.replace(/,/g, '');
          }
        } else if (amount.includes(',')) {
          // Solo virgole (es. 1234,56) - assumiamo formato italiano
          normalizedAmount = amount.replace(',', '.');
        } else {
          // Solo punti o nessun separatore (es. 1234.56 o 1234)
          normalizedAmount = amount;
        }
        
        const parsedAmount = parseFloat(normalizedAmount);
        if (!isNaN(parsedAmount)) {
          data.totalAmount = parsedAmount;
          console.log(`Trovato importo totale: ${amount} -> normalizzato a: ${normalizedAmount} -> valore: ${parsedAmount} usando pattern: ${pattern}`);
          break;
        }
      }
    }
    
    // 5. Estrai data scadenza
    const dueDateMatch = pdfText.match(/Scadenze:\s*(\d{1,2}\/\d{1,2}\/\d{4})/i);
    if (dueDateMatch && dueDateMatch[1]) {
      const dateStr = dueDateMatch[1].trim();
      const parts = dateStr.split('/');
      if (parts.length === 3) {
        data.dueDate = `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
      } else {
        data.dueDate = dateStr;
      }
    }
    
    // 6. Estrai metodo di pagamento
    const paymentMethodMatch = pdfText.match(/Pagamento:\s*([^\n]+)/i);
    if (paymentMethodMatch && paymentMethodMatch[1]) {
      data.paymentMethod = paymentMethodMatch[1].trim();
    }
    
    // Se abbiamo estratto almeno 3 campi importanti, probabilmente l'estrazione è andata a buon fine
    const importantFields = ['invoiceNumber', 'issueDate', 'totalAmount'];
    const foundFieldCount = importantFields.filter(field => {
      const typedField = field as keyof typeof data;
      return data[typedField] !== undefined;
    }).length;
    
    if (foundFieldCount >= 3) {
      console.log("Estrazione DexEve completata con successo:", data);
      return data;
    } else {
      console.log("Estrazione DexEve incompleta, ritorno ai pattern generici");
      return {};
    }
  
  } catch (error) {
    console.error("Errore durante l'estrazione specifica per DexEve:", error);
    return {};
  }
}