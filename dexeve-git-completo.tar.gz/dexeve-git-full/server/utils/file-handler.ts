import fs from "fs";
import path from "path";

// Costanti per il progetto
export const IN_REPLIT = process.env.REPL_ID !== undefined;
console.log(`Ambiente rilevato: ${IN_REPLIT ? 'Replit' : 'Produzione'}`);
console.log(`Directory di lavoro: ${process.cwd()}`);

// Directory per tutti i tipi di persistenza (garantite in Replit)
export const PERSISTENCE_DIR = path.join(process.cwd(), 'attached_assets');
export const PDF_STORAGE_DIR = path.join(PERSISTENCE_DIR, 'pdf_storage');
export const BACKUP_DIR = path.join(PERSISTENCE_DIR, 'pdf_backup');
export const UPLOADS_DIR = path.join(process.cwd(), 'uploads');
export const TEMP_UPLOADS_DIR = path.join(process.cwd(), 'temp_uploads');

// Crea directory se non esistono
export function ensureDirectoryExists(dirPath: string) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
    console.log(`Directory creata: ${dirPath}`);
    // Imposta permessi massimi per debug
    try {
      fs.chmodSync(dirPath, 0o777);
    } catch (err) {
      console.error(`Errore nell'impostazione dei permessi per ${dirPath}:`, err);
    }
  }
  return dirPath;
}

// Inizializza tutte le directory necessarie
export function initializeDirectories() {
  ensureDirectoryExists(UPLOADS_DIR);
  ensureDirectoryExists(TEMP_UPLOADS_DIR);
  ensureDirectoryExists(PDF_STORAGE_DIR);
  ensureDirectoryExists(BACKUP_DIR);
}

// Funzione di utilità per trovare un file PDF in tutte le possibili locazioni
// Ritorna il percorso completo del file se trovato, null altrimenti
export function findPdfFile(relativeFilePath: string): string | null {
  console.log(`FINDER - Cercando PDF: ${relativeFilePath}`);
  
  // Primo controllo: se siamo in Replit, verifica prima nelle directory persistenti
  if (IN_REPLIT) {
    const baseFileName = path.basename(relativeFilePath);
    
    // Cerca in attached_assets/pdf_storage
    const persistentPath = path.join(PDF_STORAGE_DIR, baseFileName);
    if (fs.existsSync(persistentPath)) {
      console.log(`FINDER - Trovato in PDF_STORAGE_DIR: ${persistentPath}`);
      return persistentPath;
    }
    
    // Cerca in attached_assets/pdf_backup
    const backupPath = path.join(BACKUP_DIR, baseFileName);
    if (fs.existsSync(backupPath)) {
      console.log(`FINDER - Trovato in BACKUP_DIR: ${backupPath}`);
      try {
        // Recupera il file dal backup e lo ripristina nella posizione originale
        const dirPath = path.dirname(relativeFilePath);
        ensureDirectoryExists(dirPath);
        fs.copyFileSync(backupPath, relativeFilePath);
        console.log(`FINDER - File ripristinato da backup: ${relativeFilePath}`);
        return relativeFilePath;
      } catch (err) {
        console.error(`FINDER - Errore nel ripristino dal backup:`, err);
        return backupPath; // Ritorna il percorso del backup se non riesce a ripristinare
      }
    }
  }
  
  // Controllo standard: percorso relativo (uploads/...)
  if (fs.existsSync(relativeFilePath)) {
    console.log(`FINDER - Trovato in percorso originale: ${relativeFilePath}`);
    return relativeFilePath;
  }
  
  // Controllo percorso con root diverso (quando il file è fornito con percorso completo)
  const absolutePath = path.isAbsolute(relativeFilePath) 
    ? relativeFilePath 
    : path.join(process.cwd(), relativeFilePath);
  
  if (fs.existsSync(absolutePath)) {
    console.log(`FINDER - Trovato in percorso assoluto: ${absolutePath}`);
    return absolutePath;
  }
  
  // Ultimo tentativo: cerca il file solo per nome in uploads
  const baseFileName = path.basename(relativeFilePath);
  const uploadsPath = path.join(UPLOADS_DIR, baseFileName);
  if (fs.existsSync(uploadsPath)) {
    console.log(`FINDER - Trovato in UPLOADS_DIR per nome file: ${uploadsPath}`);
    return uploadsPath;
  }
  
  console.log(`FINDER - PDF non trovato in nessuna posizione`);
  return null;
}

// Ottiene il nome della cartella del cliente in base all'ID client
export async function getClientFolderName(clientId: number): Promise<string> {
  try {
    const { storage } = await import("../storage");
    const client = await storage.getClient(clientId);
    
    if (client) {
      // Usa il nome del cliente per la cartella, normalizzato per l'uso nei filesystem
      const folderName = client.name
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "") // Rimuove gli accenti
        .replace(/[^a-zA-Z0-9]/g, "_")   // Sostituisce caratteri non alfanumerici con underscore
        .toUpperCase();                   // Tutto maiuscolo per coerenza
      
      return folderName;
    }
  } catch (error) {
    console.error("Errore nell'ottenere le informazioni del cliente:", error);
  }
  
  // Fallback al nome basato sull'ID
  return `CLIENT_${clientId}`;
}

// Sposta un file dalla directory temporanea alla directory uploads
export async function moveFileFromTempToUploads(tempFilePath: string, keepOriginal: boolean = false, clientId?: number): Promise<string> {
  // Verifica se il file esiste
  if (!fs.existsSync(tempFilePath)) {
    throw new Error(`File non trovato: ${tempFilePath}`);
  }
  
  // Determina la directory di destinazione
  let destDir = UPLOADS_DIR;
  
  if (clientId) {
    const clientFolder = await getClientFolderName(clientId);
    destDir = path.join(UPLOADS_DIR, clientFolder);
    ensureDirectoryExists(destDir);
  }
  
  // Genera il percorso di destinazione
  const fileName = path.basename(tempFilePath);
  const destPath = path.join(destDir, fileName);
  
  console.log(`Spostamento file da ${tempFilePath} a ${destPath}`);
  
  // Copia o sposta il file
  if (keepOriginal) {
    fs.copyFileSync(tempFilePath, destPath);
  } else {
    fs.renameSync(tempFilePath, destPath);
  }
  
  // Verifica che il file sia stato copiato/spostato correttamente
  if (!fs.existsSync(destPath)) {
    throw new Error(`Errore: il file non è stato trovato nella destinazione dopo il trasferimento: ${destPath}`);
  }
  
  // Se siamo in Replit, salva una copia anche nelle directory persistenti
  if (IN_REPLIT) {
    try {
      // Salva in pdf_storage
      const storagePath = path.join(PDF_STORAGE_DIR, fileName);
      fs.copyFileSync(destPath, storagePath);
      console.log(`Creato backup in pdf_storage: ${storagePath}`);
      
      // Salva in pdf_backup
      const backupPath = path.join(BACKUP_DIR, fileName);
      fs.copyFileSync(destPath, backupPath);
      console.log(`Creato backup in pdf_backup: ${backupPath}`);
    } catch (err) {
      console.error("Errore nella creazione dei backup:", err);
    }
  }
  
  // Restituisci il percorso relativo del file (importante per salvare nel DB)
  const relPath = path.relative(process.cwd(), destPath);
  return relPath;
}

// Normalizza un nome di file per l'uso nei filesystem
export function normalizeFileName(fileName: string): string {
  return fileName
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // Rimuove gli accenti
    .replace(/\s+/g, "_")            // Sostituisce spazi con underscore
    .replace(/[^a-zA-Z0-9_.-]/g, "") // Rimuove caratteri non permessi
    .replace(/_{2,}/g, "_");         // Rimuove underscore multipli consecutivi
}